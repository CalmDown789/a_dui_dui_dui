
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [2:0] axis_block_sigs;
wire [9:0] inst_idle_sigs;
wire [2:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.conv3x3_layer_top_U0.grp_conv3x3_layer_top_Pipeline_input_channel_loop_output_channel_loop_fu_233.feature_in_TDATA_blk_n;
assign axis_block_sigs[1] = ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.grp_pixel_shuffle2x_stream_top_Pipeline_produce_upper_row_fu_116.pixel_out_TDATA_blk_n;
assign axis_block_sigs[2] = ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.grp_pixel_shuffle2x_stream_top_Pipeline_produce_lower_row_fu_133.pixel_out_TDATA_blk_n;

assign inst_idle_sigs[0] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.conv3x3_layer_top_U0.ap_idle;
assign inst_block_sigs[0] = (grp_p_anonymous_namespace_stage3_dataflow_fu_172.conv3x3_layer_top_U0.ap_done & ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.conv3x3_layer_top_U0.ap_continue) | ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.conv3x3_layer_top_U0.grp_conv3x3_layer_top_Pipeline_write_output_loop_fu_277.accumulator_stream_blk_n;
assign inst_idle_sigs[1] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.postprocess_stream_top_U0.ap_idle;
assign inst_block_sigs[1] = (grp_p_anonymous_namespace_stage3_dataflow_fu_172.postprocess_stream_top_U0.ap_done & ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.postprocess_stream_top_U0.ap_continue) | ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.postprocess_stream_top_U0.accumulator_stream_blk_n | ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.postprocess_stream_top_U0.channel_stream_blk_n;
assign inst_idle_sigs[2] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.ap_idle;
assign inst_block_sigs[2] = (grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.ap_done & ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.ap_continue) | ~grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.grp_pixel_shuffle2x_stream_top_Pipeline_produce_upper_row_fu_116.channel_stream_blk_n;

assign inst_idle_sigs[3] = 1'b0;
assign inst_idle_sigs[4] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.ap_idle;
assign inst_idle_sigs[5] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.conv3x3_layer_top_U0.ap_idle;
assign inst_idle_sigs[6] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.conv3x3_layer_top_U0.grp_conv3x3_layer_top_Pipeline_input_channel_loop_output_channel_loop_fu_233.ap_idle;
assign inst_idle_sigs[7] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.ap_idle;
assign inst_idle_sigs[8] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.grp_pixel_shuffle2x_stream_top_Pipeline_produce_upper_row_fu_116.ap_idle;
assign inst_idle_sigs[9] = grp_p_anonymous_namespace_stage3_dataflow_fu_172.pixel_shuffle2x_stream_top_U0.grp_pixel_shuffle2x_stream_top_Pipeline_produce_lower_row_fu_133.ap_idle;

stage3_pipeline_top_hls_deadlock_idx0_monitor stage3_pipeline_top_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
