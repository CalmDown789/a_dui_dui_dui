// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XSTAGE3_PIPELINE_TOP_H
#define XSTAGE3_PIPELINE_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xstage3_pipeline_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XStage3_pipeline_top_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XStage3_pipeline_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XStage3_pipeline_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XStage3_pipeline_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XStage3_pipeline_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XStage3_pipeline_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XStage3_pipeline_top_Initialize(XStage3_pipeline_top *InstancePtr, UINTPTR BaseAddress);
XStage3_pipeline_top_Config* XStage3_pipeline_top_LookupConfig(UINTPTR BaseAddress);
#else
int XStage3_pipeline_top_Initialize(XStage3_pipeline_top *InstancePtr, u16 DeviceId);
XStage3_pipeline_top_Config* XStage3_pipeline_top_LookupConfig(u16 DeviceId);
#endif
int XStage3_pipeline_top_CfgInitialize(XStage3_pipeline_top *InstancePtr, XStage3_pipeline_top_Config *ConfigPtr);
#else
int XStage3_pipeline_top_Initialize(XStage3_pipeline_top *InstancePtr, const char* InstanceName);
int XStage3_pipeline_top_Release(XStage3_pipeline_top *InstancePtr);
#endif

void XStage3_pipeline_top_Start(XStage3_pipeline_top *InstancePtr);
u32 XStage3_pipeline_top_IsDone(XStage3_pipeline_top *InstancePtr);
u32 XStage3_pipeline_top_IsIdle(XStage3_pipeline_top *InstancePtr);
u32 XStage3_pipeline_top_IsReady(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_EnableAutoRestart(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_DisableAutoRestart(XStage3_pipeline_top *InstancePtr);

void XStage3_pipeline_top_Set_input_channels(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_input_channels(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_rows(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_rows(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_cols(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_cols(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_rounding_mode(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_rounding_mode(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_enable_saturation(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_enable_saturation(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_map00(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_map00(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_map01(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_map01(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_map10(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_map10(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_Set_map11(XStage3_pipeline_top *InstancePtr, u32 Data);
u32 XStage3_pipeline_top_Get_map11(XStage3_pipeline_top *InstancePtr);

void XStage3_pipeline_top_InterruptGlobalEnable(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_InterruptGlobalDisable(XStage3_pipeline_top *InstancePtr);
void XStage3_pipeline_top_InterruptEnable(XStage3_pipeline_top *InstancePtr, u32 Mask);
void XStage3_pipeline_top_InterruptDisable(XStage3_pipeline_top *InstancePtr, u32 Mask);
void XStage3_pipeline_top_InterruptClear(XStage3_pipeline_top *InstancePtr, u32 Mask);
u32 XStage3_pipeline_top_InterruptGetEnabled(XStage3_pipeline_top *InstancePtr);
u32 XStage3_pipeline_top_InterruptGetStatus(XStage3_pipeline_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
