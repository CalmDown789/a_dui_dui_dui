// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xstage3_pipeline_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XStage3_pipeline_top_CfgInitialize(XStage3_pipeline_top *InstancePtr, XStage3_pipeline_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XStage3_pipeline_top_Start(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL) & 0x80;
    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XStage3_pipeline_top_IsDone(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XStage3_pipeline_top_IsIdle(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XStage3_pipeline_top_IsReady(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XStage3_pipeline_top_EnableAutoRestart(XStage3_pipeline_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XStage3_pipeline_top_DisableAutoRestart(XStage3_pipeline_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL, 0);
}

void XStage3_pipeline_top_Set_input_channels(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_INPUT_CHANNELS_DATA, Data);
}

u32 XStage3_pipeline_top_Get_input_channels(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_INPUT_CHANNELS_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_rows(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ROWS_DATA, Data);
}

u32 XStage3_pipeline_top_Get_rows(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ROWS_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_cols(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_COLS_DATA, Data);
}

u32 XStage3_pipeline_top_Get_cols(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_COLS_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_rounding_mode(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ROUNDING_MODE_DATA, Data);
}

u32 XStage3_pipeline_top_Get_rounding_mode(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ROUNDING_MODE_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_enable_saturation(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ENABLE_SATURATION_DATA, Data);
}

u32 XStage3_pipeline_top_Get_enable_saturation(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ENABLE_SATURATION_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_map00(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP00_DATA, Data);
}

u32 XStage3_pipeline_top_Get_map00(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP00_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_map01(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP01_DATA, Data);
}

u32 XStage3_pipeline_top_Get_map01(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP01_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_map10(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP10_DATA, Data);
}

u32 XStage3_pipeline_top_Get_map10(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP10_DATA);
    return Data;
}

void XStage3_pipeline_top_Set_map11(XStage3_pipeline_top *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP11_DATA, Data);
}

u32 XStage3_pipeline_top_Get_map11(XStage3_pipeline_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP11_DATA);
    return Data;
}

void XStage3_pipeline_top_InterruptGlobalEnable(XStage3_pipeline_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_GIE, 1);
}

void XStage3_pipeline_top_InterruptGlobalDisable(XStage3_pipeline_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_GIE, 0);
}

void XStage3_pipeline_top_InterruptEnable(XStage3_pipeline_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_IER);
    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_IER, Register | Mask);
}

void XStage3_pipeline_top_InterruptDisable(XStage3_pipeline_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_IER);
    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_IER, Register & (~Mask));
}

void XStage3_pipeline_top_InterruptClear(XStage3_pipeline_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStage3_pipeline_top_WriteReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ISR, Mask);
}

u32 XStage3_pipeline_top_InterruptGetEnabled(XStage3_pipeline_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_IER);
}

u32 XStage3_pipeline_top_InterruptGetStatus(XStage3_pipeline_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XStage3_pipeline_top_ReadReg(InstancePtr->Control_BaseAddress, XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ISR);
}

