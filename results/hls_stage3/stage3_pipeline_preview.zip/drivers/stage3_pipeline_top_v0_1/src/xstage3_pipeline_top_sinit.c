// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xstage3_pipeline_top.h"

extern XStage3_pipeline_top_Config XStage3_pipeline_top_ConfigTable[];

#ifdef SDT
XStage3_pipeline_top_Config *XStage3_pipeline_top_LookupConfig(UINTPTR BaseAddress) {
	XStage3_pipeline_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XStage3_pipeline_top_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XStage3_pipeline_top_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XStage3_pipeline_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XStage3_pipeline_top_Initialize(XStage3_pipeline_top *InstancePtr, UINTPTR BaseAddress) {
	XStage3_pipeline_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XStage3_pipeline_top_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XStage3_pipeline_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XStage3_pipeline_top_Config *XStage3_pipeline_top_LookupConfig(u16 DeviceId) {
	XStage3_pipeline_top_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSTAGE3_PIPELINE_TOP_NUM_INSTANCES; Index++) {
		if (XStage3_pipeline_top_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XStage3_pipeline_top_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XStage3_pipeline_top_Initialize(XStage3_pipeline_top *InstancePtr, u16 DeviceId) {
	XStage3_pipeline_top_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XStage3_pipeline_top_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XStage3_pipeline_top_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

