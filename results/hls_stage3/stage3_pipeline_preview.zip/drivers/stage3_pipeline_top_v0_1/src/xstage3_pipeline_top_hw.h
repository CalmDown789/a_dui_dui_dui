// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of input_channels
//        bit 4~0 - input_channels[4:0] (Read/Write)
//        others  - reserved
// 0x14 : reserved
// 0x18 : Data signal of rows
//        bit 15~0 - rows[15:0] (Read/Write)
//        others   - reserved
// 0x1c : reserved
// 0x20 : Data signal of cols
//        bit 15~0 - cols[15:0] (Read/Write)
//        others   - reserved
// 0x24 : reserved
// 0x28 : Data signal of rounding_mode
//        bit 1~0 - rounding_mode[1:0] (Read/Write)
//        others  - reserved
// 0x2c : reserved
// 0x30 : Data signal of enable_saturation
//        bit 0  - enable_saturation[0] (Read/Write)
//        others - reserved
// 0x34 : reserved
// 0x38 : Data signal of map00
//        bit 1~0 - map00[1:0] (Read/Write)
//        others  - reserved
// 0x3c : reserved
// 0x40 : Data signal of map01
//        bit 1~0 - map01[1:0] (Read/Write)
//        others  - reserved
// 0x44 : reserved
// 0x48 : Data signal of map10
//        bit 1~0 - map10[1:0] (Read/Write)
//        others  - reserved
// 0x4c : reserved
// 0x50 : Data signal of map11
//        bit 1~0 - map11[1:0] (Read/Write)
//        others  - reserved
// 0x54 : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_AP_CTRL                0x00
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_GIE                    0x04
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_IER                    0x08
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ISR                    0x0c
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_INPUT_CHANNELS_DATA    0x10
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_INPUT_CHANNELS_DATA    5
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ROWS_DATA              0x18
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_ROWS_DATA              16
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_COLS_DATA              0x20
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_COLS_DATA              16
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ROUNDING_MODE_DATA     0x28
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_ROUNDING_MODE_DATA     2
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_ENABLE_SATURATION_DATA 0x30
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_ENABLE_SATURATION_DATA 1
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP00_DATA             0x38
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_MAP00_DATA             2
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP01_DATA             0x40
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_MAP01_DATA             2
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP10_DATA             0x48
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_MAP10_DATA             2
#define XSTAGE3_PIPELINE_TOP_CONTROL_ADDR_MAP11_DATA             0x50
#define XSTAGE3_PIPELINE_TOP_CONTROL_BITS_MAP11_DATA             2

