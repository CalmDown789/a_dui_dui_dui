"""Portable entry around the unchanged 2026-10-09 simulation driver."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import sys
import tempfile

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('small','stress','full'),default='small')
    parser.add_argument('--vivado-root',type=Path)
    parser.add_argument('--temp-root',type=Path)
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args()
    manifest=load(HERE/'PACKAGE_MANIFEST.json')
    for entry in manifest['files']:
        path=(HERE/entry['file']).resolve()
        assert path.is_relative_to(HERE.resolve()), 'Manifest path escape'
        assert path.is_file() and path.stat().st_size==entry['bytes'] and sha(path)==entry['sha256'], 'Changed package file: '+entry['file']
    identity=load(HERE/'VERSION_IDENTITY.json')
    assert identity['candidate_id']=='R0_QAT_EMA_seed20261006_v2'
    driver_path=HERE/'verification_sources/run_candidate_sim_20261009.py'
    spec=importlib.util.spec_from_file_location('ema_original_driver',driver_path)
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    small=args.mode!='full'
    values=(32,18,4) if small else (960,540,2)
    stress=1 if args.mode=='stress' else 0
    generated=driver.make_tb(*values,stress,stress,small).replace('\n',os.linesep).encode('utf-8')
    assert hashlib.sha256(generated).hexdigest()==identity['modes'][args.mode]['TB_sha256'], 'Historical TB changed'
    assert driver.CORE_FILES==identity['RTL_compile_order'], 'Historical compile order changed'
    print('PACKAGE_AND_HISTORICAL_TB_IDENTITY_PASS mode='+args.mode,flush=True)
    if args.check_only:return
    assert args.vivado_root is not None, '--vivado-root is required for a simulation'
    vivado=args.vivado_root.resolve()
    assert all((vivado/'bin'/name).is_file() for name in ('xvlog.bat','xelab.bat','xsim.bat')), 'Vivado simulator tools missing'
    temp_root=(args.temp_root or Path(tempfile.gettempdir())).resolve()
    assert str(temp_root).isascii(), 'Choose an ASCII --temp-root, e.g. C:\\pld_tmp'
    temp_root.mkdir(parents=True,exist_ok=True)
    tempfile.tempdir=str(temp_root)
    driver.EXP=HERE
    driver.PACKAGE=HERE/'candidate_assets'
    driver.RTL=HERE/'RTL_sources'
    driver.VIVADO=vivado
    sys.argv=[str(driver_path),args.mode]
    driver.main()
    pointer=load(HERE/f'LATEST_{args.mode}.json')
    receipt=load(Path(pointer['saved'])/'RECEIPT.json')
    expected=identity['toolchain']['xsim_header_required']
    assert receipt['status']=='PASS'
    assert all(any(token in line for line in receipt['simulator_header']) for token in expected), 'Tool build differs from historical run'
    report={'status':'PASS_PORTABLE_ENTRY_SAME_RTL_ROM_TB_AND_TOOL_BUILD',
            'candidate_id':identity['candidate_id'],'mode':args.mode,
            'RTL_snapshot_sha256':identity['RTL_snapshot_sha256'],
            'saved_directory':pointer['saved'],'stage_checks':len(receipt['layer_results']),
            'mismatch_elements':sum(item['mismatch_elements'] for item in receipt['layer_results']),
            'scope':'XSim numerical replay only; no synthesis, BIT or hardware IO'}
    (Path(pointer['saved'])/'PORTABLE_ENTRY_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
