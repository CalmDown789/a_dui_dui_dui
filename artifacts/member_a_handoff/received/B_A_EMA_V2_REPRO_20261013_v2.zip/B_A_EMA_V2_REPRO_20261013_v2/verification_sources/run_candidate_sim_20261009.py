from pathlib import Path
from datetime import datetime, timezone, timedelta
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time

EXP = Path(__file__).resolve().parent
ROOT = EXP.parents[1]
PACKAGE = EXP / 'received/A_to_B_return_R0_QAT_EMA_20261009_v2'
RTL = ROOT / 'output/B_TO_A_20261008_v2/reference/rtl'
VIVADO = Path('F:/Xilinx/2025.2/Vivado')
CORE_FILES = 'same_pad_raster.sv window_kminus1_bram.sv window_stream_frontend.sv eight_phase_issue.sv pixel_shuffle2x_row_banks.sv fsrcnn_network_mem_top.sv elastic_fifo.sv phase_mac_pipeline.sv phase_accumulator_36.sv mac_issue_stage.sv vector_postprocess_shared.sv fsrcnn_stream_layer.sv fsrcnn_network_core.sv prelu_requantize.sv'.split()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def make_tb(width, height, frames, stall, reset_mid, layer_dump):
    header = '''`timescale 1ns/1ps
module tb_candidate;
 localparam IMG_W=@W@,IMG_H=@H@,FRAMES=@F@,STALL=@S@,RESET_MID=@R@;
 localparam N=IMG_W*IMG_H,M=4*N;
 reg clk=0,rst_n=0,start=0,iv=0,orr=1;always #3.333 clk=~clk;
 reg [7:0] id=0,inputs[0:N-1],golden[0:M-1];
 wire ir,ov,busy,done,sl,fl;wire[7:0] od;
 integer cycle=0,frame=0,ic=0,oc=0,sc=0,stall_out=0,fh,timing,events;
 reg active=0,held=0;reg[9:0] held_data;
 fsrcnn_network_mem_top #(.IMG_W(IMG_W),.IMG_H(IMG_H),.STRIPE_ROWS(64)) dut(
 .clk_200(clk),.rst_n(rst_n),.start(start),.busy(busy),.done(done),.in_valid(iv),.in_ready(ir),.in_data(id),
 .out_valid(ov),.out_ready(orr),.out_data(od),.stripe_last(sl),.frame_last(fl));
 always @(negedge clk)begin
  orr=(STALL==0)||((cycle%19>5)&&!(cycle%8192>=2000&&cycle%8192<2600));
 end
'''
    for key,value in (('@W@',width),('@H@',height),('@F@',frames),('@S@',stall),('@R@',reset_mid)):
        header = header.replace(key,str(value))
    monitors = ''
    if layer_dump:
        monitors += ''' integer input_f,input_count;
 always @(posedge clk)if(active&&rst_n)begin
  if(start&&!busy)input_count=0;
  if(iv&&ir)begin $fwrite(input_f,"%c%c",id,8'd0);input_count=input_count+1;end
  if(done&&input_count!=N)$fatal(1,"input stage count");
 end
'''
        for index,name,channels,lanes,outbits,wire_name,ready_name in (
            (1,'feature',16,2,16,'d1','r1'), (2,'shrink',8,1,16,'d2','r2'),
            (3,'mapping0',8,1,16,'d3','r3'), (4,'expand',16,2,16,'d4','r4'),
            (5,'subpixel',4,1,8,'d5','r5')):
            monitors += f' integer {name}_f,{name}_af,{name}_count,{name}_acount,{name}_ch;\n'
            for lane in range(lanes):
                monitors += f' wire [31:0] {name}_a{lane}=dut.core.l{index}.post.units[{lane}].post.prelu_value_s4;\n'
            monitors += f''' always @(posedge clk)if(active&&rst_n)begin
 if(start&&!busy)begin {name}_count=0;{name}_acount=0;end
 if(dut.core.v{index}&&dut.core.{ready_name})begin
 for({name}_ch=0;{name}_ch<{channels};{name}_ch={name}_ch+1)begin
'''
            if outbits==16:
                monitors += f' $fwrite({name}_f,"%c%c",dut.core.{wire_name}[{name}_ch*16+:8],dut.core.{wire_name}[{name}_ch*16+8+:8]);\n'
            else:
                monitors += f' $fwrite({name}_f,"%c",dut.core.{wire_name}[{name}_ch*8+:8]);\n'
            monitors += f' end {name}_count={name}_count+1;end\n'
            monitors += f' if(dut.core.l{index}.post.units[0].post.valid_s4)begin\n'
            for lane in range(lanes):
                monitors += f' $fwrite({name}_af,"%c%c%c%c",{name}_a{lane}[7:0],{name}_a{lane}[15:8],{name}_a{lane}[23:16],{name}_a{lane}[31:24]);\n'
            monitors += f' {name}_acount={name}_acount+{lanes};end\n'
            monitors += f' if(done&&({name}_count!=N||{name}_acount!=N*{channels}))$fatal(1,"{name} stage count out=%0d accum=%0d",{name}_count,{name}_acount);\n end\n'
    control = '''
 always @(posedge clk)begin
  if(!rst_n)begin cycle=0;held=0;ic=0;oc=0;end
  else begin
   cycle=cycle+1;
   if(active)begin
    if(held&&(!ov||{fl,sl,od}!==held_data))$fatal(1,"output hold violation");
    held=ov&&!orr;held_data={fl,sl,od};
    if(start&&!busy)begin sc=cycle;ic=0;oc=0;stall_out=0;end
    if(iv&&ir)ic=ic+1;
    if(ov&&!orr)stall_out=stall_out+1;
    if(ov&&orr)begin
     if(oc>=M||od!==golden[oc])$fatal(1,"Candidate final mismatch frame=%0d offset=%0d actual=%02x expected=%02x",frame,oc,od,golden[oc]);
     if(fl !== (oc==M-1))$fatal(1,"frame_last mismatch");
     if(sl !== (((oc+1)%(2*IMG_W*64)==0)||(oc==M-1)))$fatal(1,"stripe_last mismatch");
     $fwrite(fh,"%c",od);oc=oc+1;
     if(oc%(2*IMG_W*64)==0||oc==M)begin
      $display("CANDIDATE_PROGRESS frame=%0d out_bytes=%0d cycle=%0d",frame,oc,cycle);
      $fflush(fh);$fdisplay(events,"%0d,%0d,%0d",frame,oc,cycle);$fflush(events);
     end
    end
    if(done)begin
     if(ic!=N||oc!=M)$fatal(1,"frame count mismatch");
     $fdisplay(timing,"%0d,%0d,%0d,%0d,%0d,%0d",frame,sc,cycle,cycle-sc,oc,stall_out);$fflush(timing);
     $display("CANDIDATE_FRAME_PASS frame=%0d cycles=%0d output_bytes=%0d output_stall=%0d",frame,cycle-sc,oc,stall_out);
    end
   end else if(iv&&ir)ic=ic+1;
  end
 end
 initial begin
  timing=$fopen("timing.csv","w");events=$fopen("events.csv","w");
  $fdisplay(timing,"frame,start,done,cycles,output_bytes,output_stall");
  $fdisplay(events,"frame,output_bytes,cycle");
  repeat(10)@(negedge clk);rst_n=1;
  if(RESET_MID)begin
   $readmemh("input_0.hex",inputs);@(negedge clk);start=1;@(negedge clk);start=0;iv=1;id=inputs[0];
   repeat(400)begin @(negedge clk);if(ic<N)id=inputs[ic];else iv=0;end
   $display("CANDIDATE_RESET_IN_FLIGHT input_accepted=%0d busy=%0d",ic,busy);
   rst_n=0;iv=0;start=0;repeat(10)@(negedge clk);rst_n=1;
  end
  for(frame=0;frame<FRAMES;frame=frame+1)begin
   $readmemh($sformatf("input_%0d.hex",frame),inputs);$readmemh($sformatf("golden_%0d.hex",frame),golden);
   fh=$fopen($sformatf("actual_%0d.bin",frame),"wb");
   @OPEN_STAGES@
   active=1;@(negedge clk);start=1;@(negedge clk);start=0;iv=1;id=inputs[0];
   while(ic<N)begin @(negedge clk);if(ic<N)id=inputs[ic];else iv=0;end
   wait(done);@(negedge clk);@(negedge clk);$fclose(fh);
   @CLOSE_STAGES@
   active=0;
  end
  $display("CANDIDATE_NUMERIC_PASS W=%0d H=%0d FRAMES=%0d STALL=%0d RESET_MID=%0d",IMG_W,IMG_H,FRAMES,STALL,RESET_MID);$finish;
 end
 initial begin #500000000;$fatal(1,"Candidate watchdog");end
endmodule
'''
    open_stages,close_stages='',''
    if layer_dump:
        open_stages += 'input_f=$fopen($sformatf("actual_input_%0d.bin",frame),"wb");\n'
        close_stages += '$fclose(input_f);\n'
        for name in ('feature','shrink','mapping0','expand','subpixel'):
            stage = 'subpixel_phases' if name=='subpixel' else name
            open_stages += f'{name}_f=$fopen($sformatf("actual_{stage}_%0d.bin",frame),"wb");\n'
            open_stages += f'{name}_af=$fopen($sformatf("actual_{name}_accum_%0d.bin",frame),"wb");\n'
            close_stages += f'$fclose({name}_f);$fclose({name}_af);\n'
    return header+monitors+control.replace('@OPEN_STAGES@',open_stages).replace('@CLOSE_STAGES@',close_stages)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('mode',choices=('small','stress','full'))
    args=ap.parse_args()
    identity=json.loads((EXP/'IDENTITY_ROM_REPORT.json').read_text(encoding='utf-8'))
    assert identity['status']=='IDENTITY_INTERFACE_CHECKPOINT_EXPORT_AND_19_ROM_PASS'
    small=args.mode!='full'
    width,height,frames=(32,18,4) if small else (960,540,2)
    stall,reset_mid=(1,1) if args.mode=='stress' else (0,0)
    run=Path(tempfile.mkdtemp(prefix=f'pld_a_ema_{args.mode}_'))
    assert str(run).isascii()
    saved=EXP/'runs'/run.name
    saved.mkdir(parents=True)
    sources=[]
    def copy(source,name=None):
        name=name or source.name
        shutil.copyfile(source,run/name)
        sources.append({'source':str(source),'name':name,'source_sha256':sha(source),'copy_sha256':sha(run/name)})
    for name in CORE_FILES:
        copy(RTL/name)
    for path in sorted((EXP/'candidate_rom').glob('*.mem')):
        copy(path)
    cases=('zero','impulse','gradient','random') if small else ('frame_0000','frame_0001')
    vectors=[]
    for index,case in enumerate(cases):
        directory=PACKAGE/('vectors/32x18/'+case if small else 'vectors/full_frames/'+case)
        spec=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
        input_path=directory/('input_y_u8.bin' if small else spec['input_file'])
        golden_path=directory/('output_hwc_uint8.bin' if small else spec['candidate_output_file'])
        copy(input_path,f'input_{index}.bin');copy(golden_path,f'golden_{index}.bin')
        for name,path in (('input',input_path),('golden',golden_path)):
            (run/f'{name}_{index}.hex').write_text(''.join(f'{b:02x}\n' for b in path.read_bytes()),encoding='ascii')
        vectors.append({'index':index,'case':case,'input_sha256':sha(input_path),'golden_sha256':sha(golden_path),'manifest_sha256':sha(directory/'manifest.json')})
    (run/'tb_candidate.sv').write_text(make_tb(width,height,frames,stall,reset_mid,small),encoding='utf-8')
    (run/'run.tcl').write_text('run all\nquit\n',encoding='ascii')
    copy(Path(__file__))
    commands=[[str(VIVADO/'bin/xvlog.bat'),'-sv']+CORE_FILES+['tb_candidate.sv'],
              [str(VIVADO/'bin/xelab.bat'),'--debug','off','--mt','off','--timescale','1ns/1ps','tb_candidate','-s','snapshot'],
              [str(VIVADO/'bin/xsim.bat'),'snapshot','--tclbatch','run.tcl']]
    receipt={'status':'RUNNING','candidate_id':identity['candidate_id'],'checkpoint_sha256':identity['checkpoint_sha256'],
             'quant_params_sha256':identity['quant_params_sha256'],'mode':args.mode,'ASCII_run_directory':str(run),
             'saved_directory':str(saved),'geometry':[width,height],'frames':frames,'stall':stall,'reset_mid':reset_mid,
             'clock_hz_nominal':150000000,'TB_period_ns':6.666,'vectors':vectors,'sources':sources,
             'TB_sha256':sha(run/'tb_candidate.sv'),'commands':[], 'created_local':datetime.now(timezone(timedelta(hours=8))).isoformat()}
    def save():
        (saved/'RECEIPT.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (EXP/f'LATEST_{args.mode}.json').write_text(json.dumps({'run':str(run),'saved':str(saved)},indent=2),encoding='utf-8')
    save();print(f'RUN={run}\nSAVED={saved}',flush=True)
    env=os.environ.copy();env['APPDATA']=str(run/'appdata');(run/'appdata').mkdir()
    try:
        for index,command in enumerate(commands):
            log=saved/f'{index+1}_{Path(command[0]).stem}.log'
            begin=time.perf_counter()
            with log.open('wb') as stream:
                process=subprocess.Popen(command,cwd=run,env=env,stdout=stream,stderr=subprocess.STDOUT)
                receipt['active_process']={'pid':process.pid,'argv':command,'started_local':datetime.now(timezone(timedelta(hours=8))).isoformat()};save()
                code=process.wait(timeout=21600)
            receipt['commands'].append({'argv':command,'exit_code':code,'wall_seconds':time.perf_counter()-begin,'log':str(log)})
            save();print(f'STEP={index+1} EXIT={code}',flush=True)
            assert code==0, f'Tool failure: {log}'
        text=log.read_text(encoding='utf-8',errors='replace')
        assert 'CANDIDATE_NUMERIC_PASS' in text and 'Fatal:' not in text and 'ERROR:' not in text, f'Missing PASS: {log}'
        results=[]
        for index,case in enumerate(cases):
            directory=PACKAGE/('vectors/32x18/'+case if small else 'vectors/full_frames/'+case)
            spec=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
            entries=[entry for entry in spec['files'] if entry['stage']!='input_source'] if small else [{'file':spec['candidate_output_file'],'stage':'output','dtype':'uint8','shape':spec['candidate_output_shape_hwc']}]
            for entry in entries:
                stage=entry['stage']
                actual=run/(f'actual_{index}.bin' if stage=='output' else f'actual_{stage}_{index}.bin')
                expected=directory/entry['file']
                a,b=actual.read_bytes(),expected.read_bytes()
                size={'int16':2,'int32':4,'uint8':1}[entry['dtype']]
                assert len(a)==len(b), f'Length mismatch {case}/{stage}'
                mismatch_elements=sum(a[offset:offset+size]!=b[offset:offset+size] for offset in range(0,len(a),size))
                first=next((offset//size for offset in range(0,len(a),size) if a[offset:offset+size]!=b[offset:offset+size]),None)
                result={'case':case,'stage':stage,'dtype':entry['dtype'],'shape_hwc':entry['shape'],'bytes':len(a),
                        'mismatch_elements':mismatch_elements,'first_mismatch_element':first,
                        'actual_sha256':sha(actual),'candidate_golden_sha256':sha(expected)}
                results.append(result)
        receipt['layer_results']=results
        assert all(x['mismatch_elements']==0 for x in results), 'Layer mismatch; inspect layer_results'
        assert all(sha(Path(x['source']))==x['source_sha256'] for x in sources)
        receipt['status']='PASS';receipt['pass_lines']=[line for line in text.splitlines() if 'PASS' in line or 'RESET_IN_FLIGHT' in line]
        receipt['simulator_header']=(run/'xsim.log').read_text(encoding='utf-8',errors='replace').splitlines()[:5]
    except Exception as exc:
        receipt['status']='FAIL';receipt['error']=str(exc);raise
    finally:
        outputs=[]
        for path in sorted(run.iterdir()):
            if path.is_file():
                shutil.copyfile(path,saved/path.name)
                outputs.append({'name':path.name,'bytes':path.stat().st_size,'sha256':sha(path)})
        receipt['files']=outputs;receipt.pop('active_process',None);save()
        print('STATUS='+receipt['status'],flush=True)

if __name__=='__main__':main()
