`timescale 1ns/1ps
module tb_candidate;
 localparam IMG_W=960,IMG_H=540,FRAMES=2,STALL=0,RESET_MID=0;
 localparam N=IMG_W*IMG_H,M=4*N;
 reg clk=0,rst_n=0,start=0,iv=0,orr=1;always #3.333 clk=~clk;
 reg [7:0] id=0,inputs[0:N-1],golden[0:M-1];
 wire ir,ov,busy,done,sl,fl;wire[7:0] od;
 integer cycle=0,frame=0,ic=0,oc=0,sc=0,stall_out=0,fh,timing,events;
 reg active=0,held=0;reg[9:0] held_data;
 fsrcnn_network_mem_top #(.IMG_W(IMG_W),.IMG_H(IMG_H),.STRIPE_ROWS(64)) dut(
 .clk_200(clk),.rst_n(rst_n),.start(start),.busy(busy),.done(done),.in_valid(iv),.in_ready(ir),.in_data(id),
 .out_valid(ov),.out_ready(orr),.out_data(od),.stripe_last(sl),.frame_last(fl));
 always @(negedge clk)begin
  orr=(STALL==0)||((cycle%19>5)&&!(cycle%8192>=2000&&cycle%8192<2600));
 end

 always @(posedge clk)begin
  if(!rst_n)begin cycle=0;held=0;ic=0;oc=0;end
  else begin
   cycle=cycle+1;
   if(active)begin
    if(held&&(!ov||{fl,sl,od}!==held_data))$fatal(1,"output hold violation");
    held=ov&&!orr;held_data={fl,sl,od};
    if(start&&!busy)begin sc=cycle;ic=0;oc=0;stall_out=0;end
    if(iv&&ir)ic=ic+1;
    if(ov&&!orr)stall_out=stall_out+1;
    if(ov&&orr)begin
     if(oc>=M||od!==golden[oc])$fatal(1,"Candidate final mismatch frame=%0d offset=%0d actual=%02x expected=%02x",frame,oc,od,golden[oc]);
     if(fl !== (oc==M-1))$fatal(1,"frame_last mismatch");
     if(sl !== (((oc+1)%(2*IMG_W*64)==0)||(oc==M-1)))$fatal(1,"stripe_last mismatch");
     $fwrite(fh,"%c",od);oc=oc+1;
     if(oc%(2*IMG_W*64)==0||oc==M)begin
      $display("CANDIDATE_PROGRESS frame=%0d out_bytes=%0d cycle=%0d",frame,oc,cycle);
      $fflush(fh);$fdisplay(events,"%0d,%0d,%0d",frame,oc,cycle);$fflush(events);
     end
    end
    if(done)begin
     if(ic!=N||oc!=M)$fatal(1,"frame count mismatch");
     $fdisplay(timing,"%0d,%0d,%0d,%0d,%0d,%0d",frame,sc,cycle,cycle-sc,oc,stall_out);$fflush(timing);
     $display("CANDIDATE_FRAME_PASS frame=%0d cycles=%0d output_bytes=%0d output_stall=%0d",frame,cycle-sc,oc,stall_out);
    end
   end else if(iv&&ir)ic=ic+1;
  end
 end
 initial begin
  timing=$fopen("timing.csv","w");events=$fopen("events.csv","w");
  $fdisplay(timing,"frame,start,done,cycles,output_bytes,output_stall");
  $fdisplay(events,"frame,output_bytes,cycle");
  repeat(10)@(negedge clk);rst_n=1;
  if(RESET_MID)begin
   $readmemh("input_0.hex",inputs);@(negedge clk);start=1;@(negedge clk);start=0;iv=1;id=inputs[0];
   repeat(400)begin @(negedge clk);if(ic<N)id=inputs[ic];else iv=0;end
   $display("CANDIDATE_RESET_IN_FLIGHT input_accepted=%0d busy=%0d",ic,busy);
   rst_n=0;iv=0;start=0;repeat(10)@(negedge clk);rst_n=1;
  end
  for(frame=0;frame<FRAMES;frame=frame+1)begin
   $readmemh($sformatf("input_%0d.hex",frame),inputs);$readmemh($sformatf("golden_%0d.hex",frame),golden);
   fh=$fopen($sformatf("actual_%0d.bin",frame),"wb");
   
   active=1;@(negedge clk);start=1;@(negedge clk);start=0;iv=1;id=inputs[0];
   while(ic<N)begin @(negedge clk);if(ic<N)id=inputs[ic];else iv=0;end
   wait(done);@(negedge clk);@(negedge clk);$fclose(fh);
   
   active=0;
  end
  $display("CANDIDATE_NUMERIC_PASS W=%0d H=%0d FRAMES=%0d STALL=%0d RESET_MID=%0d",IMG_W,IMG_H,FRAMES,STALL,RESET_MID);$finish;
 end
 initial begin #500000000;$fatal(1,"Candidate watchdog");end
endmodule
