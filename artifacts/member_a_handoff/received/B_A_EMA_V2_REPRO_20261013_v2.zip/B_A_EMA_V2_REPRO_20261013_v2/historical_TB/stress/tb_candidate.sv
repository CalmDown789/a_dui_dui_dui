`timescale 1ns/1ps
module tb_candidate;
 localparam IMG_W=32,IMG_H=18,FRAMES=4,STALL=1,RESET_MID=1;
 localparam N=IMG_W*IMG_H,M=4*N;
 reg clk=0,rst_n=0,start=0,iv=0,orr=1;always #3.333 clk=~clk;
 reg [7:0] id=0,inputs[0:N-1],golden[0:M-1];
 wire ir,ov,busy,done,sl,fl;wire[7:0] od;
 integer cycle=0,frame=0,ic=0,oc=0,sc=0,stall_out=0,fh,timing,events;
 reg active=0,held=0;reg[9:0] held_data;
 fsrcnn_network_mem_top #(.IMG_W(IMG_W),.IMG_H(IMG_H),.STRIPE_ROWS(64)) dut(
 .clk_200(clk),.rst_n(rst_n),.start(start),.busy(busy),.done(done),.in_valid(iv),.in_ready(ir),.in_data(id),
 .out_valid(ov),.out_ready(orr),.out_data(od),.stripe_last(sl),.frame_last(fl));
 always @(negedge clk)begin
  orr=(STALL==0)||((cycle%19>5)&&!(cycle%8192>=2000&&cycle%8192<2600));
 end
 integer input_f,input_count;
 always @(posedge clk)if(active&&rst_n)begin
  if(start&&!busy)input_count=0;
  if(iv&&ir)begin $fwrite(input_f,"%c%c",id,8'd0);input_count=input_count+1;end
  if(done&&input_count!=N)$fatal(1,"input stage count");
 end
 integer feature_f,feature_af,feature_count,feature_acount,feature_ch;
 wire [31:0] feature_a0=dut.core.l1.post.units[0].post.prelu_value_s4;
 wire [31:0] feature_a1=dut.core.l1.post.units[1].post.prelu_value_s4;
 always @(posedge clk)if(active&&rst_n)begin
 if(start&&!busy)begin feature_count=0;feature_acount=0;end
 if(dut.core.v1&&dut.core.r1)begin
 for(feature_ch=0;feature_ch<16;feature_ch=feature_ch+1)begin
 $fwrite(feature_f,"%c%c",dut.core.d1[feature_ch*16+:8],dut.core.d1[feature_ch*16+8+:8]);
 end feature_count=feature_count+1;end
 if(dut.core.l1.post.units[0].post.valid_s4)begin
 $fwrite(feature_af,"%c%c%c%c",feature_a0[7:0],feature_a0[15:8],feature_a0[23:16],feature_a0[31:24]);
 $fwrite(feature_af,"%c%c%c%c",feature_a1[7:0],feature_a1[15:8],feature_a1[23:16],feature_a1[31:24]);
 feature_acount=feature_acount+2;end
 if(done&&(feature_count!=N||feature_acount!=N*16))$fatal(1,"feature stage count out=%0d accum=%0d",feature_count,feature_acount);
 end
 integer shrink_f,shrink_af,shrink_count,shrink_acount,shrink_ch;
 wire [31:0] shrink_a0=dut.core.l2.post.units[0].post.prelu_value_s4;
 always @(posedge clk)if(active&&rst_n)begin
 if(start&&!busy)begin shrink_count=0;shrink_acount=0;end
 if(dut.core.v2&&dut.core.r2)begin
 for(shrink_ch=0;shrink_ch<8;shrink_ch=shrink_ch+1)begin
 $fwrite(shrink_f,"%c%c",dut.core.d2[shrink_ch*16+:8],dut.core.d2[shrink_ch*16+8+:8]);
 end shrink_count=shrink_count+1;end
 if(dut.core.l2.post.units[0].post.valid_s4)begin
 $fwrite(shrink_af,"%c%c%c%c",shrink_a0[7:0],shrink_a0[15:8],shrink_a0[23:16],shrink_a0[31:24]);
 shrink_acount=shrink_acount+1;end
 if(done&&(shrink_count!=N||shrink_acount!=N*8))$fatal(1,"shrink stage count out=%0d accum=%0d",shrink_count,shrink_acount);
 end
 integer mapping0_f,mapping0_af,mapping0_count,mapping0_acount,mapping0_ch;
 wire [31:0] mapping0_a0=dut.core.l3.post.units[0].post.prelu_value_s4;
 always @(posedge clk)if(active&&rst_n)begin
 if(start&&!busy)begin mapping0_count=0;mapping0_acount=0;end
 if(dut.core.v3&&dut.core.r3)begin
 for(mapping0_ch=0;mapping0_ch<8;mapping0_ch=mapping0_ch+1)begin
 $fwrite(mapping0_f,"%c%c",dut.core.d3[mapping0_ch*16+:8],dut.core.d3[mapping0_ch*16+8+:8]);
 end mapping0_count=mapping0_count+1;end
 if(dut.core.l3.post.units[0].post.valid_s4)begin
 $fwrite(mapping0_af,"%c%c%c%c",mapping0_a0[7:0],mapping0_a0[15:8],mapping0_a0[23:16],mapping0_a0[31:24]);
 mapping0_acount=mapping0_acount+1;end
 if(done&&(mapping0_count!=N||mapping0_acount!=N*8))$fatal(1,"mapping0 stage count out=%0d accum=%0d",mapping0_count,mapping0_acount);
 end
 integer expand_f,expand_af,expand_count,expand_acount,expand_ch;
 wire [31:0] expand_a0=dut.core.l4.post.units[0].post.prelu_value_s4;
 wire [31:0] expand_a1=dut.core.l4.post.units[1].post.prelu_value_s4;
 always @(posedge clk)if(active&&rst_n)begin
 if(start&&!busy)begin expand_count=0;expand_acount=0;end
 if(dut.core.v4&&dut.core.r4)begin
 for(expand_ch=0;expand_ch<16;expand_ch=expand_ch+1)begin
 $fwrite(expand_f,"%c%c",dut.core.d4[expand_ch*16+:8],dut.core.d4[expand_ch*16+8+:8]);
 end expand_count=expand_count+1;end
 if(dut.core.l4.post.units[0].post.valid_s4)begin
 $fwrite(expand_af,"%c%c%c%c",expand_a0[7:0],expand_a0[15:8],expand_a0[23:16],expand_a0[31:24]);
 $fwrite(expand_af,"%c%c%c%c",expand_a1[7:0],expand_a1[15:8],expand_a1[23:16],expand_a1[31:24]);
 expand_acount=expand_acount+2;end
 if(done&&(expand_count!=N||expand_acount!=N*16))$fatal(1,"expand stage count out=%0d accum=%0d",expand_count,expand_acount);
 end
 integer subpixel_f,subpixel_af,subpixel_count,subpixel_acount,subpixel_ch;
 wire [31:0] subpixel_a0=dut.core.l5.post.units[0].post.prelu_value_s4;
 always @(posedge clk)if(active&&rst_n)begin
 if(start&&!busy)begin subpixel_count=0;subpixel_acount=0;end
 if(dut.core.v5&&dut.core.r5)begin
 for(subpixel_ch=0;subpixel_ch<4;subpixel_ch=subpixel_ch+1)begin
 $fwrite(subpixel_f,"%c",dut.core.d5[subpixel_ch*8+:8]);
 end subpixel_count=subpixel_count+1;end
 if(dut.core.l5.post.units[0].post.valid_s4)begin
 $fwrite(subpixel_af,"%c%c%c%c",subpixel_a0[7:0],subpixel_a0[15:8],subpixel_a0[23:16],subpixel_a0[31:24]);
 subpixel_acount=subpixel_acount+1;end
 if(done&&(subpixel_count!=N||subpixel_acount!=N*4))$fatal(1,"subpixel stage count out=%0d accum=%0d",subpixel_count,subpixel_acount);
 end

 always @(posedge clk)begin
  if(!rst_n)begin cycle=0;held=0;ic=0;oc=0;end
  else begin
   cycle=cycle+1;
   if(active)begin
    if(held&&(!ov||{fl,sl,od}!==held_data))$fatal(1,"output hold violation");
    held=ov&&!orr;held_data={fl,sl,od};
    if(start&&!busy)begin sc=cycle;ic=0;oc=0;stall_out=0;end
    if(iv&&ir)ic=ic+1;
    if(ov&&!orr)stall_out=stall_out+1;
    if(ov&&orr)begin
     if(oc>=M||od!==golden[oc])$fatal(1,"Candidate final mismatch frame=%0d offset=%0d actual=%02x expected=%02x",frame,oc,od,golden[oc]);
     if(fl !== (oc==M-1))$fatal(1,"frame_last mismatch");
     if(sl !== (((oc+1)%(2*IMG_W*64)==0)||(oc==M-1)))$fatal(1,"stripe_last mismatch");
     $fwrite(fh,"%c",od);oc=oc+1;
     if(oc%(2*IMG_W*64)==0||oc==M)begin
      $display("CANDIDATE_PROGRESS frame=%0d out_bytes=%0d cycle=%0d",frame,oc,cycle);
      $fflush(fh);$fdisplay(events,"%0d,%0d,%0d",frame,oc,cycle);$fflush(events);
     end
    end
    if(done)begin
     if(ic!=N||oc!=M)$fatal(1,"frame count mismatch");
     $fdisplay(timing,"%0d,%0d,%0d,%0d,%0d,%0d",frame,sc,cycle,cycle-sc,oc,stall_out);$fflush(timing);
     $display("CANDIDATE_FRAME_PASS frame=%0d cycles=%0d output_bytes=%0d output_stall=%0d",frame,cycle-sc,oc,stall_out);
    end
   end else if(iv&&ir)ic=ic+1;
  end
 end
 initial begin
  timing=$fopen("timing.csv","w");events=$fopen("events.csv","w");
  $fdisplay(timing,"frame,start,done,cycles,output_bytes,output_stall");
  $fdisplay(events,"frame,output_bytes,cycle");
  repeat(10)@(negedge clk);rst_n=1;
  if(RESET_MID)begin
   $readmemh("input_0.hex",inputs);@(negedge clk);start=1;@(negedge clk);start=0;iv=1;id=inputs[0];
   repeat(400)begin @(negedge clk);if(ic<N)id=inputs[ic];else iv=0;end
   $display("CANDIDATE_RESET_IN_FLIGHT input_accepted=%0d busy=%0d",ic,busy);
   rst_n=0;iv=0;start=0;repeat(10)@(negedge clk);rst_n=1;
  end
  for(frame=0;frame<FRAMES;frame=frame+1)begin
   $readmemh($sformatf("input_%0d.hex",frame),inputs);$readmemh($sformatf("golden_%0d.hex",frame),golden);
   fh=$fopen($sformatf("actual_%0d.bin",frame),"wb");
   input_f=$fopen($sformatf("actual_input_%0d.bin",frame),"wb");
feature_f=$fopen($sformatf("actual_feature_%0d.bin",frame),"wb");
feature_af=$fopen($sformatf("actual_feature_accum_%0d.bin",frame),"wb");
shrink_f=$fopen($sformatf("actual_shrink_%0d.bin",frame),"wb");
shrink_af=$fopen($sformatf("actual_shrink_accum_%0d.bin",frame),"wb");
mapping0_f=$fopen($sformatf("actual_mapping0_%0d.bin",frame),"wb");
mapping0_af=$fopen($sformatf("actual_mapping0_accum_%0d.bin",frame),"wb");
expand_f=$fopen($sformatf("actual_expand_%0d.bin",frame),"wb");
expand_af=$fopen($sformatf("actual_expand_accum_%0d.bin",frame),"wb");
subpixel_f=$fopen($sformatf("actual_subpixel_phases_%0d.bin",frame),"wb");
subpixel_af=$fopen($sformatf("actual_subpixel_accum_%0d.bin",frame),"wb");

   active=1;@(negedge clk);start=1;@(negedge clk);start=0;iv=1;id=inputs[0];
   while(ic<N)begin @(negedge clk);if(ic<N)id=inputs[ic];else iv=0;end
   wait(done);@(negedge clk);@(negedge clk);$fclose(fh);
   $fclose(input_f);
$fclose(feature_f);$fclose(feature_af);
$fclose(shrink_f);$fclose(shrink_af);
$fclose(mapping0_f);$fclose(mapping0_af);
$fclose(expand_f);$fclose(expand_af);
$fclose(subpixel_f);$fclose(subpixel_af);

   active=0;
  end
  $display("CANDIDATE_NUMERIC_PASS W=%0d H=%0d FRAMES=%0d STALL=%0d RESET_MID=%0d",IMG_W,IMG_H,FRAMES,STALL,RESET_MID);$finish;
 end
 initial begin #500000000;$fatal(1,"Candidate watchdog");end
endmodule
