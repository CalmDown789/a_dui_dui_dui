# 物理 I/O 与启动身份边界

本次没有新增硬件操作；以下为确切 EMA BIT/DCP 和恢复 R0 的既有证据整理。

- 平台 ACX750-200T / xc7a200tfbg484-2，core 150 MHz，pause0，16 行条带；EVF1 输入、EVF2 显式协商推送输出。
- B 原 79 输入、14 数值 RTL、19 ROM 和源 XDC 未变；物理实现优化链单独保留。C 重开确切 EMA DCP 的数字门禁通过；数字实现使用有条件板级 I/O 包络，不能代表电气合规。
- EMA 新启动和恢复冻结 R0 的 UART 审计各有两个一致 PHY0 状态记录；配置/身份/页恢复和 DONE 条件成立，PHY RX delay=1、TX delay=0。
- 恢复 R0 的 BIT SHA 为 cefe3ba044bb208a08969714f48144870f5c00efc6879edb063ac1f358ef1ea5，DCP SHA 为 47e5a1ece0b669fa45597ab3ae4b7ca826fc1857cd8c3d43d4a7d009a84b68da。原 JTAG 成功退出，独立审计范围是 LAB_STARTUP_IDENTITY_OBSERVED_ONLY，不是完整配置读回。
- 引脚/IO 标准/XDC/时钟/DDR 双沿等资料引用原候选清单及独立数字审查，原告警/waiver 均保留。启动与功能收发正确不能覆盖 RGMII 电压/波形/眼图、板级真实时序或温压角验收。

结论：物理电气 UNVERIFIED；真实面板刷新 NOT_MEASURED。当前材料没有可作为本次签核的仪器波形或扫描输出观测。本单未运行示波器/线侧捕获/显示刷新测量，不能宣称设备已经测过或不存在。

如需要后续物理签核，应先核实实际板卡原理图、供电与 IO 电平条件和可用探测设备，制定针对性观测点、时基和判据；设备不足则列明依赖。不能靠增加 Golden 样本、改变 PHY 延时或放宽 XDC 补签。
