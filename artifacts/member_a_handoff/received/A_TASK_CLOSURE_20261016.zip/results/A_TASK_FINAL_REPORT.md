# 给 A：R0 整机联调与 EMA v2 独立上板评估汇总

日期：2026-10-16（Asia/Shanghai）。本报告合并既有工作并补做保存帧的离线后处理/显示，不是本次新做整机板测。评估材料已整理；纯核计时、物理电气与真实面板刷新仍未完成，持续 4K30 未达标。

## 结论

1. 冻结 R0：C 10/15 留存在线结果表明 EVF1 输入/EVF2 显式协商推送输出已接通 A 正式 PC4K 与预览；758 帧逐帧零差、零重试/重复/缺帧。本次核对 CSV、源帧/模型身份、4K参考哈希及阶段均值一致。**原始 journal、accepted/outputs 事件文件当前迁移副本中缺失，未找到完整 10/15 封存包，因此本次不能重审这 758 帧的原始协议。** 原始审计声明与本次复核范围严格区分。
2. EMA v2：原 19 ROM/14 数值 RTL 身份对应 C 综合→B 150 MHz 物理实现→独立 BIT；C 10/16 新进程重开确切 DCP 与 Natural8 实板8帧通过。本次重新由保存 raw 还原8帧，共16,588,800字节与原输出及候选Golden零差。
3. 本次新增 EMA PC4K：固定 A CPU 参考与已有 CUDA 后端，对同8个保存板帧生成3840×2160 Y8，共66,355,200像素，失配0；无预热、不增加板测样本。全部4K PNG无损读回验证，首末帧raw保存。
4. 本次新增显示：已生成图像的8帧离线 Tk 回放、72个widget取样像素、末帧4K保存/哈希和有限退出通过。用户在本聊天确认“看到了，显示正常”。这不是EMA在线视频、实时处理吞吐或物理面板刷新证明。
5. 正式R0未替换；原EMA测试后的确切冻结R0恢复和独立启动身份审计保留。本次只读核对冻结/EMA BIT、DCP四项SHA一致，没有新Vivado、JTAG、串口或网络板测，也没有推送/发送消息。

## 各层结果与归属

| 项目 | 结果 | 归属/范围 |
|---|---|---|
| EMA数值RTL | C原portable small/stress/full 98项零差、两帧4,147,200字节一致 | C 10/14既有数值复现，本次不重新仿真 |
| 150 MHz实现资源 | LUT45250、FF76724、BRAM Tile221、DSP394 | B原最终route结果，不称C本次综合 |
| 数字时序 | WNS/WHS/WPWS +0.015/+0.040/+0.264ns；TNS/THS/TPWS均0 | C 10/16确切DCP新进程审查；48指定路径、114685已布线网络、16Gray偏斜路径 |
| CDC | CDC-3 Info9、CDC-9 Info7、CDC-15 Warning224保留 | 不是CDC零告警 |
| EMA实板Natural8 | 8帧16,588,800字节零差，正常零重复、HELLO重试0 | C 10/16板测；本次离线raw还原再次一致 |
| R0连续帧 | 60秒600帧约10.0002fps，零缺帧/重试/重复 | C 10/15留存在线结果；当前仅CSV/摘要可复核 |
| R0 30fps排程 | 150帧11.6291245秒，约12.898649fps；149个输入槽迟到 | 所有尾帧计入；最终帧齐全不等于按30fps完成 |
| PC4K合同 | Keys a=-0.5、half-pixel、边界复制、float64、ties-away、饱和Y8 | A固定参考SHA及同语义CUDA；R0/EMA模型和数据各自绑定 |
| EMA当前PC4K计时 | CPU call wall 8帧均值397.3353ms；CUDA首帧9777.9180ms，后7帧9.7021—14.4839ms | 当前环境、无预热、仅已有8帧；冷启动保留，不能代替独立稳态预算 |
| 物理I/O | UART配置/身份/RX1-TX0有观察；电气未签核 | 有条件I/O包络的数字通过不替代仪器/板级签核 |
| 纯FPGA计算/真实面板刷新 | 未测 | 主机协议时间不相减推算纯核；窗口提交不等于扫描输出 |

R0原在线预览1280×720；本次回放显示960×540缩放预览，完整4K图像保存为3840×2160 Y8。Tk报告桌面几何2560×1440仅作环境信息，不能据此声称真实4K面板展示。

当前后处理运行时：Python 3.12.10、NumPy 2.5.2、Torch 2.14.0+cu130（CUDA 13.0），GPU NVIDIA GeForce RTX 5080 Laptop GPU。旧100帧PC预算属旧环境，不能与本次短样本混算。CPU/CUDA差异对拍为本次新运行，数值实现源码未改。

## 身份与恢复

- A固定提交 cb0ad8549967c5306cc25f88023658918d0fe03d；正式后处理SHA 8ffa8363b6bbf0fcb2066f77ca0151ff4a31a43ea4dc2ed7e0cf97c207d011f6。
- EMA checkpoint 10867199deba770b8903e268bb4aa6775f0ad2036bab695790b6593cc01eeb6a；quant 12e6e26ea9770c7bf57ab3cc048328d845f2a6cbb6764441df0d7c74e50c2809。
- 19 ROM集合SHA 8ef151f70646dfa6f0aa38a6b07d9381aee65e4bb64ef57b47e82a08707912bd；14 RTL快照 B_RTL_SNAPSHOT_20261008_EMA_V2_NUMERIC_20261009，RTL commit=null，保留真实快照而非补造提交。
- A候选Natural8原ZIP SHA 1b8266493fec4c0df85da053ed5612d884a2c68f9ad6794017f1a2e8915209b7；源索引1440、1452、…、1524，PTS60…63.5秒。重复这些采样帧不是原生30fps视频。
- EMA BIT/DCP：3c290d2e0b278ce89033f985fa21aa0277017d12b5e695286fe8dbfcee40d3b2 / e091345b9146a80f6756cb08e52d49254fab2a13140c0f10d65bb3ec0408770a。
- 冻结R0 BIT/DCP：cefe3ba044bb208a08969714f48144870f5c00efc6879edb063ac1f358ef1ea5 / 47e5a1ece0b669fa45597ab3ae4b7ca826fc1857cd8c3d43d4a7d009a84b68da。
- 既有恢复JTAG exit0、UART先开、两份一致PHY0状态；审计LAB_STARTUP_IDENTITY_OBSERVED_ONLY，不是全量BIT读回。

## 本次证据与未完成项

主对应表 REQUIREMENTS_MATRIX.csv；来源/路径映射 PROVENANCE.json、PATH_MAPPING.json；R0/EMA各自PER_FRAME.csv及STAGE_TIMINGS.json；新EMA_PC4K/attempt01/EMA_NATURAL8_PC4K.json及逐帧表；DISPLAY/attempt01/GUI_STATUS.json、DISPLAY/HUMAN_OBSERVATION.json；TIMING_COVERAGE.md、PHYSICAL_IO_RESULT.md、EVIDENCE_GAPS.json。

原EMA四次失败和一次成功封存包在 ORIGINAL_ARCHIVES_INDEX.json。成功包SHA为89d6063e80cdb9165d2b13e3cf0d108cd77b6e63015621b1dcc631863de05ad9；本次核过SHA、CRC、174载荷成员和175个总成员，并逐项对照当前解包文件SHA。原失败包均保留并核过SHA/CRC。本次P0首次误把载荷数174当总成员数，失败/修正记录单独保留，未改原门槛、原件或旧收据。

尚未完成：①R0 10/15原始journal/事件档案的找回与原始层重审；②板端纯核周期实测；③物理I/O电气签核；④真实面板刷新实测；⑤持续整机4K30。已有结果可支持当前实验条件下EMA数字/8帧功能评估，不能提升为正式R0升版或无条件物理/性能验收。

如果必须补纯核数据，需新候选加入带帧身份的可信计数接口并完成相应回归/实现/板测；当前源码不改。如果要求电气/物理刷新证明，需具体仪器和观测方案。4K30性能优化另立工程任务，本单没有运行ACK/EVF3或跨帧实验。

报告和全部本次成功/失败材料封存至本目录 A_TASK_CLOSURE_20261016.zip；成员SHA/大小/CRC及ZIP外部收据以 A_TASK_CLOSURE_20261016.zip.receipt.json 为准。大原始包只索引引用，不重复复制；R0缺失原始材料不会被宣称已经封存齐全。本材料仅本地交付，未向A/B发送。
