# 当前状态 · 2026-10-16

2026-10-16 A 原委托收口：R0 10/15 留存在线758帧与原CSV/审计摘要已汇总核对；当前迁移副本未找到原始journal及accepted/outputs事件，不能宣称本次原始层重审。EMA 10/16保存raw本次重建8帧16,588,800字节零差；新增固定A正式CPU/CUDA离线4K对拍8帧66,355,200像素零差，Tk离线回放/保存/退出通过，用户确认画面正常。新环境CUDA冷启动首调用约9.778秒完整保留；短样本不作吞吐结论。本次无新Vivado/JTAG/网络板测，正式R0不替换；纯核/物理I/O/面板刷新未测或未签核，整机4K30未达。报告与缺证清单见 candidates/20261016_a_task_completion/results/A_TASK_FINAL_REPORT.md、EVIDENCE_GAPS.json。

2026-10-16 EMA v2 最新执行：B 留存时序报告与 C 本次独立 DCP 重开分别记录；C 门禁通过，WNS/WHS/WPWS +0.015/+0.040/+0.264 ns、TNS/THS/TPWS 0，48 指定路径、114685 全布线网络、16 条 Gray bus-skew，CDC-15 Warning 224。Natural8 实板 8 帧 16,588,800 字节 Golden 零差；独立原始审计及正常零重复门通过，HELLO 重试/输出重复均 0。随后按确切 SHA 恢复冻结 R0 并独立审计启动；正式 R0 未替换。物理 I/O 电气未签核，持续整机 4K30 未测/未达成。失败尝试与成功结果均已封存；最终 ZIP SHA256 `89d6063e80cdb9165d2b13e3cf0d108cd77b6e63015621b1dcc631863de05ad9`。详见 `candidates/20261016_b_ema_v2_execution_spec/results/RESULT.md`。

依据截至 2026-10-15 的绑定实验及用户澄清更新。ACK trace v3 最新同Realtek捕获模式A–B–A已复现：关闭/开启/关闭PktMon，64帧主机重试0/26/0，中段24 DATA+2 QUERY，全部Golden零差；首5个DATA各两帧合法GMII ACK而NIC/应用只收到一帧。捕获条件关联已得到恢复对照支持，具体物理/驱动根因仍未闭合，关闭后仍有输出窗口缺口。板卡已恢复确切冻结R0并独立审计启动，另一任务保持暂停。EMA v2 原portable入口三模式恢复全部通过，原异常保留；冻结R0的A自然8帧Golden零差。原始测量以候选目录报告、数据和身份清单为准。

## 当前基线与主线

- ACX750-200T / xc7a200tfbg484-2；Vivado 2025.2，core 150 MHz，pause=0，输出条带 16 行。
- FSRCNN d16/s8/m1/c16：960×540 Y8 输入 → 1920×1080 Y8 输出 → PC 双三次生成 3840×2160 Y8 → 缩放预览。
- 已验收延迟优化基线仍为 2026-10-09 四步整合 V2。本地 `output/C_TO_B_LATENCY_HANDOFF_V2_20261009/`，GitHub `deliverables/c_latency_v2_20261009/`。
- BIT SHA256：`cefe3ba044bb208a08969714f48144870f5c00efc6879edb063ac1f358ef1ea5`；DCP SHA256：`47e5a1ece0b669fa45597ab3ae4b7ca826fc1857cd8c3d43d4a7d009a84b68da`。
- input64 / batch1 / output128 是已测运行候选，未提升为冻结默认；当前 BIT 不支持 EVF3。
- **跨帧方案尚未正式交付。** 10 月 10 日已有单 RAM 设计/合同草案评审和隔离 RTL 实验，但不能据此宣布跨帧方案已完成、已实施或可验收。当前原分工 C03 主线等待正式方案；执行计划 C05/C06 为待方案/待新实现验收，整机 4K30 尚未达标。

## 已证实结果

- 2026-10-15 EMA v2 布线/时序交接 B：确切19 ROM、14份数值RTL与完整物理顶层已完成C新综合、布局及布局后优化，用户暂停时刚进入route_design第一阶段。只有带约束综合DCP（SHA `1487d5ddab1c19f5c441d6aae9cbd590ae94c89f3f8b2efa8f93d62d0bc2b0eb`）及前约束DCP保存；末次路由前估计WNS/TNS −0.147/−20.419ns、WHS/THS −3.781/−83.365ns，不是最终路由结论，无placed/routed DCP、新BIT或EMA板测。按用户要求打包给B接手，292文件ZIP SHA `a508ab98cba9ef8f24ed9271371393bc495686f488aa725d7ae6226460cf4f9b`，逐成员SHA/CRC及异地解压check-only通过，含从synth接续/源码重建入口、数值复现包、候选Golden及原始停止证据；本轮未恢复工具、未发送或同步。见 `candidates/20261015_ema_v2_b_timing_handoff/results/RESULT.md` / `00_HANDOFF.md`。

- 2026-10-15 冻结R0在线后处理接入：独立候选三组共758帧、1,571,788,800板端Y8字节raw审计Golden零差、零重试/重复/缺帧；A正式Keys a=-0.5 CPU参考与CUDA逐帧4K零差，保存预览像素核对通过。60秒600帧约10fps；30fps排程150帧实际11.629125秒、约12.899fps，未达4K30；源为自然8幅采样素材循环，非原生30fps视频。物理I/O、纯核时间和真实面板刷新未测。证据及逐帧CSV在 `candidates/20261015_r0_system_ema_v2/results/r0_attempt02/`，汇总 `results/R0_FINAL_STATUS.json`；该候选继续暂停，冻结交付未改。

- 2026-10-15 ACK重跑复现：同Realtek、原BIT/DCP/参数、三次新启动各2+64，唯一计划变化为PktMon关闭/开启/关闭；64帧主机重试0/26/0，中段24 DATA+2 QUERY，198帧410,572,800 Golden字节零差。原生Npcap共711,650包drop0并与应用完整匹配，B1 PktMon全部Rx也匹配且ETL EventsLost0；24 DATA重发前已有写入信用，首5个身份各五阶段2次及两帧有效GMII ACK。输出满128跨度缺口0/9/1，说明关闭后的零主机重试不代表输出首次发送无缺口。支持捕获负载/接收路径相关，尚不能给具体器件定责；All42/42和契约8/8沿用已绑定原收据。已恢复冻结R0、新UART/JTAG审计通过并释放资源。见 `candidates/20261015_ack_reproduction_v4/results/RESULT.md`；输出窗口/信用阻塞机制详见 `candidates/20261015_ack_deep_path_analysis/results/RESULT.md`。

- 2026-10-15 ACK 具体定位补充：旧 Npcap 脚本包头 ABI 错误已证实并在外置新脚本修复，原 PCAP 有效，不能据此归因原重试；原失败 post-JTAG PHY0 RX1/TX0 与页恢复读回通过。另一任务暂停后完成同版新启动 A–B–A：Realtek A1/A2 各2+64零重试/重复；Intel B1两帧Golden零差但EVF2/EVF3各1次HELLO重试，首批响应约52.9ms才到NIC，按门槛未进64帧，DATA重试0。三段134帧277,862,400 Golden字节零差，480,190捕获包drop0且与应用完整匹配；均无BTRC触发，原DATA ACK缺口仍未复现、根因UNPROVEN。已恢复Realtek专用IP/邻居及确切冻结R0镜像，并独立复核新UART/JTAG启动；另一任务未自动恢复。见 `candidates/20261015_ack_specific_fault_localization/results/RESULT.md`。

- 2026-10-15 ACK trace v3 Npcap 独立单轮及原因分析：完整 All 42/42、限定 trace 契约 8/8 和管理员 Preflight 通过；Natural2 零重试，Natural16/64 全部 Golden 正确但有 19 次 DATA + 1 次 QUERY 重试。19 个 DATA 在首次发送后 1.2012–1.3363 ms 的 CREDIT.W 已覆盖，重发前没有匹配 ACK；frame 20 / epoch 21 / seq 56、57 各有两次完整五阶段及两帧字节相同、FCS/头部有效的 GMII ACK。六阶段收敛计数均 33,481、XOR 与所有 DATA 发送的预期 ACK 一致，应用成功 ACK 33,462，差 19；聚合证据不替代其余身份逐包证明。针对该 19 个 DATA，PktMon 各 2 Tx / 1 ACK；Npcap 全局自身丢弃约 80.3%，不能充当线侧观测。按门槛未扩测，具体根因 `UNPROVEN`；板测封存 SHA `4f3e99e49c43c51285b6903975099c055ea4013e4cfd23d82d897dcfe91914b4`。最新分析及口径更正见 `candidates/20261015_ack_retry_cause_analysis/results/RESULT.md`，原件见 `candidates/20261015_b_ack_trace_v3_acceptance_npcap01/results/RESULT.md`。

- 2026-10-14 B ACK trace v3 阅读规划：新包19,316条目全部CRC正常，两层19,315/19,312项SHA与230项选择源码绑定通过；当前短项124、full95、物理97项输入与包内字节一致。C用包内审计器重审B留存原始仿真wire/UART，三帧6,220,800字节Golden零差、零输出重复，五路身份与1024条GMII窗口匹配；这不是C新RTL运行。所选新BIT `f8fae14c84d0963e7c253d58312c306fd8c89d252d837d3b43def41e0e69212d`、DCP `44ef7d418cc0fc501ac73928683931f0a853dda3df5bfea306cf2c6a45d8cad1`。B精确DCP重开收据报WNS/WHS +0.001/+0.009ns，含两条限定排空返回首级多周期契约；B统一整包All未执行，C All/重开DCP/新BIT板测均待执行，根因未闭合。旧指南/STEP3结果是旧镜像证据，冻结基线不升级。见 `candidates/20261014_b_ack_trace_v3_review/results/RESULT.md`。

- 2026-10-15 C ACK trace v3 execution：完整All在host_checks第2项停止（tool_diagnosis通过，host_checks因Python 3.12.10缺Pillow/PIL失败）；2/42项已尝试，发行文件复核未变。未进入DCP复核、UART/NIC或板测，ACK根因仍UNPROVEN。失败原件及188文件外部临时目录已校验复制，证据ZIP SHA256 `957bc4a9fcc84ed006a53dc60e28a7f5d4eecbec97e360a2e0e2b7d15cdb2285`。见 `candidates/20261014_b_ack_trace_v3_acceptance/results/RESULT.md`。
- 2026-10-14 EMA v2：首次三模式异常保留，xelab 返回 0 却有访问异常不能签核 PASS。诊断将共同 PC 定位到 nProtect GameGuard `npggNT64.des+0x2769`；无 EMA RTL 的延时最小 TB 同址崩溃，退出游戏后固定源 small 恢复，强烈支持本轮环境冲突。随后新独立解压、原 portable 入口 small/stress/full 各串行运行一次，全部严格 PASS：小图 96 项/full 2 项共 98 项零差，两帧 full 输出 4,147,200 字节一致；Vivado/XSim 2025.2 SW Build 6299465，full XSim 墙钟 3,190.554 秒。原包 158 项不变，快照/14 RTL/19 ROM及checkpoint/quant身份保持，commit=null。EMA v2 未综合/P&R/上板。最新结果 `candidates/20261014_ema_v2_repro_recovery/results/RESULT.md`；原失败和诊断分别在 `20261014_ema_v2_repro`、`20261014_ema_v2_failure_analysis`，不改写。
- 2026-10-14 冻结 R0 A 自然 8 帧：bbb_clip_01 源索引 1440…1524/PTS60…63.5秒，16份素材及确切冻结BIT/DCP复核，新UART/JTAG身份通过；8帧共16,588,800个Golden字节零差，独立原始journal审计及逐帧正常零重复门槛通过，重试（含HELLO）0。沿用冻结input16/output128、ACK batch32、nonblocking/sampled16；实际8帧协议循环609.541ms约13.125fps，单帧whole均值75.410ms，不与input64候选或持续4K30混算。8份新board_y8、源↔会话帧映射、SHA/CRC、journal、启动身份和阶段时间已封存。独立软件副本仅增加Natural8 lab调度，两份源码重新绑定；冻结transport/镜像/ROM不改。PC后处理、纯FPGA核时间、显示未测，物理I/O仍UNVERIFIED。见 `candidates/20261014_r0_natural8_board_test/results/RESULT.md`；当前板卡已临时配置回确切冻结R0镜像。

- 同 BIT 输入扩窗：20 个成功 case 共 360 帧 Golden 零差；四轮平衡对照中，input64 的实际 Natural16 协议循环约 21.224 fps，input128 约 21.186 fps 且长尾较大。首次 JTAG 失败保留。见 `candidates/20261010_input_window_plan/results/RESULT.md`。
- input64 长期复核：32 个完整原 Run，共 512 个 Natural16、64 个 Natural2，1,194,393,600 个 Golden 字节零差；逐 case 正常零重复门槛通过。Natural16 按实际协议循环累计约 20.479 fps；保留 2 次主机失败和 1 次用户中断，不是连续无失败启动。见 `candidates/20261010_input64_followup/results/RESULT.md`。
- 当前 BIT 的 PC4K：150 个输入槽全部协议完成，4K 逐像素参考零差，实际约 7.304 秒，生成/预览提交约 20.536 fps。完成 150 槽不代表达到 30 fps；应用提交和 Tk 像素检查不代表真实面板刷新。
- 逐调用/轻量 GC 诊断均有 16 帧审计通过。轻量样本最大末输出 RX 至 FINAL TX 间隔 2.7602 ms，间隔内无 GC，未复现原 12.3267 ms 长尾；根因仍未确定，不能从 PC 日志归因 NIC、USB 或物理链路。
- 冻结 V2 数字实现最终 setup/hold 余量 +0.018/+0.050 ns，DRC 无 error/critical；物理 I/O 仍 UNVERIFIED。数字时序、配置读回、协议/Golden、PC4K 与真实显示分别验收。

- 2026-10-12 B ACK pressure v1：首次实板 Natural16 64 帧有 1 次输入重试并停止；此后 3 次完整离线入口复跑均在 tb_bxf_ack_pressure_fix 停止，包身份、Preflight 和主机检查通过，xsim 3/3 记录 0 ps FATAL_ERROR。一次在 PASS/$finish 后再报错并挂起，两次步骤 3 非零退出；均未到完整 CNN 原线、DCP 或新 Capture，板卡重试复现性未测。全部失败包及补充包通过校验，详见候选最终报告与证据索引。
- 2026-10-13 B ACK debug v2：输入包、8141 项清单、BIT/DCP 身份通过核对；本机 Preflight、Tools、离线 All（29 项命令）通过且包内源码未变。两轮同 BIT 实板 2+64：第一轮正常门槛通过，第二轮 Natural16 64 帧有 10 次重试，Golden 零差但正常门槛失败，依计划停止。NIC ACK 载荷与应用 journal 一致；第二轮 ACKD 六阶段计数 33,472，应用共 33,462，关注身份在 NIC 与应用均各出现一次。10 个总量差与重试数量吻合但没有逐包阶段记录，根因未证实；未运行第三轮、512/PC4K、真实显示或物理 I/O 验收。两份原始 Attempt 及逐文件校验通过的证据 ZIP 均保留，见 `candidates/20261013_ack_debug_v2_test_plan/results/EXECUTION_RESULT.md`。
- 10 月 13 日后续只读分析：frame 4 / epoch 5 / sequence 166–175 在重发前已实际写入，CREDIT W=182272 覆盖其末尾 180224；成功 ACK 仅在重发后于 NIC 出现。全部 DATA 发送对应的 ACK 总数/指纹与六阶段相符，NIC 全部入向协议载荷与应用 journal 精确一致。证据最支持 ACK 回程缺口，重点为 ACK 封装及 GMII 观测到 NIC 捕获之间的路径；聚合 XOR、缺少逐包时限及完整 MAC/IP 头，仍不能确定具体根因或完全排除异常延迟。见 `candidates/20261013_ack_debug_v2_failure_analysis/results/RESULT.md`。
- 10 月 13 日网卡 A–B–A：现有 ACK debug v2 BIT、同线缆、新 JTAG、固定 2+64；A1 Realtek 的 64 帧有 2 次重试、Golden 零差，B1 I226-V 链路正常但 ARP 无应答、Rx0且未进入帧传输，A2 恢复 Realtek 后 2+64 零重试通过。未定位根因，B1 不是有效 ACK 行为样本；NIC 未见失败身份在重试前到达，C 接收分支未触发。隔离 ACK trace 源码的 4 个当前模块单元仿真通过，但 trace 开启端到端和完整 All 未签核；物理实现中间 WNS −1.024 ns，用户停止后无新 BIT。B 接手的 23 修改/10 新增源码覆盖层、完整基线、停止检查点和逐文件校验 ZIP 已生成，见 `candidates/20261013_b_ack_trace_handoff/results/RESULT.md`。

## 草案与已停止实验的边界

- 单 RAM 设计草案已做条件性环地址安全评审；合同 v1 (`0.1.0-draft`) 原包 SHA256 `260871da8610e8a75fced9fd95b3f82a6509307fb07fec61c77c9adbc5dcbc66`，离线控制模型 21/21、线协议 62 项、交叉检查 7 项通过。这些是实施评审输入，尚无正式方案交付/冻结或实板收益。
- C 隔离 RTL 第一阶段与系统接入实验保留：小尺寸读流及部分 contexts/TX/GMII 定向仿真通过；信用模块有 XSim elaboration 访问异常，完整 HELLO/STATE/CREDIT/主动信用通路未接齐。最新版综合包装器因目录错误判失败，post-synth WNS −1.629 ns、post-place WNS −2.898 ns；P&R 按用户要求停止，无最终 route、新 BIT 或板测。
- 原报告不改写，入口为 `20261010_single_ram_cross_frame_review`、`20261010_single_ram_contract_review`、`20261010_single_ram_rtl_phase1`、`20261010_single_ram_rtl_integration` 候选。既有实验不替代 B 的正式方案。

## 未完成项与下一步

ACK失败下一步：同Realtek启用PktMon已复现24 DATA+2 QUERY重试，关闭前后主机重试为0；关闭后仍有输出满窗口缺口，因此不能将PktMon认作所有异常的充分必要条件。优先围绕捕获负载、Realtek USB接收/调度路径排查，进一步器件定责需独立线侧观察或共同时间基准；具体RGMII/PHY/线缆/NIC/USB驱动责任仍`UNPROVEN`。正常验收避免叠加本次全包PktMon配置，并重建输出覆盖，不能以主机零重试/重复替代输出无缺口证明。最新复现见 `candidates/20261015_ack_reproduction_v4/results/RESULT.md`，原逐身份分析和封存保持不变。

2026-10-15 ACK triage V5 前置失败原因已证实并修正：Vivado 2025.2 的 `-version` 路径在 `rdiArgs.bat` 进入 version-only 后，由 `loader.bat` 输出版本并明确返回 1；原守卫误把该返回码当作 build 不符。隔离修正版要求精确 release 与 SW Build，并仅接受该查询路径的 0/1、记录退出码。`batch01_run002` 完成 OFF→COUNTERS→OFF，各段 2+64：A1/B1 零重试、零重复；A2 有 4 次 DATA 重试、零重复。198 帧 Golden 零差；三段 Npcap 均零 drop 且发送/接收负载与应用逐包匹配。A2 trace 完整（3,588条记录、1,024个GMII帧、无解析异常），输出覆盖记25次首部缺口恢复和1个满128跨度缺口；身份级分析最支持 ACK 回程在 GMII 后至 NIC 捕获前丢失或超时，但时钟未对齐、缺独立线侧捕获，具体根因仍 `UNPROVEN`。确切冻结 R0 BIT `cefe3ba044bb208a08969714f48144870f5c00efc6879edb063ac1f358ef1ea5` 恢复并通过独立启动身份审计；未新跑All、未签核物理I/O/视频/4K30。详见 `candidates/20261015_ack_triage_v5_vivado_guard_fix/results/GUARD_FIX_NOTE.md` 与 `candidates/20261015_ack_triage_v5_batch01_run002/results/RESULT.md`、`POST_SEAL_ANALYSIS.md` 和收据。当时没有自动开启下一批。

2026-10-15 ACK triage V5 后续 batch02 按审阅路由完成 OFF→HEADER80→OFF，各段 2+64。仅 B1 HEADER80 的64帧段出现2次 DATA重试；A1/A2 OFF为0，Golden全零差，Npcap drop0且与应用逐包匹配。B1 两个重试身份的 ACK 在 GMII trace 各出现两份有效FCS帧，PC捕获均只见重发后ACK；支持 GMII 后至 PC 接收截止点之间迟到/丢失，器件根因仍 UNPROVEN。B1 输出有23次头部缺口恢复及1个满128跨度缺口。BTRC 唯一告警的 tick 跳变与跨 Natural2/Natural16 长间隔后的 32 位 tx_clk125 回绕一致，解码器因此报单调性错误；原 ANALYSIS.json 保留 FAIL，帧序号连续、无帧结构异常。确切冻结 R0 恢复，未新跑All；此批已封存，当前不自动启动下一批。结果与证据见 candidates/20261015_ack_triage_v5_batch02/results/RESULT.md、POST_SEAL_ANALYSIS.md 及 ZIP 收据。

2026-10-15 ACK编号诊断版 B 交付包已整理：基于 B ACK trace v3 完整源发行包与 batch02 精简原始证据，明确 EVF3 ACK 实例号格式、RTL/主机/BTRC 修改范围、离线及完整实现验收；ZIP 570,175,641 bytes，SHA256 3874764ac7b9d933632148d4310fe86848505d633959482197233cc403e992ae。独立校验包内13项、12个载荷文件的 CRC/成员集合/字节数/SHA 均通过。当前仅交付材料，编号源码/BIT/DCP 尚待 B 实施；没有运行 RTL/软件测试或板测。入口 candidates/20261015_ack_numbering_b_handoff/results/RESULT.md。

低端模型执行入口：`candidates/20261014_b_ack_trace_v3_execution_spec/results/EXECUTION.md`，同目录执行套件ZIP含外置辅助脚本。S00—S08规定原完整All、限定约束复核、最多三轮fresh2+64、失败分流/续跑/封存；retry02已执行至首轮门槛失败并完成有界失败分析及证据封存，后续硬件路径诊断须另立任务。
1. 等待跨帧正式方案/实施交付，确认同版合同、资源、真实握手/信用、帧所有权与恢复边界；方案未到前，不恢复已停止实现，不向当前 BIT 发送 EVF3。
2. 新实现先完成真实 CNN 三帧/网络 Golden、完整物理顶层布局布线、150 MHz 时序及 CDC/DRC 审查，绑定新 BIT/DCP 后 C 再独立复核和板测；模型或 GMII OOC 不替代这些门槛。
3. 可独立继续准备 A 正式后处理同帧对拍、独立后处理预算、播放器/有界队列与恢复验收材料；当前约 20–21 fps 不关闭持续整机 4K30 门槛。
4. 两类主机停滞尚未全部查明：一次 Smoke 审计原生栈指向 SyncDisk 注入锁等待，另一次板卡 I/O 前 bootstrap 超时根因未证实。10 月 10 日按用户要求停止 AnyShare Family7 服务且未改 Automatic 配置；本轮未重新检查服务或建立性能因果关系。
5. 最终恢复矩阵、真实显示刷新、持续整机 4K30、公平软件比较、最终机器彩排和提交版冻结仍待验收。

给 B 的既有实施前材料见 `candidates/20261010_b_implementation_support/results/RESULT.md`：四窗口证据、条件性 I/O 来源和独立 C 差异已整理，原 ZIP/收据保留；先前没有发送材料，GitHub 文档同步不代表 B 已签收。

任务矩阵见 `C_TASK_STATUS.json`；计划入口在 `C:/Users/Administrator/Desktop/srtp/计划/PLD竞赛2026_C侧执行任务规划_20261007.md`，GitHub 镜像在 `workspace/plans/`；同步范围及本地原报告映射见 GitHub `workspace/evidence/20261010/INDEX.json`。冻结交付字节不变，旧 BOARD_PENDING 由最终收据补充。


- 2026-10-15 C ACK trace v3 独立重试：当前发行包完整离线 All 42/42 项通过、源码未变；精确 DCP 重开及限定 trace 数字契约 8/8 检查通过，WNS/WHS +0.001/+0.009 ns。Realtek/192.168.0.3/24、COM3、文件核验与 Preflight 匹配；但当前 Administrator 令牌非管理员，pktmon 两项均因拒绝访问退出5，按门槛未开始 UART/JTAG/NIC 捕获或实板短测，根因仍 UNPROVEN。新尝试证据包 11,025 文件、118,572,396 字节，SHA256 `21df90632bc0aa8239556fc19712230616fcb3575275e86abcb6a8d5bc8e9cca`；旧 Pillow 失败尝试及收据不变。后续需在管理员令牌下以新独立尝试重做 S04，再决定首轮2+64。结果：`candidates/20261015_b_ack_trace_v3_acceptance_retry01/results/RESULT.md`。

- 2026-10-15 C ACK trace v3 retry02：完整离线All 42/42、限定trace契约8/8和管理员Preflight通过，源码未变。首轮Natural2两帧Golden 4,147,200 bytes零差、0 output duplicate，但有2次DATA重试，按门槛停止且未启动Natural16 64帧。UART BTRC为WINDOW_SHORT（3,221条记录）；每个重试身份有两次core五阶段和两帧GMII ACK（118 bytes、FCS valid）。全会话应用日志6,822条有效EVF（Tx 1,166/Rx 5,656）；PktMon TX 1,652/RX 5,656。RX逐包负载SHA/计数完全一致；TX有81个哈希计数不等、净多486事件，事件源/实际线上发送数不明。ETL文本与同源pcapng逐方向/哈希/计数完全一致。没有共同时间基准或独立线缆捕获，不能把GMII ACK帧分配到NIC ACK或定位丢失点，根因UNPROVEN。前两份归档均复核为原SHA且保持不变；第三份补充包 `C_ACK_TRACE_V3_EVIDENCE_20261015T035325563530Z.zip` 已封存，11,133文件、143,532,404 bytes，SHA256 `56eaba9f815b37436416271f70b6440327552686d6656dce35ca649ff3f93f4c`。见 `candidates/20261015_b_ack_trace_v3_acceptance_retry02/results/RESULT.md` 与 `round_01/nic_capture/PKTMON_JOURNAL_CROSSCHECK.json`。
