# 必要历史

2026-10-16 A 原委托收口：R0 10/15 留存在线758帧与原CSV/审计摘要已汇总核对；当前迁移副本未找到原始journal及accepted/outputs事件，不能宣称本次原始层重审。EMA 10/16保存raw本次重建8帧16,588,800字节零差；新增固定A正式CPU/CUDA离线4K对拍8帧66,355,200像素零差，Tk离线回放/保存/退出通过，用户确认画面正常。新环境CUDA冷启动首调用约9.778秒完整保留；短样本不作吞吐结论。本次无新Vivado/JTAG/网络板测，正式R0不替换；纯核/物理I/O/面板刷新未测或未签核，整机4K30未达。报告与缺证清单见 candidates/20261016_a_task_completion/results/A_TASK_FINAL_REPORT.md、EVIDENCE_GAPS.json。

2026-10-16 EMA v2 S02失败原因已证实：执行套件直接比较JSON读回的list行与re.findall产生的tuple行，触发cdc_summary假阴性；只读复现12个字段仅类型比较失败，表示统一后数值和文本全部相同，74份审查报告/收据与封存ZIP一致。原门禁FAIL、原报告/套件/ZIP保留，未再启动Vivado或硬件，未补签通过。分析见 candidates/20261016_ema_v2_cdc_gate_failure_analysis/results/RESULT.md。

2026-10-16 EMA v2 C独立重开执行：S01文件核验通过；C新Vivado进程打开固定DCP并生成原始REVIEW.json（正向时序指标、48路径、114685布线网络及16条Gray偏斜路径）。最终S02门禁因独立重算CDC报告摘要与REVIEW.json字段不一致，状态FAIL_C_REOPEN_PRESERVE_REPORTS；按单停止，未运行S03—S05、未启动板卡或修改R0。S06封存76文件通过，ZIP SHA256 af1e7f9c5b49436ef44e0a187861b5b34973edf1d8c9e7b8361e86254c9dfad3。结论和证据索引见 candidates/20261016_b_ema_v2_execution_spec/results/RESULT.md。

10 月 15 日 ACK 编号诊断版 B 交付包：按 batch02 两个 DATA 重试身份的证据整理了新诊断协议合同、修改点、验收和 B 返回模板；包含当前 B 完整 v3 源发行包及精简 ACK_DIAG/BTRC/身份分析原始证据。ZIP SHA256 `3874764ac7b9d933632148d4310fe86848505d633959482197233cc403e992ae`，570,175,641 bytes；包内逐文件 SHA/大小、ZIP CRC 与成员集合校验通过。此步骤只封装材料，未改 B 源码、未运行测试或刷板；新编号 BIT/DCP 等待 B 实施。入口 `candidates/20261015_ack_numbering_b_handoff/results/RESULT.md`。

10 月 15 日 EMA v2 时序交接 B：用户暂停C物理实现后，改为要求将布线与收敛交B。C仅整理292文件交付ZIP并逐项校验，没有恢复Vivado/板测。包保留确切19 ROM、完整物理源/XDC、两个综合DCP、布局后至route初始停止日志及既有数值证据；最后估计setup/hold −0.147/−3.781ns，非最终route结果，无placed/routed DCP或候选BIT。提供从带约束synth DCP重新opt/place/route与源码重建入口，新适配脚本仅离线结构/制备核对；B需回传同版完整实现、时序/CDC/DRC/约束及BIT/DCP身份后C再验。冻结R0不替换，原件保持；交付包SHA256 `a508ab98cba9ef8f24ed9271371393bc495686f488aa725d7ae6226460cf4f9b`。入口 `candidates/20261015_ema_v2_b_timing_handoff/results/RESULT.md`。

10 月 15 日 ACK triage V5 HEADER80 后续批次：按审阅路由在同一 Realtek/BIT/DCP 下完成 OFF→HEADER80→OFF，各段2+64；只有HEADER80的64帧段出现2次DATA重试，关闭段为0，Golden零差、Npcap drop0并与应用逐包匹配。两个重试身份的ACK各在GMII trace出现两份有效FCS帧，PC只在重发后见到一个ACK，根因仍UNPROVEN。B1输出覆盖有23次头部缺口恢复和1个满128跨度缺口。BTRC的单调性告警与32位125MHz tick跨两次入口间长空档回绕一致；原始FAIL保留，帧序号连续且无帧异常。冻结R0恢复，未新跑All；证据包SHA256 7218c303238070c18851ddc8bf4a1e0e1bd6c782fa9e5e52f0efc6f142e110f7，分析见 candidates/20261015_ack_triage_v5_batch02/results/POST_SEAL_ANALYSIS.md。当前未启动后续批次。


10 月 15 日 ACK triage V5 前置失败诊断及修正批次：首批 PREFLIGHT 守卫失败的原因已从本机 Vivado 源码确认，`rdiArgs.bat` 的 `-version` 分支设置 `RDI_INVOKE_VERSION_ONLY`，`loader.bat` 打印版本后明确 `exit /b 1`；原控制器把预期的 1 误判为版本不符。新隔离控制器严格绑定 release/SW Build，仅对本机 version-only 查询接受 0/1，并记录退出码。用户要求排查修复后，以独立 `_run002` 完成 A1 OFF、B1 COUNTERS、A2 OFF，各 2+64。A1/B1 均零重试/重复；A2 64帧有4次DATA重试、Golden零差，触发停止门槛。共198帧Golden零差；Npcap各段drop0并与应用Tx/Rx负载及重数匹配。A2 trace 3,588条/1,024个GMII帧、无解析异常，输出覆盖有25次首部缺口恢复与1个满128跨度缺口。封存后身份级只读复核显示 frame 40 / epoch 41 / seq 65–68 各有两次 core 五阶段与两帧同哈希有效FCS的GMII ACK；NIC/应用只见一次ACK且均在重发后。证据最支持 GMII 后至 NIC 捕获前的 ACK 丢失或超时，但没有共同时间基准/独立线侧捕获，不能定责。确切冻结R0恢复及独立启动身份审计通过；All沿用旧收据、未新跑，物理I/O/视频/4K30未签核，ACK根因仍 `UNPROVEN`，没有自动开下一批。修复说明、执行结果和封存外补充见 `candidates/20261015_ack_triage_v5_vivado_guard_fix/results/GUARD_FIX_NOTE.md`、`candidates/20261015_ack_triage_v5_batch01_run002/results/RESULT.md` / `POST_SEAL_ANALYSIS.md` 和封存收据。

10 月 15 日 ACK捕获模式复现：用户要求进一步定位、必要时重跑；同Realtek/原ACK trace v3 BIT及参数，新启动各2+64，PktMon关闭/开启/关闭对应64帧主机重试0/26/0，中段24 DATA+2 QUERY。198帧410,572,800 Golden字节零差，711,650个原生Npcap包零捕获丢弃且与应用匹配，PktMon Rx亦匹配、ETL事件丢失0；首5个DATA身份各两帧有效GMII ACK，NIC/应用各仅一份，复现原ACK回程缺口。输出满128跨度缺口0/9/1，捕获条件关联得到恢复对照支持，但不能认作所有异常的充分必要条件或给USB/驱动/PHY直接定责。19:36恢复确切冻结R0，新UART/JTAG启动审计通过，另一任务保持暂停。原失败包不变，All沿用原绑定收据；结果 `candidates/20261015_ack_reproduction_v4/results/RESULT.md`。只读深度分析另证实原6组DATA故障与前一输出窗口缺口相邻，解释窗口背压限制输入信用，见 `candidates/20261015_ack_deep_path_analysis/results/RESULT.md`。

10 月 15 日 ACK 具体定位补充：旧抓包脚本包头 ABI 错误已在新外置工具修复，原 PCAP 有效，不能归因原 ACK 重试。用户暂停另一板测并切线后，同版 A–B–A 的 Realtek 两段各2+64零重试；Intel 在两帧因2次HELLO响应延迟失败，未进64帧，DATA重试0。三段全部480,190个捕获包零丢弃且与应用负载/重数匹配，原DATA ACK缺口仍未复现、根因开放；旧失败封存不变。结束后恢复原网络配置和确切冻结R0镜像，新UART/JTAG启动独立复核，未恢复或消息通知另一任务。入口 `candidates/20261015_ack_specific_fault_localization/results/RESULT.md`。

10 月 15 日 ACK 重试原因只读分析：独立 Npcap 单轮的总重试 20 更正细分为 19 DATA + 1 QUERY。19 个 DATA 在重发前均已被实际写入 CREDIT.W 覆盖；首两个故障身份各有五阶段及完整有效 GMII 原 ACK/重复 ACK，六阶段总计数及 XOR 又与全部 DATA 发送的预期 ACK 一致，应用 ACK 少 19。最支持 GMII 后至 NIC/应用接收前的 ACK 回程缺口，尚不能给物理链路或驱动定责；Npcap 自身大量丢弃限制其否定性证据。分析新增独立候选，封存原件保留，未新增板测或修改发行源码。入口 `candidates/20261015_ack_retry_cause_analysis/results/RESULT.md`。

10 月 14 日完整恢复与自然8板测：用户退出游戏并要求继续后，独立新解包原portable入口三模式串行严格PASS，98项数值零差；full一次运行约53.176分钟，原异常/诊断/恢复对照均保留，EMA v2仍仅离线数值验收。其后确切冻结R0镜像新UART/JTAG及A自然8板测通过，16,588,800字节零差、重试0，主机input16协议循环609.541ms约13.125fps；仅增加独立lab Natural8调度并重新绑定文件身份，不改冻结源码和交付。两个任务分别结果/证据ZIP，未综合新EMA镜像、未测PC后处理/显示/纯核时间、未发送或同步远端。入口 `candidates/20261014_ema_v2_repro_recovery/results/RESULT.md` 与 `candidates/20261014_r0_natural8_board_test/results/RESULT.md`。

10 月 14 日游戏退出恢复对照：用户正常退出游戏/客户端后，固定原 small RTL/ROM/TB/向量/工具参数，三步日志干净、48 项数值零差、模块采样未见 GameGuard。与同源加载组件时失败及延时最小 TB 同址异常构成恢复证据；本轮无需重启，组件内部机制未查。stress/full 尚未恢复验收，原失败/分析 ZIP 不改。见 `candidates/20261014_ema_v2_failure_analysis/results/RECOVERY_RESULT.md`。

10 月 14 日 EMA 异常分析补充：原 xelab 返回 0 却有访问异常，纠正“展开 PASS”的旧解释，原报告/收据/ZIP 不改。新加载模块采样定位共同 PC 为有效签名的第三方 nProtect GameGuard `npggNT64.des+0x2769`；隔离用户目录不消除，完全不含 EMA RTL 的延时最小 TB 同址崩溃。优先处理环境冲突，游戏正常退出后的固定源恢复对照待用户完成退出；不从 HDL 当时执行行或旧工具 PASS 直接定 RTL 根因。见 `candidates/20261014_ema_v2_failure_analysis/results/RESULT.md`。

10 月 14 日 EMA v2 独立复现：B 原包补齐 RTL 快照与 14 份文件哈希，commit 明确为 null；C 前检与身份核对全过，但三种原入口 XSim 均内核异常退出，历史 PASS 不替代 C 新结果，未改 Golden/RTL/工具选项求通过。原始失败日志和收据保留，冻结 R0 / EMA / 诊断镜像继续分离；冻结 R0 自然 8 帧本轮仅复核素材和设备准备，无板端输出/计时。入口 `candidates/20261014_ema_v2_repro/results/RESULT.md`。

| 阶段 | 保留结论 | 原始来源 |
| --- | --- | --- |
| 9 月模型与任务书 | d16/s8/m1/c16、稠密 L5 Conv16→4 + PixelShuffle×2、整数 Golden 与模型交付；任务书 v3.2.2 属于当时修订执行版 | A 仓库、`output/任务书v3.2.2_修订执行版.md`、对应 DOCX |
| 9 月 23 日失败调查 | 旧 2022.2 复现曾失败，排除过程和工具链问题有追溯价值；该失败不能代表后续源树 | 外部清理备份中的旧 `HANDOFF_CODEX.md`、`c_side/docs/` |
| 9 月 24 日 | 100 MHz 单帧 UART / Golden 通过；UART 约 22.43 秒是回传时间 | C 板测专项报告 |
| 9 月 26 日 | B 的 150/200 MHz 实验与 C 的板测不是同一验证层级 | `PROJECT_STATUS_SYNC_2026-10-03.md`，属于历史快照 |
| 10 月 8 日 | 流式通信、ACK 服务间隔与 PC4K 截止失败调查；精选原始证据已随 2026-10-16 工作区审计迁至 D 盘 | candidates/20261016_workspace_migration/results/preserved/20261008_operator/ |
| 10 月 9 日 | 四步整合新 BIT 及 512 帧实验成为当前延迟优化交接基线 | `output/C_TO_B_LATENCY_HANDOFF_V2_20261009/` |
| 10 月 10 日 | 同BIT输入扩窗360帧正常零重复/Golden通过；四轮对照64窗口约21.224fps，建议64/batch1/output128候选，128典型帧更快但长尾较大；首次JTAG失败与服务恢复保留，冻结默认未变 | `candidates/20261010_input_window_plan/results/RESULT.md`、`FINAL_STATUS.json` |
| 10 月 10 日后续中间快照 | 当时长测为320 Natural16 + 40 Natural2；两次主机启动/Smoke审计停滞均保留，后一次捕获SyncDisk注入与挂起线程的临界区阻塞。该行记录中间状态，后续完成情况见下一行 | `candidates/20261010_input64_followup/results/partial_review_01/RESULTS.json`、`recovery_stall_01/` |
| 10 月 10 日后续完成 | 32个完整Run共512 Natural16 + 64 Natural2零Golden差；当前BIT的150帧PC4K配对约20.536fps；轻量GC样本未复现12.3267ms长尾且未见间隔内GC，长尾根因仍未定。保留2次主机失败、1次用户中断；跨帧正式评审待B设计原文 | `candidates/20261010_input64_followup/results/RESULT.md`、`FINAL_STATUS.json`、`GC_LIGHT_REVIEW.json`、证据包SHA收据 |
| 10 月 10 日跨帧设计评审 | B单RAM设计原文到达；C核对12个RTL源与当前BIT/DCP，并独立验证消费信用地址不变量。结构可行性有条件通过；信用线格式、待启动COMMIT、启动握手和原B模型附件未闭合，未实现/上板 | `candidates/20261010_single_ram_cross_frame_review/results/RESULT.md`、`REVIEW_STATUS.json`、`C_RING_GEOMETRY_MODEL.json` |
| 10 月 10 日跨帧合同补交复核 | B补齐原三份附件、EVF3信用协议、上下文与启动/进展合同、离线模型；C复跑原脚本、21项控制模型、62项线协议、7项交叉检查并核对16份冻结RTL快照。草案可供同版评审，未实施RTL/新BIT/板测 | `candidates/20261010_single_ram_contract_review/results/RESULT.md`、原包SHA256 `260871da8610e8a75fced9fd95b3f82a6509307fb07fec61c77c9adbc5dcbc66` |
| 10 月 10 日跨帧 RTL 第一阶段 | 在隔离候选实现 ROM 物理基址/逻辑计数与真实 B 消费信用/整包预约/实际写指针；分别综合成功，读流小尺寸 XSim 干净通过；信用测试有 PASS 输出但 XSim elaboration 访问异常，未作干净签核。未集成、未出新 BIT 或上板 | `candidates/20261010_single_ram_rtl_phase1/results/RESULT.md`、`PHASE1_STATUS.json`、证据 ZIP SHA256 `d7e404ad92054f196a7d85725944b2bd2cfc0dce52e2888348ea450ec735d1b5` |

10 月 10 日跨帧系统候选及 B 实施补充：C 候选已有 GMII/三上下文/TX 接入和定向仿真；最新版综合包装器因目录错误失败、post-place WNS −2.898 ns，P&R 被用户停止，未出新 BIT。拟由 B 完成实现/时序，C 提供已有四窗口板测、条件性 I/O 和候选差异。冻结交接版/B main逐文件一致；物理 I/O仍UNVERIFIED。本轮仅整理材料，未运行硬件/Vivado。入口为 `candidates/20261010_b_implementation_support/results/RESULT.md`；补充 ZIP SHA256 `dcfabce1b7a3cc28387fe56e43c2b27e7e4d5d2e6ca69680117340cbec3a7fc6`；原始 RTL/日志在 `20261010_single_ram_rtl_integration/`。

10 月 11 日用户澄清与状态同步：跨帧方案尚未正式交付；10 月 10 日单 RAM 设计/合同草案、离线模型与已停止 C RTL 实验作为历史评审证据保留，不能冒充正式方案完成。当前主线等待正式方案，已有约 20–21 fps 正确链路与 150 槽 PC4K 结果保留；更新计划入口和维护分支，不合并 main 或 C/B 分支。本轮无新硬件/Vivado运行。

10 月 13 日 B ACK debug v2：包完整性、Preflight、Tools 与离线 All 全过，包内源码未变；两轮同版 BIT 的 2+64 板测中，首轮正常门槛通过，第二轮 64 帧 Golden 零差但有 10 次重试，按门槛停止。第二轮 10 个重复 DATA 身份在 NIC 与应用各有一个成功 ACK 观察，NIC ACK 载荷与应用日志一致；ACKD 六阶段比应用总数多 10，但没有逐包阶段身份，不能据总数相关性确定 ACK 缺失边界或物理根因。两份原始 Attempt 与封存 ZIP 保留；未运行第三轮及 512/PC4K。详见 `candidates/20261013_ack_debug_v2_test_plan/results/EXECUTION_RESULT.md`。

10 月 13 日 ACK 失败只读分析：重发前 CREDIT 的实际写入 W 已超过失败的 10 个 DATA 身份；全部发送按 ACK 语义计算的总数和 XOR 与六阶段一致，NIC 全部入向协议载荷与应用日志一致。最受证据支持的解释是 ACK 回程连续缺口，尚不能区分封装错误、GMII 后物理路径或 NIC 捕获前丢弃；聚合数据没有逐包时限，异常延迟仍未彻底排除。本轮未新增板测。入口为 `candidates/20261013_ack_debug_v2_failure_analysis/results/RESULT.md`。

10 月 13 日 ACK 回程 A–B–A 与 B 接手包：A1 Realtek 64 帧两次重试、Golden 零差；B1 I226-V 在 DATA 前因无 ARP/Rx 中止；A2 恢复 Realtek 后 2+64 正常门槛通过，具体根因未定位。隔离 trace 候选经过 4 个当前模块单元仿真，物理实现 best 中间 WNS −1.024 ns；用户要求停止优化，保留 checkpoint、原始日志和停止收据，无新 BIT/完整 All/B2 板测。其后只整理 B 交接包并做字节校验、源码重建和合成流解码验证，未恢复 Vivado/板测；入口 `candidates/20261013_b_ack_trace_handoff/results/RESULT.md`。旧镜像身份与新源码覆盖层分开绑定，既有 PASS 不能用于新候选签核。

2026-10-16 EMA v2：B回传原RTL/ROM物理优化最终候选，C文件/原报告复核支持B数字收敛（WNS/WHS +0.015/+0.040ns，48指定路径），保留祖先失败和正式R0。C本轮仅制作并离线核验低端模型执行套件，尚未新重开DCP或做EMA板测；后续严格按新DCP→候选自然8→恢复R0分层验收。见 `candidates/20261016_b_ema_v2_execution_spec/results/RESULT.md`。
2026-10-16 EMA v2 执行续报：修复仅落在 build 隔离套件副本，原固定套件 ZIP SHA 不变、门槛与配置未放宽。C 新进程确切 DCP 重开通过；Natural8 实板 8 帧 Golden 零差、正常零重复通过；随后按确切 BIT/DCP 恢复正式冻结 R0 并完成独立 UART 启动身份审计。R0 未替换；物理 I/O 电气仍未签核，PC4K/持续整机 4K30 未测/未达成。前四次类型/权限/编码预检失败及本次成功结果均保留并分别封存；最终证据 ZIP SHA256 `89d6063e80cdb9165d2b13e3cf0d108cd77b6e63015621b1dcc631863de05ad9`。详见 `candidates/20261016_b_ema_v2_execution_spec/results/RESULT.md`。

长期保留的口径：软件量化指标、仿真逐字节正确、数字时序通过、板上协议正确、PC4K 输出、真实显示和整机吞吐分别验收。理论 MAC/DSP、BRAM KiB 核算与综合/实现报告分别引用。输出整帧装不进板上 BRAM，条带/握手的容量边界按当前候选合同判断，不能沿用旧接口假设。

旧记录中的“不支持 UDP”“只有 Vivado 2022.2”“GitHub 不可访问”“全帧未通过”“没有板测”均有时间与源树边界，不能作为当前事实。
