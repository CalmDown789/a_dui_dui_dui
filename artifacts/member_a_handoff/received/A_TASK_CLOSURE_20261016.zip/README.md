# A 委托收口执行

2026-10-16，Asia/Shanghai。用户授权按 `../20261016_a_task_completion_plan/results/PLAN.md` 执行 P0—P5。

目标：核验现有 R0/EMA 证据、统一逐帧和阶段计时、使用已保存的 EMA 实板 Natural8 输出补做 A 正式 PC4K 数值对拍及离线显示证据，形成一份最终报告和可核验本地交付包。

冻结 R0 BIT/DCP SHA256：`cefe3ba044bb208a08969714f48144870f5c00efc6879edb063ac1f358ef1ea5` / `47e5a1ece0b669fa45597ab3ae4b7ca826fc1857cd8c3d43d4a7d009a84b68da`。

EMA BIT/DCP SHA256：`3c290d2e0b278ce89033f985fa21aa0277017d12b5e695286fe8dbfcee40d3b2` / `e091345b9146a80f6756cb08e52d49254fab2a13140c0f10d65bb3ec0408770a`。

验收：输入身份通过；R0/EMA 来源分开；新后处理只使用已有8帧，4K CUDA与固定A CPU参考逐像素零差；新离线回放/图像检查单独记录，不算新板测或持续吞吐；原失败证据与所有未测/未达标项保留；最终包成员SHA/CRC通过。入口脚本在 `build/`，结果在 `results/`。

不启动新 Vivado/JTAG/网络板测，不改 RTL、ROM、约束或正式 R0；不运行 ACK/EVF3，不扩大板测样本，不推送或发送消息。人工视觉/物理面板刷新/物理电气/纯核时间无证据时明确保留未完成状态。

执行结果：本轮可执行的收口工作已完成，入口 `results/A_TASK_FINAL_REPORT.md`，分项状态与缺口在 `results/FINAL_STATUS.json`、`results/REQUIREMENTS_MATRIX.csv`、`results/EVIDENCE_GAPS.json`。用户已确认本次离线窗口画面正常。原R0 10/15 raw/event档案未在当前迁移副本找到，不能宣称本次758帧原始层重审；物理/纯核/刷新及4K30限制仍保留。

交付包 `results/A_TASK_CLOSURE_20261016.zip`；外部SHA/字节/成员校验收据 `results/A_TASK_CLOSURE_20261016.zip.receipt.json`。新脚本在当前工作区执行，固定输入路径和既有结果路径均已记录，不承诺脱离所索引大型原包即可重新运行；已有结果目录不覆盖重跑。
