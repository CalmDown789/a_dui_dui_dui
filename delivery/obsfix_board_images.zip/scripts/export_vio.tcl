# Source in Vivado Hardware Manager AFTER programming matching BIT+LTX.
# No hardware connection/programming is performed by this file.
proc obs_probe {vio type port width} {
    set probes [get_hw_probes -of_objects $vio -filter "TYPE == $type && PROBE_PORT == $port"]
    if {[llength $probes]!=1} {error "expected one $type probe port $port; inspect LTX and report_property"}
    set p [lindex $probes 0]
    if {[get_property PROBE_PORT_BIT_COUNT $p]!=$width} {error "probe width mismatch at $port"}
    return $p
}
proc obs_hex {value} {
    set value [string map {_ ""} [string trim $value]]
    if {[regexp {^[0-9]+'h([0-9a-fA-F]+)$} $value -> digits]} {return "0x$digits"}
    if {[regexp {^0x[0-9a-fA-F]+$} $value]} {return $value}
    if {[regexp {^[0-9a-fA-F]+$} $value]} {return "0x$value"}
    error "unknown INPUT_VALUE representation: $value"
}
proc obs_export {csvfile} {
    if {[file exists $csvfile]} {error "preserving existing export"}
    set vios [get_hw_vios -filter {INSTANCE_NAME =~ *u_obs_vio*}]
    if {[llength $vios]!=1} {error "expected exactly one matching observation VIO"}
    set vio [lindex $vios 0]
    set ctrl [obs_probe $vio vio_output 0 5]
    refresh_hw_vio -update_output_values $vio
    set old [obs_hex [get_property OUTPUT_VALUE $ctrl]]
    if {[expr {($old & 16)!=0}]} {error "release pause before exporting snapshots"}
    set probes {}
    foreach port {0 1 2 3 4 5} width {256 256 256 166 1 5} {
        lappend probes [obs_probe $vio vio_input $port $width]
    }
    set fp [open $csvfile {WRONLY CREAT EXCL}]
    puts $fp "slot,p0,p1,p2,p3,valid,count"
    try {
        for {set slot 0} {$slot<16} {incr slot} {
            set_property OUTPUT_VALUE [format %02x $slot] $ctrl
            commit_hw_vio $ctrl
            after 10
            set stable 0
            for {set retry 0} {$retry<5} {incr retry} {
                refresh_hw_vio $vio
                set first {}; foreach p $probes {lappend first [obs_hex [get_property INPUT_VALUE $p]]}
                after 10
                refresh_hw_vio $vio
                set second {}; foreach p $probes {lappend second [obs_hex [get_property INPUT_VALUE $p]]}
                if {$first eq $second} {set stable 1;break}
            }
            if {!$stable} {error "snapshot did not stabilize; keep raw partial CSV"}
            puts $fp "$slot,[join $second ,]"
            flush $fp
        }
    } finally {
        close $fp
        # Export requires pause=0 and preserves original selected slot.
        set_property OUTPUT_VALUE [format %02x [expr {$old & 15}]] $ctrl
        commit_hw_vio $ctrl
    }
    puts "OBS_EXPORT_COMPLETE=$csvfile"
}

# Apply a bounded pause only on an independently gated pause=1 image.
# Call after the host has submitted a frame and the B core has started.
proc obs_pause_once {milliseconds} {
    if {![string is integer -strict $milliseconds] || $milliseconds<1 || $milliseconds>1000} {
        error "pause must be 1..1000ms"
    }
    set vios [get_hw_vios -filter {INSTANCE_NAME =~ *u_obs_vio*}]
    if {[llength $vios]!=1} {error "expected exactly one observation VIO"}
    set vio [lindex $vios 0]
    set ctrl [obs_probe $vio vio_output 0 5]
    refresh_hw_vio -update_output_values $vio
    set old [obs_hex [get_property OUTPUT_VALUE $ctrl]]
    if {[expr {$old & 16}]} {error "existing pause must be released first"}
    try {
        set_property OUTPUT_VALUE [format %02x [expr {($old & 15)|16}]] $ctrl
        commit_hw_vio $ctrl
        after $milliseconds
    } finally {
        set_property OUTPUT_VALUE [format %02x [expr {$old & 15}]] $ctrl
        commit_hw_vio $ctrl
    }
    puts "BOUNDED_PAUSE_RELEASED=${milliseconds}ms; verify forced_block_cycles>0 in completed snapshot"
}
