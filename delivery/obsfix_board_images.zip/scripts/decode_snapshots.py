"""Decode VIO CSV (slot,p0,p1,p2,p3,valid,count), retaining raw values."""
from pathlib import Path
import argparse,csv,json,re

def numeric(text):
    text=text.strip().replace('_','')
    if re.fullmatch(r'\d+',text): return int(text)
    m=re.fullmatch(r"(?:\d+)?'([hbd])([0-9a-fA-F]+)",text)
    if m:return int(m[2],{'h':16,'b':2,'d':10}[m[1]])
    if text.lower().startswith('0x'):return int(text,16)
    # Export Tcl always emits 0x-prefixed hex; bare API values are not guessed.
    raise ValueError('ambiguous numeric format: '+text)

def decode(row,mapping):
    widths=[256,256,256,166];shift=0;packed=0
    for i,w in enumerate(widths):
        value=numeric(row[f'p{i}']);assert 0<=value<(1<<w)
        packed|=value<<shift;shift+=w
    fields={f['name']:(packed>>f['lsb'])&((1<<f['width'])-1) for f in mapping['fields']}
    assert len(fields)==31 and mapping['width_bits']==934
    valid=numeric(row['valid']);count=numeric(row['count']);slot=int(row['slot'])
    assert 0<=count<=16 and valid in [0,1]
    if valid:assert fields['valid']==1 and fields['slot_index']==slot
    return dict(slot=slot,selected_valid=valid,snapshot_count=count,raw_hex='0x'+format(packed,'0234x'),fields=fields)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('csv');ap.add_argument('--map',default=str(Path(__file__).resolve().parents[1]/'contracts/signal_map.json'));ap.add_argument('--output',required=True);args=ap.parse_args()
    mapping=json.loads(Path(args.map).read_text(encoding='utf-8'))
    rows=[decode(row,mapping) for row in csv.DictReader(Path(args.csv).open(encoding='utf-8-sig'))]
    out=Path(args.output)
    if out.exists():raise SystemExit('Preserving existing output: '+str(out))
    out.write_text(json.dumps(dict(status='DECODED_NOT_BOARD_VALIDATED',records=rows),indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('DECODED',len(rows))
