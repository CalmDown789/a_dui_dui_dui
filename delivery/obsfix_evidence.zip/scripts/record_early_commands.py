from pathlib import Path
import json,re,datetime,hashlib
root=Path(__file__).resolve().parents[1]
for name,session in [('f100_p0_a01',89482),('f150_p0_a01',22041)]:
    stage=root/'impl'/name;dest=stage/'command_reconstructed.json'
    assert not dest.exists()
    log=(stage/'vivado.log').read_text(encoding='utf-8',errors='replace')
    jou=(stage/'vivado.jou').read_text(encoding='utf-8',errors='replace')
    assert re.search(r'^STAGE6_ROUTE_COMPLETE=',log,re.M)
    assert re.search(r'^INFO: \[Common 17-206\] Exiting Vivado at ',log,re.M)
    record=dict(status='TOOL_EXITED',command_line=re.search(r'^# Command line\s*:\s*(.+)$',jou,re.M)[1],start_journal=re.search(r'^# Start of session at:\s*(.+)$',jou,re.M)[1],end_log=re.search(r'^INFO: \[Common 17-206\] Exiting Vivado at (.+)$',log,re.M)[1],exit_code=0,exit_code_source=f'Original exec session {session} completion returned exit_code=0; first jobs invoked directly, not through later run_build wrapper',recorded=datetime.datetime.now().astimezone().isoformat(),record_kind='retrospective index of preserved original journal/log and original tool completion, not a contemporaneous command.json',journal_sha256=hashlib.sha256((stage/'vivado.jou').read_bytes()).hexdigest(),log_sha256=hashlib.sha256((stage/'vivado.log').read_bytes()).hexdigest())
    dest.write_text(json.dumps(record,indent=2),encoding='utf-8')
    print('EARLY_COMMAND_INDEX',name)
