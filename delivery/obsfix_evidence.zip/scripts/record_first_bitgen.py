from pathlib import Path
import json,re,datetime,hashlib
root=Path(__file__).resolve().parents[1];stage=root/'impl/f100_p0_a01'
dest=stage/'bitgen_command_reconstructed.json';assert not dest.exists()
log=(stage/'bitgen.log').read_text(encoding='utf-8',errors='replace');jou=(stage/'bitgen.jou').read_text(encoding='utf-8',errors='replace')
assert re.search(r'^BITGEN_GATES_PASS ',log,re.M) and re.search(r'^GATED_BITSTREAM_COMPLETE=',log,re.M)
r=dict(status='TOOL_EXITED',command_line=re.search(r'^# Command line\s*:\s*(.+)$',jou,re.M)[1],start_journal=re.search(r'^# Start of session at:\s*(.+)$',jou,re.M)[1],end_log=re.search(r'^INFO: \[Common 17-206\] Exiting Vivado at (.+)$',log,re.M)[1],exit_code=0,exit_code_source='Original exec session41799 completed with exit_code0',record_kind='retrospective index of original direct invocation, not contemporaneous wrapper receipt',recorded=datetime.datetime.now().astimezone().isoformat(),journal_sha256=hashlib.sha256((stage/'bitgen.jou').read_bytes()).hexdigest(),log_sha256=hashlib.sha256((stage/'bitgen.log').read_bytes()).hexdigest())
dest.write_text(json.dumps(r,indent=2),encoding='utf-8');print('FIRST_BITGEN_INDEX_RECORDED')
