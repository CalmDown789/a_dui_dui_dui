from pathlib import Path
import sys,json,hashlib,re
root=Path(__file__).resolve().parents[1]
stage=root/'impl'/sys.argv[1];out=stage/'reports'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def metrics(p):
    s=p.read_text(encoding='utf-8',errors='replace')
    m=re.search(r'WNS\(ns\)[^\n]*\n[^\n]*\n\s*([-\d.]+)\s+([-\d.]+)\s+(\d+)\s+(\d+)\s+([-\d.]+)\s+([-\d.]+)\s+(\d+)\s+(\d+)\s+([-\d.]+)\s+([-\d.]+)\s+(\d+)\s+(\d+)',s)
    assert m,p
    names=['WNS','TNS','setup_failing','setup_total','WHS','THS','hold_failing','hold_total','WPWS','TPWS','pulse_failing','pulse_total']
    return dict(zip(names,[float(v) if i in [0,1,4,5,8,9] else int(v) for i,v in enumerate(m.groups())])),s
nom,text=metrics(out/'timing_summary_postroute.rpt')
pressure,_=metrics(out/'timing_summary_route_setup030.rpt')
route=(out/'route_status_postroute.rpt').read_text(encoding='utf-8',errors='replace')
drc=(out/'drc_postroute.rpt').read_text(encoding='utf-8',errors='replace')
def count(label):
    m=re.search(label+r'\.+\s*:\s*(\d+)\s*:',route);assert m,label
    return int(m[1])
routes=dict(routable=count('routable nets'),fully_routed=count('fully routed nets'),errors=count('nets with routing errors'))
gates=dict(setup=nom['WNS']>=0 and nom['TNS']==0 and nom['setup_failing']==0,hold=nom['WHS']>=0 and nom['THS']==0 and nom['hold_failing']==0,pulse=nom['WPWS']>=0 and nom['TPWS']==0 and nom['pulse_failing']==0,route=routes['errors']==0 and routes['routable']==routes['fully_routed'],drc_no_error=not bool(re.search(r'\|\s*[^|]+\|\s*Error\s*\|',drc)),internal_coverage=all(re.search(r'checking '+name+r' \(0\)',text) for name in ['no_clock','unconstrained_internal_endpoints']))
manifest=json.loads((stage/'stage6_build_manifest.json').read_text(encoding='utf-8'))
hash_rows=[]
for row in manifest['inputs']:
    p=Path(row['path']);actual=sha(p);assert actual==row['sha256'],p
    hash_rows.append(dict(path=str(p),sha256=actual))
gates['source_unchanged']=True
frozen=json.loads((stage/'frozen_inputs.json').read_text(encoding='utf-8'))
assert all(sha(Path(r['copy']))==r['sha256'] for r in frozen)
gates['frozen_copies_match']=True
log=(stage/'vivado.log').read_text(encoding='utf-8',errors='replace')
hier=re.search(r'^STAGE6_HIERARCHY (b_core_real=\d+[^\n]+)',log,re.M);assert hier
gates['real_hierarchy']='b_core_real=1 b_core_stub=0 network=1 layers=5' in hier[1] and 'ila=1 vio=1' in hier[1]
util=(out/'utilization_postroute_hier.rpt').read_text(encoding='utf-8',errors='replace')
observer=re.search(r'^\|\s*u_observation\s*\|\s*c_observation\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*(\d+)',util,re.M)
gates['observer_retained']=bool(observer and int(observer[1])>0 and int(observer[5])>0)
gates['original_board_XDC']=sha(root/'candidate/multiframe/constr/c_top.xdc')==sha(root/'original/overlay/multiframe/constr/c_top.xdc')
passed=all(bool(v) for v in gates.values())
result=dict(status='IMPLEMENTATION_PASS' if passed else 'IMPLEMENTATION_FAIL',board_status='NOT_RUN',freq_MHz=manifest['freq_MHz'],pause=manifest['pause'],original_uncertainty_ns=0.0,pressure_uncertainty_ns=0.300,nominal=nom,pressure=pressure,pressure_setup_pass=pressure['WNS']>=0 and pressure['TNS']==0,route=routes,gates={k:bool(v) for k,v in gates.items()},hierarchy=hier[1],source_manifest_sha256=sha(stage/'stage6_build_manifest.json'),dcp=dict(path=str(stage/'postroute.dcp'),bytes=(stage/'postroute.dcp').stat().st_size,sha256=sha(stage/'postroute.dcp')),reports=[dict(name=p.name,sha256=sha(p)) for p in sorted(out.glob('*.rpt'))])
result['observer_resources']=dict(total_LUTs=int(observer[1]),FFs=int(observer[5])) if observer else None
(stage/'implementation_result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:result[k] for k in ['status','freq_MHz','pause','nominal','pressure','route','gates']}))
if not passed:sys.exit(2)
