from pathlib import Path
import sys,subprocess,json,zipfile,hashlib,re,datetime,argparse
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--preview',action='store_true');args=parser.parse_args()
target=root/('portable_check_preview' if args.preview else 'portable_check');target.mkdir(exist_ok=False)
kit=target/'sourcekit';kit.mkdir()
archive=root/('preflight_sourcekit' if args.preview else 'delivery')/'obsfix_sourcekit.zip'
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        p=kit/info.filename
        assert p.resolve().is_relative_to(kit.resolve()),info.filename
        z.extract(info,kit)
manifest=json.loads((kit/'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
for r in manifest:
    p=kit/r['path'];assert p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],p
commands=[]
def run(args):
    cmd=[sys.executable,*map(str,args)]
    p=subprocess.run(cmd,cwd=kit,capture_output=True,text=True,errors='replace')
    commands.append(dict(command=cmd,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr
for freq in [100,150]:
    for pause in [0,1]:
        name=f'f{freq}_p{pause}_portable01'
        run([kit/'scripts/prepare_impl.py',freq,pause,'portable01'])
        run([kit/'scripts/freeze_attempt.py',name])
        m=json.loads((kit/'impl'/name/'stage6_build_manifest.json').read_text(encoding='utf-8'))
        assert m['freq_MHz']==freq and m['pause']==pause and m['B_sources']==42
        for r in m['inputs']:
            p=Path(r['path']);assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'],p
        build=(kit/'impl'/name/'build.tcl').read_text(encoding='utf-8')
        assert f'CORE_CLK_HZ={freq}000000' in build and f'OBS_TEST_PAUSE_ENABLE={pause}' in build
        assert 'C:/Users/Administrator' not in build and 'R:/' not in build
run([kit/'scripts/run_observer_tests.py','--attempt','portable_selftest01'])
assert json.loads((kit/'results/portable_selftest01/result.json').read_text())['status']=='PASS'
if args.preview:
    run([kit/'candidate/run_alignment_sim.py','multiframe','portable01','--clock-mhz',100,'--wall-timeout',1800])
    assert json.loads((kit/'candidate/sim/multiframe_portable01/result.json').read_text())['status']=='PASS'
for r in manifest:
    assert hashlib.sha256((kit/r['path']).read_bytes()).hexdigest()==r['sha256'],'Portable test altered a shipped source'
result=dict(status='PASS_SOURCEKIT_MIGRATION_CHECK',T6='NOT_RUN',created=datetime.datetime.now().astimezone().isoformat(),archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_members_verified=len(manifest),four_build_preparations='PASS fresh extracted root, fixed42B files, IP/source/ROM closure and frozen input checks',observer_simulation='PASS standalone extracted sourcekit 16slot selftest and10000cycle equivalence',full_physical_rebuild='NOT_RUN in extracted kit; real four source builds are separate original measured evidence',commands=commands)
result['T5']='NOT_COMPLETE_SOURCE_DRAFT' if args.preview else 'see gated final four image delivery index'
result['UART_portable_preview']='PASS independent100MHz actual UART two frames byte-exact' if args.preview else 'prior source-only preview relocation run; final kit raw hashes and selftest newly checked'
(root/('preflight_sourcekit' if args.preview else 'delivery')/'PORTABLE_CHECK.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('SOURCEKIT_MIGRATION_CHECK_PASS')
