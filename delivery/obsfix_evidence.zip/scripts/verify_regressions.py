from pathlib import Path
import hashlib,json,importlib.util
root=Path(__file__).resolve().parents[1]
rows=[]
for mhz,suffix in [(100,'fix01'),(150,'fix15001')]:
    for mode in ['controlled','multiframe']:
        run=root/'candidate/sim'/f'{mode}_{suffix}'
        receipt=json.loads((run/'result.json').read_text())
        assert receipt['status']=='PASS'
        assert receipt.get('clock_mhz',100)==mhz
        for i,vector in enumerate(['impulse','ramp']):
            actual=bytes(int(x,16) for x in (run/f'actual_frame{i}.mem').read_text().split())
            expected=bytes(int(x,16) for x in (run/f'tv_{vector}_out.mem').read_text().split())
            assert len(actual)==20736 and actual==expected
            rows.append(dict(clock_mhz=mhz,mode=mode,frame=i,bytes=len(actual),mismatch=0,sha256=hashlib.sha256(actual).hexdigest()))
(root/'results/T3_raw_uart_recheck.json').write_text(json.dumps(rows,indent=2))
spec=importlib.util.spec_from_file_location('decoder',root/'scripts/decode_snapshots.py');decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
mapping=json.loads((root/'contracts/signal_map.json').read_text())
for slot in range(16):
    packed=0;values={}
    for f in mapping['fields']:
        value=((1<<f['width'])-1) if slot%2 else (slot*23+f['lsb'])&((1<<f['width'])-1)
        if f['name']=='valid':value=1
        if f['name']=='slot_index':value=slot
        values[f['name']]=value;packed|=value<<f['lsb']
    row=dict(slot=str(slot),valid='0x1',count='0x10')
    shift=0
    for i,w in enumerate([256,256,256,166]):row[f'p{i}']='0x'+format((packed>>shift)&((1<<w)-1),'x');shift+=w
    assert decoder.decode(row,mapping)['fields']==values
(root/'results/export_decoder_test.json').write_text(json.dumps(dict(status='PASS',slots=16,fields=31,all_fields_cross_chunk_reconstruction=True,hardware_read='NOT_RUN; C T6'),indent=2))
print('UART_RECHECK_AND_DECODER_PASS')
