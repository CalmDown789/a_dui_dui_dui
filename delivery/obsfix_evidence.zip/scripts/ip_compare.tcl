set_param general.maxThreads 2
set base [lindex $argv 0]
set variant [lindex $argv 1]
file mkdir $base
cd $base
create_project iptest "$base/project" -part xc7a200tfbg484-2 -force
set ip_dir "$base/ip"
source [lindex $argv 2]
set ila [get_ips ila_obs_snapshot]
if {$variant eq "data_only"} {set_property CONFIG.C_PROBE1_TYPE 1 $ila}
report_property $ila -file "$base/ila_config.rpt"
generate_target all $ila
synth_ip $ila
close_project
open_checkpoint "$base/ip/ila_obs_snapshot/ila_obs_snapshot/ila_obs_snapshot.dcp"
create_clock -period 6.666667 -name clk [get_ports clk]
report_utilization -file "$base/utilization.rpt"
report_timing_summary -max_paths 10 -file "$base/timing.rpt"
report_timing -max_paths 10 -nets -file "$base/paths.rpt"
write_checkpoint -force "$base/ila_synth.dcp"
puts "IP_COMPARE_COMPLETE=$variant"
