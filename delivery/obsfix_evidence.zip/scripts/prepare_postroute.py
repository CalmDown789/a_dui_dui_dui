from pathlib import Path
import sys,json,hashlib,shutil
root=Path(__file__).resolve().parents[1]
previous=root/'impl'/sys.argv[1];stage=root/'impl'/sys.argv[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((previous/'implementation_result.json').read_text(encoding='utf-8'))
assert parent['gates']['source_unchanged'] and parent['gates']['real_hierarchy']
assert sha(previous/'postroute.dcp')==parent['dcp']['sha256']
stage.mkdir(exist_ok=False);(stage/'reports').mkdir()
source=stage/'source_postroute.dcp';shutil.copyfile(previous/'postroute.dcp',source)
for p in (previous/'reports').iterdir():
    if p.is_file():shutil.copyfile(p,stage/'reports'/p.name)
manifest=json.loads((previous/'stage6_build_manifest.json').read_text(encoding='utf-8'))
for row in manifest['inputs']:assert sha(Path(row['path']))==row['sha256'],row['path']
freq=manifest['freq_MHz']
script='''set_param general.maxThreads 2
if {[llength $argv]!=1} {error "usage: postroute <fresh_stage>"}
set stage [lindex $argv 0]
set out "$stage/reports"
open_checkpoint "$stage/source_postroute.dcp"
if {[get_property PART [current_design]] ne "xc7a200tfbg484-2"} {error "part mismatch"}
set_property SEVERITY Error [get_drc_checks {NSTD-1 UCIO-1}]
set cp [get_pins -quiet {u_multiframe/g_mmcm.u_mmcm/CLKOUT0}]
set cc [get_clocks -quiet -of_objects $cp]
'''+f'''if {{[llength $cc]!=1 || abs([get_property PERIOD $cc]-1000.0/{freq}.0)>0.001}} {{error "clock mismatch"}}
'''+'''set counts {}
foreach ref {b_core_real b_core_stub fsrcnn_network_mem_top fsrcnn_stream_layer pixel_shuffle2x_row_banks elastic_fifo ila_obs_snapshot vio_obs_snapshot_ctrl} {
    if {$ref eq "ila_obs_snapshot" || $ref eq "vio_obs_snapshot_ctrl"} {set query "REF_NAME == $ref"} else {set query "REF_NAME =~ $ref*"}
    lappend counts [llength [get_cells -quiet -hier -filter $query]]
}
lassign $counts a b c d e f g h
puts "STAGE6_HIERARCHY b_core_real=$a b_core_stub=$b network=$c layers=$d pixel_shuffle=$e fifo=$f ila=$g vio=$h"
if {$a!=1 || $b!=0 || $c!=1 || $d!=5 || $e!=1 || $f<4 || $g!=1 || $h!=1} {error "hierarchy mismatch"}
set header [get_cells -quiet {u_multiframe/u_frame_loader/header_q_reg[12]}]
set errorq [get_cells -quiet {u_multiframe/u_frame_loader/frame_error_count_reg[10]}]
report_property $header -file "$out/focus_header_property.rpt"
report_property $errorq -file "$out/focus_error_property.rpt"
set ce [get_pins -of_objects $errorq -filter REF_PIN_NAME==CE]
report_property [get_nets -of_objects $ce] -file "$out/focus_ce_net_property.rpt"
report_timing -to $ce -max_paths 10 -file "$out/focus_before.rpt"
set_clock_uncertainty -setup -from $cc -to $cc 0.300
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_before_postroute_opt_setup030.rpt"
phys_opt_design -directive AggressiveExplore
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_after_postroute_opt_setup030.rpt"
'''
route=(root/'original/scripts/stage6_route_setup030.tcl').read_text(encoding='utf-8')
route=route[route.index('report_clocks -file "$out/clocks_route_setup030.rpt"'):]
(stage/'build.tcl').write_text(script+route,encoding='utf-8')
manifest['inputs']+=[dict(path=str(p),sha256=sha(p)) for p in [source,stage/'build.tcl']]
manifest['postroute_continuation']=dict(previous=str(previous),source_dcp_sha256=sha(source),fresh_source_implementation_parent=True,RTL_changed=False,strategy_change='one postroute phys_opt_design AggressiveExplore under +0.300ns; original NoTimingRelaxation route; restore original uncertainty only',copied_reports='parent raw reports copied, synthesis is parent provenance; final reports overwritten by new measured results')
(stage/'stage6_build_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(stage/'continuation_input.json').write_text(json.dumps(manifest['postroute_continuation'],indent=2),encoding='utf-8')
print('POSTROUTE_PREPARED',stage.name,sha(source))
