from pathlib import Path
import json,hashlib,shutil
root=Path(__file__).resolve().parents[1]
proof=json.loads((root/'preflight_sourcekit/PORTABLE_CHECK.json').read_text(encoding='utf-8'))
assert proof['status']=='PASS_SOURCEKIT_MIGRATION_CHECK'
proof['T5']='NOT_COMPLETE_SOURCE_DRAFT';proof['UART_portable_preview']='PASS 100MHz actual UART two frames byte-exact'
source=root/'portable_check_preview/sourcekit/candidate/sim/multiframe_portable01'
assert json.loads((source/'result.json').read_text())['status']=='PASS'
proof['actual_UART_recheck']=[]
for i,v in enumerate(['impulse','ramp']):
    actual=bytes(int(x,16) for x in (source/f'actual_frame{i}.mem').read_text().split())
    expected=bytes(int(x,16) for x in (source/f'tv_{v}_out.mem').read_text().split())
    assert actual==expected and len(actual)==20736
    proof['actual_UART_recheck'].append(dict(frame=i,bytes=len(actual),mismatch=0,sha256=hashlib.sha256(actual).hexdigest()))
dest=root/'results/portable_sourcekit_preview';dest.mkdir(exist_ok=False)
for sub,src in [('UART',source),('observer',root/'portable_check_preview/sourcekit/results/portable_selftest01')]:
    target=dest/sub;target.mkdir()
    for p in src.iterdir():
        if p.is_file() and p.suffix in ['.txt','.json','.log','.jou','.mem','.v','.tcl']:
            shutil.copyfile(p,target/p.name)
(root/'results/PREFLIGHT_SOURCEKIT_CHECK.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
print('PORTABLE_PREFLIGHT_EVIDENCE_ARCHIVED')
