from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1];workspace=root.parent
entry=Path(sys.argv[1]).read_text(encoding='utf-8')
heading=next(s for s in entry.splitlines() if s.startswith('## '))
for name in ['HANDOFF.md','PROJECT_STATUS.md','LEARNING_LOG.md']:
    p=workspace/name;s=p.read_text(encoding='utf-8-sig')
    if heading in s:continue
    line,rest=s.split('\n',1)
    if name=='HANDOFF.md':line='# 新对话交接：C观测修复与板测交付'
    p.write_text(line+'\n\n'+entry.strip()+'\n\n'+rest.lstrip(),encoding='utf-8',newline='\n')
print('PROGRESS_RECORDS_UPDATED',heading)
