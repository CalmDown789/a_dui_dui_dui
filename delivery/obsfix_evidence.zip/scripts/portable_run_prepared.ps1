param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Vivado,
    [Parameter(Mandatory=$true)][ValidatePattern('^f(100|150)_p[01]_[a-zA-Z0-9]+$')][string]$StageName
)
$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $PSScriptRoot
$taskStage=Join-Path $taskRoot ('impl\'+$StageName)
$taskManifest=Get-Content -LiteralPath (Join-Path $taskStage 'stage6_build_manifest.json') -Raw | ConvertFrom-Json
if(-not(Test-Path -LiteralPath (Join-Path $taskStage 'frozen_inputs.json'))){throw 'Freeze prepared inputs first'}
if(-not(Test-Path -LiteralPath $Python) -or -not(Test-Path -LiteralPath $Vivado)){throw 'Fill installed tool paths'}
$taskReceipt=Join-Path $taskStage 'command.json'
if(Test-Path -LiteralPath $taskReceipt){throw 'Preserving previous execution; prepare a fresh attempt'}
function Save-TaskReceipt($taskPath,$taskValue) {
    [System.IO.File]::WriteAllText($taskPath,($taskValue|ConvertTo-Json -Depth 8),[System.Text.UTF8Encoding]::new($false))
}
$taskBuildArguments=@('-mode','batch','-source',(Join-Path $taskStage 'build.tcl'),'-log',(Join-Path $taskStage 'vivado.log'),'-journal',(Join-Path $taskStage 'vivado.jou'),'-tclargs',$taskStage)
$taskBuildRecord=@{status='RUNNING';command=(@($Vivado)+$taskBuildArguments);start=(Get-Date).ToString('o')}
Save-TaskReceipt $taskReceipt $taskBuildRecord
& $Vivado @taskBuildArguments
$taskBuildExit=$LASTEXITCODE
$taskBuildRecord.status='TOOL_EXITED';$taskBuildRecord.exit_code=$taskBuildExit;$taskBuildRecord.end=(Get-Date).ToString('o')
Save-TaskReceipt $taskReceipt $taskBuildRecord
if($taskBuildExit -ne 0){throw "Vivado failed ($taskBuildExit); keep raw evidence"}
& $Python (Join-Path $PSScriptRoot 'collect_impl.py') $StageName
if($LASTEXITCODE -ne 0){throw 'Physical gates failed; no BIT generated'}
$taskBitReceipt=Join-Path $taskStage 'bitgen_command.json'
$taskBitArguments=@('-mode','batch','-source',(Join-Path $PSScriptRoot 'gated_bitgen.tcl'),'-log',(Join-Path $taskStage 'bitgen.log'),'-journal',(Join-Path $taskStage 'bitgen.jou'),'-tclargs',(Join-Path $taskStage 'postroute.dcp'),$taskManifest.freq_MHz,(Join-Path $taskStage 'bitgen01'))
$taskBitRecord=@{status='RUNNING';command=(@($Vivado)+$taskBitArguments);start=(Get-Date).ToString('o')}
Save-TaskReceipt $taskBitReceipt $taskBitRecord
& $Vivado @taskBitArguments
$taskBitExit=$LASTEXITCODE
$taskBitRecord.status='TOOL_EXITED';$taskBitRecord.exit_code=$taskBitExit;$taskBitRecord.end=(Get-Date).ToString('o')
Save-TaskReceipt $taskBitReceipt $taskBitRecord
if($taskBitExit -ne 0){throw 'Independent bitgen gates failed'}
& $Python (Join-Path $PSScriptRoot 'verify_bit.py') $StageName
if($LASTEXITCODE -ne 0){throw 'BIT/LTX/DCP identity check failed'}
