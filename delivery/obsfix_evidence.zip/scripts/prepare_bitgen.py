from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'original/scripts/gated_bitgen.tcl').read_text(encoding='utf-8')
s='set_param general.maxThreads 2\n'+s
s=s.replace('set dcp [file normalize [lindex $argv 0]]','set dcp [lindex $argv 0]').replace('set out [file normalize [lindex $argv 2]]','set out [lindex $argv 2]')
needle='puts "BITGEN_GATES_PASS'
where=s.index(needle)
s=s[:where]+'''set ila [get_cells -quiet u_obs_ila]
set vio [get_cells -quiet u_obs_vio]
if {[llength $ila]!=1 || [llength $vio]!=1} {error "debug core hierarchy mismatch"}
set config [get_property CORE_GENERATION_INFO $ila]
foreach token {C_NUM_OF_PROBES=10 C_DATA_DEPTH=1024 C_PROBE1_WIDTH=934 C_PROBE1_TYPE=1 C_INPUT_PIPE_STAGES=0} {
    if {[string first ",$token," ",$config,"]<0} {error "ILA config gate failed: $token"}
}
set real [get_cells -quiet -hier -filter {REF_NAME =~ b_core_real*}]
set stub [get_cells -quiet -hier -filter {REF_NAME =~ b_core_stub*}]
if {[llength $real]!=1 || [llength $stub]!=0} {error "real B gate failed"}
report_property $ila -file "$out/ila_identity.rpt"
report_property $vio -file "$out/vio_identity.rpt"
set f [open "$out/drc_severity.txt" w]
foreach check {NSTD-1 UCIO-1} {puts $f "$check=[get_property SEVERITY [get_drc_checks $check]]"}
close $f
'''+s[where:]
s=s.replace('puts "GATED_BITSTREAM_COMPLETE=', 'write_debug_probes "$out/c_board_${mhz}mhz.ltx"\nputs "GATED_BITSTREAM_COMPLETE=')
s=s.replace('write_xdc -force "$out/constraints.xdc"','''write_xdc -force "$out/constraints.xdc"
set skew [report_bus_skew -return_string]
set f [open "$out/bus_skew.rpt" w];puts $f $skew;close $f
if {[regexp {Slack \\(VIOLATED\\)} $skew]} {error "IP bus skew constraint failed"}''')
(root/'scripts/gated_bitgen.tcl').write_text(s,encoding='utf-8',newline='\n')
print('GATED_BITGEN_PREPARED')
