param(
    [Parameter(Mandatory=$true)][string]$Python,
    [Parameter(Mandatory=$true)][string]$Vivado,
    [ValidateSet(100,150)][int]$MHz=150,
    [ValidateSet(0,1)][int]$Pause=0,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-zA-Z0-9]+$')][string]$Attempt
)
$ErrorActionPreference='Stop'
$taskRoot=Split-Path -Parent $PSScriptRoot
if(-not (Test-Path -LiteralPath $Python) -or -not (Test-Path -LiteralPath $Vivado)){throw 'Fill the installed tool paths'}
# Use the actual new kit directory. Do not change existing drive mappings.
$taskStage=Join-Path $taskRoot ('impl\f{0}_p{1}_{2}' -f $MHz,$Pause,$Attempt)
if(Test-Path -LiteralPath $taskStage){throw 'Preserving previous attempt; choose another name'}
& $Python (Join-Path $PSScriptRoot 'prepare_impl.py') $MHz $Pause $Attempt
if($LASTEXITCODE -ne 0){throw 'Source preparation failed'}
& $Python (Join-Path $PSScriptRoot 'freeze_attempt.py') (Split-Path -Leaf $taskStage)
if($LASTEXITCODE -ne 0){throw 'Source freeze failed'}
$taskReceiptPath=Join-Path $taskStage 'command.json'
$taskRecord=@{status='RUNNING'; command=@($Vivado,'-mode','batch','-source',(Join-Path $taskStage 'build.tcl'),'-tclargs',$taskStage); start=(Get-Date).ToString('o')}
[System.IO.File]::WriteAllText($taskReceiptPath,($taskRecord|ConvertTo-Json -Depth 6),[System.Text.UTF8Encoding]::new($false))
# For the recommended short ASCII kit path, normalization is safe. A long
# or non-ASCII root should be mapped to a free drive in the same user session
# before calling this script; never overwrite an unknown existing mapping.
& $Vivado -mode batch -source (Join-Path $taskStage 'build.tcl') -log (Join-Path $taskStage 'vivado.log') -journal (Join-Path $taskStage 'vivado.jou') -tclargs $taskStage
$taskExit=$LASTEXITCODE
$taskRecord.status='TOOL_EXITED'; $taskRecord.exit_code=$taskExit; $taskRecord.end=(Get-Date).ToString('o')
[System.IO.File]::WriteAllText($taskReceiptPath,($taskRecord|ConvertTo-Json -Depth 6),[System.Text.UTF8Encoding]::new($false))
if($taskExit -ne 0){throw "Vivado build failed: $taskExit; retain all raw files"}
& $Python (Join-Path $PSScriptRoot 'collect_impl.py') (Split-Path -Leaf $taskStage)
if($LASTEXITCODE -ne 0){throw 'Implementation gates failed; no BIT allowed'}
$taskBitDir=Join-Path $taskStage 'bitgen01'
$taskBitReceipt=Join-Path $taskStage 'bitgen_command.json'
$taskBitRecord=@{status='RUNNING'; command=@($Vivado,'-mode','batch','-source',(Join-Path $PSScriptRoot 'gated_bitgen.tcl'),'-tclargs',(Join-Path $taskStage 'postroute.dcp'),$MHz,$taskBitDir); start=(Get-Date).ToString('o')}
[System.IO.File]::WriteAllText($taskBitReceipt,($taskBitRecord|ConvertTo-Json -Depth 6),[System.Text.UTF8Encoding]::new($false))
& $Vivado -mode batch -source (Join-Path $PSScriptRoot 'gated_bitgen.tcl') -log (Join-Path $taskStage 'bitgen.log') -journal (Join-Path $taskStage 'bitgen.jou') -tclargs (Join-Path $taskStage 'postroute.dcp') $MHz $taskBitDir
$taskBitExit=$LASTEXITCODE
$taskBitRecord.status='TOOL_EXITED'; $taskBitRecord.exit_code=$taskBitExit; $taskBitRecord.end=(Get-Date).ToString('o')
[System.IO.File]::WriteAllText($taskBitReceipt,($taskBitRecord|ConvertTo-Json -Depth 6),[System.Text.UTF8Encoding]::new($false))
if($taskBitExit -ne 0){throw 'Independent bitgen gates failed'}
& $Python (Join-Path $PSScriptRoot 'verify_bit.py') (Split-Path -Leaf $taskStage)
if($LASTEXITCODE -ne 0){throw 'BIT/LTX identity check failed'}
