from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path(__file__).resolve().parents[1]
repo=root/'source_review';repo.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git','-c','core.autocrlf=false','-c','user.name=Codex','-c','user.email=codex@local.invalid','-C',str(repo),*args])
git('init','-b','c-observation-fix-20261005')
shutil.copytree(root/'original/overlay/multiframe',repo/'multiframe')
(repo/'scripts').mkdir()
shutil.copyfile(root/'original/scripts/configure_observation_debug_ip.tcl',repo/'scripts/configure_observation_debug_ip.tcl')
(repo/'.gitattributes').write_text('* -text\n',encoding='utf-8')
git('add','.gitattributes','multiframe','scripts/configure_observation_debug_ip.tcl')
git('commit','-m','Import frozen C observation candidate from 86df150 for independent review')
base=git('rev-parse','HEAD').decode().strip()
shutil.copyfile(root/'candidate/multiframe/rtl/c_observation.v',repo/'multiframe/rtl/c_observation.v')
p=repo/'scripts/configure_observation_debug_ip.tcl';s=p.read_text(encoding='utf-8')
s=s.replace('set_property -dict $ila_cfg $ila','''set_property -dict $ila_cfg $ila
# Full 934-bit snapshot is captured as data. Trigger on the nine small probes.
# TYPE=1 is DATA in the installed ILA 6.2 component.xml.
set_property CONFIG.C_PROBE1_TYPE 1 $ila''')
p.write_text(s,encoding='utf-8',newline='\n')
git('add','multiframe/rtl/c_observation.v','scripts/configure_observation_debug_ip.tcl')
git('commit','-m','Fix observation increment chains and make wide ILA snapshot data-only')
head=git('rev-parse','HEAD').decode().strip()
(root/'results/repair.patch').write_bytes(git('diff','--binary',base,head))
(root/'results/source_revision.json').write_text(json.dumps(dict(base=base,fix_commit=head,pinned_C='86df150d45ff8f98b976053ce293688133bc12e9',fixed_B='6cc8ea4173d2a720f741e80b7cbd9279558ee93a',repo=str(repo),patch_sha256=hashlib.sha256((root/'results/repair.patch').read_bytes()).hexdigest(),pushed=False,changed_paths=git('diff','--name-only',base,head).decode().splitlines()),indent=2),encoding='utf-8')
print(head)
