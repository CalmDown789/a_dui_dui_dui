from pathlib import Path
import subprocess,json,sys,datetime
root=Path(__file__).resolve().parents[1]
stage=root/'impl'/sys.argv[1]
assert stage.is_dir() and (stage/'build.tcl').is_file()
receipt=stage/'command.json'
if receipt.exists():raise SystemExit('Preserving existing command receipt')
alias='Q:/impl/'+stage.name
command=['cmd.exe','/d','/c','F:/Xilinx/2025.2/Vivado/bin/vivado.bat','-mode','batch','-source',alias+'/build.tcl','-log',alias+'/vivado.log','-journal',alias+'/vivado.jou','-tclargs',alias]
record=dict(status='RUNNING',command=command,start=datetime.datetime.now().astimezone().isoformat())
receipt.write_text(json.dumps(record,indent=2),encoding='utf-8')
with (stage/'console.log').open('wb') as log:
    code=subprocess.call(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
record.update(status='TOOL_EXITED',exit_code=code,end=datetime.datetime.now().astimezone().isoformat())
receipt.write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record));sys.exit(code)
