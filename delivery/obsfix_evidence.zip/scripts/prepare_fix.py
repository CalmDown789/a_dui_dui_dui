from pathlib import Path
import hashlib,json,re,shutil,subprocess
root=Path(__file__).resolve().parents[1]
rtl=root/'candidate/multiframe/rtl'
p=rtl/'c_observation.v'
s=p.read_text()
func='''    // Exact modulo-2^64 increment, with four independent 16-bit sums.
    // Carry predicates use the OLD value; no cycle latency or range change.
    function [63:0] inc64;
        input [63:0] value;
        begin
            inc64[15:0]  = value[15:0]  + 16'd1;
            inc64[31:16] = value[31:16] + (&value[15:0]);
            inc64[47:32] = value[47:32] + (&value[31:0]);
            inc64[63:48] = value[63:48] + (&value[47:0]);
        end
    endfunction

'''
s=s.replace('    localparam [31:0] EXPECTED_INPUTS_U32',func+'    localparam [31:0] EXPECTED_INPUTS_U32')
s=re.sub(r'(\w+_q) \+ 64\x27d1',r'inc64(\1)',s)
p.write_text(s,newline='\n')
for rel in ['scripts/run_alignment_sim.py','toolchain.json']:
    src=root/'original'/rel
    if src.exists():shutil.copyfile(src,root/'candidate'/Path(rel).name)
runner=(root/'candidate/run_alignment_sim.py').read_text().replace("Path(__file__).resolve().parents[1]","Path(__file__).resolve().parent")
runner=runner.replace("root/'overlay/multiframe/rtl'","root/'multiframe/rtl'").replace("root/'overlay/multiframe/tb'","root/'multiframe/tb'").replace("root/'b_reference'","root.parent/'b_fixed'").replace("root/'fixtures/simulation'","root.parent/'original/fixtures/simulation'")
(root/'candidate/run_alignment_sim.py').write_text(runner)
(root/'candidate/toolchain.json').write_text(json.dumps({'vivado_root':'F:/Xilinx/2025.2/Vivado'}))
(root/'candidate/sim').mkdir(exist_ok=True)
inputs=[]
for group,base,globs in [('C',root/'original/overlay',['**/*']),('B',root/'b_fixed',['rtl/**/*.sv','experiments/l5_splitmem_20260924/rtl/b/*.sv','rom/member_a_d16_s8_m1_c16/*_packed.mem'])]:
    for glob in globs:
        for f in base.glob(glob):
            if not f.is_file():continue
            sha=hashlib.sha256(f.read_bytes()).hexdigest()
            if group=='B':
                rel=f.relative_to(base).as_posix()
                blob=subprocess.check_output(['git','-C',str(base),'show','6cc8ea4173d2a720f741e80b7cbd9279558ee93a:'+rel])
                assert hashlib.sha256(blob).hexdigest()==sha,rel
            inputs.append(dict(group=group,path=str(f),sha256=sha))
(root/'results/source_manifest.json').write_text(json.dumps(inputs,indent=2,ensure_ascii=False),encoding='utf-8')
(root/'results/T0_environment.json').write_text(json.dumps(dict(vivado='F:/Xilinx/2025.2/Vivado',version='2025.2',sw_build=6299465,part='xc7a200tfbg484-2',fixed_B='6cc8ea4173d2a720f741e80b7cbd9279558ee93a',C='86df150d45ff8f98b976053ce293688133bc12e9',supplement='d6b13e625a15d952b6d3b657428472c1f51b1242',shared_checkout_untouched=True,source_checks=len(inputs),cim_memory='access denied in sandbox; query separately if required'),indent=2))
print('PREPARED',len(inputs))
