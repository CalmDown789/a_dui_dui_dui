set_param general.maxThreads 2
set out [lindex $argv 1]
open_checkpoint [lindex $argv 0]
create_clock -period 6.666667 -name clk [get_ports clk]
report_utilization -file "$out/utilization.rpt"
report_timing_summary -max_paths 10 -file "$out/timing.rpt"
report_timing -max_paths 10 -nets -file "$out/paths.rpt"
set f [open "$out/counts.txt" w]
puts $f "CARRY4=[llength [get_cells -hier -filter {REF_NAME == CARRY4}]]"
close $f
