from pathlib import Path
import json,hashlib,sys,re
root=Path(__file__).resolve().parents[1];stage=root/'impl'/sys.argv[1]
impl=json.loads((stage/'implementation_result.json').read_text(encoding='utf-8'))
assert impl['status']=='IMPLEMENTATION_PASS' and all(impl['gates'].values())
assert hashlib.sha256((stage/'postroute.dcp').read_bytes()).hexdigest()==impl['dcp']['sha256']
command_path=stage/'command.json'
if not command_path.is_file():command_path=stage/'command_reconstructed.json'
command=json.loads(command_path.read_text(encoding='utf-8'))
assert command['status']=='TOOL_EXITED' and command['exit_code']==0
bitgen=stage/'bitgen01';freq=impl['freq_MHz']
bit=bitgen/f'c_board_{freq}mhz.bit';ltx=bitgen/f'c_board_{freq}mhz.ltx'
log=(stage/'bitgen.log').read_text(encoding='utf-8',errors='replace')
assert re.search(r'^BITGEN_GATES_PASS ',log,re.M) and re.search(r'^GATED_BITSTREAM_COMPLETE=',log,re.M)
assert bit.stat().st_size>9000000 and ltx.is_file()
cores=json.loads(ltx.read_text(encoding='utf-8'))['ltx_root']['ltx_data'][0]['debug_cores']
ila=next(c for c in cores if c['name']=='u_obs_ila')
vio=next(c for c in cores if c['name']=='u_obs_vio')
hub=next(c for c in cores if c['type']=='XSDB_V3')
assert int(hub['clk_input_freq_hz'])==freq*1000000
assert len(ila['pins'])==10
snapshot=next(p for p in ila['pins'] if p['portIndex']==1)
assert snapshot['type']=='DATA' and abs(snapshot['rightIndex']-snapshot['leftIndex'])+1==934
assert all(p['type']=='DATA_TRIGGER' for p in ila['pins'] if p['portIndex']!=1)
inputs=[p for p in vio['pins'] if p['direction']=='IN'];outputs=[p for p in vio['pins'] if p['direction']=='OUT']
assert [abs(p['rightIndex']-p['leftIndex'])+1 for p in sorted(inputs,key=lambda p:p['portIndex'])]==[256,256,256,166,1,5]
assert len(outputs)==1 and abs(outputs[0]['rightIndex']-outputs[0]['leftIndex'])+1==5
vio_identity=(bitgen/'vio_identity.rpt').read_text(encoding='utf-8',errors='replace')
for token in ['C_NUM_PROBE_IN=6','C_NUM_PROBE_OUT=1','C_PROBE_OUT0_WIDTH=5']:
    assert ','+token+',' in vio_identity,token
initial=re.search(r',C_PROBE_OUT0_INIT_VAL=([^,}]+)',vio_identity)
assert initial and int(initial[1],0)==0
artifacts=[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [bit,ltx]]
result=dict(status='BOARD_READY',T6='NOT_RUN',freq_MHz=freq,pause=impl['pause'],source_commit=json.loads((root/'results/source_revision.json').read_text())['fix_commit'],fixed_B='6cc8ea4173d2a720f741e80b7cbd9279558ee93a',artifacts=artifacts,ILA_uuid=ila['uuid'],VIO_uuid=vio['uuid'],ILA_probe1='934-bit DATA',VIO_widths=[256,256,256,166,1,5],implementation=str(stage/'implementation_result.json'),source_postroute_sha256=impl['dcp']['sha256'],bitgen_gates='PASS; same postroute DCP',bus_skew='PASS; see bitgen01/bus_skew.rpt')
result['VIO_output_initial_value']=0
(stage/'board_ready.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result))
