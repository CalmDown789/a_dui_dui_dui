from pathlib import Path
import json,hashlib,datetime
root=Path(__file__).resolve().parents[1];results=root/'results'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ready=[]
for stage in sorted((root/'impl').iterdir()):
    p=stage/'board_ready.json'
    if not p.is_file():continue
    r=json.loads(p.read_text(encoding='utf-8'));i=json.loads((stage/'implementation_result.json').read_text(encoding='utf-8'))
    assert r['status']=='BOARD_READY' and r['T6']=='NOT_RUN' and i['status']=='IMPLEMENTATION_PASS' and all(i['gates'].values())
    assert sha(stage/'postroute.dcp')==r['source_postroute_sha256']
    for a in r['artifacts']:assert sha(Path(a['path']))==a['sha256']
    r['attempt']=stage.name;r['nominal']=i['nominal'];r['pressure']=i['pressure'];r['pressure_setup_pass']=i['pressure_setup_pass'];r['route']=i['route']
    r['board_zip_directory']=f"{r['freq_MHz']}mhz_pause{r['pause']}"
    r['top']='c_multiframe_synth_top';r['tool']='Vivado/XSim2025.2 SW6299465';r['part']='xc7a200tfbg484-2'
    ready.append(r)
assert {(r['freq_MHz'],r['pause']) for r in ready}=={(100,0),(100,1),(150,0),(150,1)}
raw=json.loads((results/'T3_raw_uart_recheck.json').read_text());assert len(raw)==8 and all(r['mismatch']==0 for r in raw)
assert json.loads((results/'observer_tests01/result.json').read_text())['status']=='PASS'
revision=json.loads((results/'source_revision.json').read_text())
assert sha(results/'repair.patch')==revision['patch_sha256']
record=dict(status='BOARD_READY',T0_T5='COMPLETE_OFFLINE',T6='NOT_RUN',created=datetime.datetime.now().astimezone().isoformat(),source=revision,images=ready,regressions=dict(observer='31fields/16slots/overflow/injected errors + 10000cycle old/new equivalence PASS',UART='100/150MHz pause0/1 two different96x54 frames each; 8 actual serial outputs all20736bytes byte-exact',full_size='existing verified baseline fullframe evidence reused, not new candidate full-size run'),OPEN=['C T6 physical JTAG/VIO/ILA and UART4/16frames + bounded pause','REQP-1839/1840 and BRAM asynchronous reset structure','Flash autonomous startup and busy-time reset not verified','camera/HDMI/30fps outside this task','200MHz task PAUSED_AT_USER_REQUEST'],guides=['C_BOARD_GUIDE.md','REBUILD_GUIDE.md'],archives=['obsfix_board_images.zip','obsfix_sourcekit.zip','obsfix_evidence.zip','obsfix_checkpoints.zip'],no_publication=True)
portable=json.loads((results/'PREFLIGHT_SOURCEKIT_CHECK.json').read_text(encoding='utf-8'))
assert portable['status']=='PASS_SOURCEKIT_MIGRATION_CHECK' and all(r['mismatch']==0 for r in portable['actual_UART_recheck'])
record['sourcekit_preflight']='PASS relocated sourcekit four frozen build preparations, observer selftest/equivalence and separate2 actual byte-exact UART frames; see PREFLIGHT_SOURCEKIT_CHECK.json'
(results/'T5_delivery.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
lines=['# T5 C板测交付索引','','T0–T5离线完成，四组合仅 **BOARD_READY**；实体T6 **NOT_RUN**。先读C_BOARD_GUIDE.md，按每组合独立BIT/LTX及哈希配置；不能继承历史基线板测PASS。','','| MHz | pause | 本轮最终attempt | WNS/WHS/WPWS(ns) | 压力WNS(ns) |','|---:|---:|---|---|---:|']
for r in ready:
    n=r['nominal'];lines.append(f"| {r['freq_MHz']} | {r['pause']} | {r['attempt']} | {n['WNS']:+.3f}/{n['WHS']:+.3f}/{n['WPWS']:+.3f} | {r['pressure']['WNS']:+.3f} |")
lines+=['','签核按原约束：TNS/THS/TPWS=0、setup/hold/pulse非负、route全通且errors0、DRC Error0、NSTD/UCIO Error、no_clock/internal_unconstrained0、真实固定B层级通过。额外+0.300ns压力另报，不能与名义裕量混用。原板级XDC未改，器件jitter保留。','','## 镜像身份','']
for r in ready:
    if not r['pressure_setup_pass']:
        p=r['pressure'];idx=lines.index('## 镜像身份');lines[idx:idx]=[f"{r['freq_MHz']}MHz pause={r['pause']}：额外压力setup未通过，WNS{p['WNS']:+.3f}ns/TNS{p['TNS']:+.3f}ns/{p['setup_failing']}端点；正式原约束全部门控通过。压力原始失败与route critical warning保留，不宣称四档都通过额外压力。",'']
for r in ready:
    lines += [f"### {r['freq_MHz']}MHz pause={r['pause']}",'',f"板测ZIP相对目录：`{r['board_zip_directory']}`；后布线DCP SHA：`{r['source_postroute_sha256']}`。",'']
    for a in r['artifacts']:lines.append(f"- `{Path(a['path']).name}`，{a['bytes']}字节，SHA256 `{a['sha256']}`。")
    lines += ['',f"ILA UUID `{r['ILA_uuid']}`；VIO UUID `{r['VIO_uuid']}`。934位probe1 DATA；其余9探针DATA_TRIGGER；VIO256/256/256/166/1/5，输出5位初值0。",'']
lines+=['## 源与复现','',f"最小补丁提交 `{revision['fix_commit']}`（独立本地repo，未推送）；原C `{revision['pinned_C']}`，固定B `{revision['fixed_B']}`，A98c82f3。补丁SHA `{revision['patch_sha256']}`。`source_review.bundle`可在新目录clone审查，源码包的candidate才是完整重建入口。",'', '四份ZIP：board_images直接供C上板；sourcekit含固定源/ROM/IP/原始模板/脚本/契约/测试向量；evidence含全部通过和失败尝试报告、日志、命令、UART实际返回和测试台；checkpoints按SHA去重保存本轮DCP和冻结输入原字节，object_index映射每个原路径。ZIP及每成员长度/SHA/CRC由DELIVERY_MANIFEST.json与各PACKAGE_MANIFEST.json签核。','','首两个直接Vivado作业的命令/起止来自原jou/log，退出码来自实际tool session完成回执，后补command_reconstructed.json明确是回顾索引；后续作业command.json在启动/完成时记录。工具错误和检查脚本错误不计作硬件失败；150MHz a01实际setup失败完整保留。','','## 尚待C与回退','','按指南进行四帧、连续16帧、31字段实读、ILA实际导出、受控暂停forced>0且释放后Golden一致。现有通路停止PC读串口不自动形成B内部背压。原100/150基线BIT可直接JTAG回退，准确SHA见C_BOARD_GUIDE.md。REQP-1839/1840/BRAM异步复位结构仍OPEN；报告20条上限不代表总违规数。Flash自主启动、忙时复位、自然视频播放、HDMI、30fps及200MHz不由此次离线通过升级；用户掌握状态未升级。']
(results/'T5_delivery.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
morning=['# 次日上午验收入口','','C观测时序修复的T0–T5离线工作已经完成。100/150MHz普通与受控暂停四种镜像均通过完整物理门控并生成同DCP配套BIT/LTX；实体板测仍交C。','','根因与修正：宽934位探针触发匹配配置导致ILA117级进位长路径，单变量OOC已证明改DATA消除该长路径；64位计数器改精确四段16位增量，10000拍旧新逐拍等价。固定B和C板级XDC未改。150MHz普通版首轮余下C帧头→错误计数控制-0.141ns，通过本轮源码DCP上的布线后物理优化继续修复，所有失败证据保留。','','回归：31字段/16槽/溢出/故意违例检测、10000拍等价、100/150MHz两种暂停配置各两帧真实UART共8帧全部逐字节一致。完整尺寸长仿真明确复用已核验基线，本轮未冒充重跑。','','先读T5_delivery.md看最终四组合数值与SHA，再按C_BOARD_GUIDE.md上板。DELIVERY_MANIFEST.json列四ZIP：先给C board_images；需要复现再给sourcekit/evidence；checkpoints用于网表检查和冻结原字节取证。全部仍仅BOARD_READY，C实跑通过后才能BOARD_PASS。','','另200MHz任务仍暂停，共享dirty工作树、冻结基线和原失败DCP保护；未push、未联系A/C、未创建额外任务。']
(results/'MORNING_REVIEW.md').write_text('\n'.join(morning)+'\n',encoding='utf-8')
with (results/'MORNING_REVIEW.md').open('a',encoding='utf-8') as f:
    f.write('\n150MHz受控暂停版的额外+0.300ns压力WNS-0.048ns、10个端点未过；正式原约束WNS+0.252ns且其余门控全部通过。压力失败单独保留，不作为额外压力通过宣传。源码草稿已在另一个新目录通过四档构建闭包、自检/等价和独立UART两帧回归；最终ZIP另做逐成员SHA/CRC及新解压目录核对。\n')
print('T5_OFFLINE_INDEX_READY',[(r['freq_MHz'],r['pause'],r['nominal']['WNS']) for r in ready])
