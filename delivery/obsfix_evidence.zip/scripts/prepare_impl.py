from pathlib import Path
import sys,shutil,json,hashlib
root=Path(__file__).resolve().parents[1]
freq,pause,attempt=sys.argv[1:]
assert freq in ['100','150'] and pause in ['0','1'] and attempt.isalnum()
stage=root/'impl'/f'f{freq}_p{pause}_{attempt}'
stage.mkdir(parents=True,exist_ok=False)
(stage/'reports').mkdir()
for name,src in [('ila_obs_snapshot',root/'results/ipdata/ip/ila_obs_snapshot/ila_obs_snapshot/ila_obs_snapshot.xci'),('vio_obs_snapshot_ctrl',root/'original/generated_ip/vio_obs_snapshot_ctrl/vio_obs_snapshot_ctrl/vio_obs_snapshot_ctrl.xci')]:
    d=stage/'ip'/name;d.mkdir(parents=True)
    shutil.copyfile(src,d/f'{name}.xci')
for p in (root/'b_fixed/rom/member_a_d16_s8_m1_c16').glob('*_packed.mem'):shutil.copyfile(p,stage/p.name)
B_sources=[]
for glob in ['rtl/b_real_ae29515/stream/*.sv','experiments/l5_splitmem_20260924/rtl/b/*.sv','rom/member_a_d16_s8_m1_c16/*_packed.mem']:
    B_sources.extend((root/'b_fixed').glob(glob))
if (root/'B_VERIFIED_BLOBS.json').is_file():
    verified=json.loads((root/'B_VERIFIED_BLOBS.json').read_text(encoding='utf-8'))
    for p in B_sources:
        rel=p.relative_to(root/'b_fixed').as_posix()
        assert hashlib.sha256(p.read_bytes()).hexdigest()==verified['files'][rel],rel
s=(root/'original/scripts/stage6_synth_setup030.tcl').read_text()
s='set_param general.maxThreads 2\n'+s
s=s.replace('set stage [file normalize [lindex $argv 0]]','set stage [lindex $argv 0]')
start=s.index('set here ');end=s.index('set out ',start)
s=s[:start]+'''set work [file dirname [file dirname $stage]]
set candidate "$work/candidate"
set b_root "$work/b_fixed"
set c_rtl "$candidate/multiframe/rtl"
set xdc "$candidate/multiframe/constr/c_top.xdc"
'''+s[end:]
s=s.replace('150000000',freq+'000000').replace('8.0','12.0' if freq=='100' else '8.0').replace('1000.0/150.0','1000.0/'+freq+'.0').replace('OBS_TEST_PAUSE_ENABLE=0','OBS_TEST_PAUSE_ENABLE='+pause)
route=(root/'original/scripts/stage6_route_setup030.tcl').read_text()
route=route[route.index('report_clocks -file "$out/clocks_route_setup030.rpt"'):]
route=route.replace('set_clock_uncertainty -setup -from $cc -to $cc 0.000','set_clock_uncertainty -setup -from $cc -to $cc 0.000')
s+='\n'+route
(stage/'build.tcl').write_text(s)
files=list((root/'candidate/multiframe').rglob('*'))+B_sources+list((stage/'ip').rglob('*.xci'))+list(stage.glob('*.mem'))+[stage/'build.tcl']
rows=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files if p.is_file()]
(stage/'stage6_build_manifest.json').write_text(json.dumps(dict(freq_MHz=int(freq),pause=int(pause),fixed_B='6cc8ea4173d2a720f741e80b7cbd9279558ee93a',inputs=rows,B_sources=len(B_sources),B_source_manifest=str(root/'results/source_manifest.json'),ILA_probe1_type='DATA=1; other nine probes unchanged',strategy='original comparable',pressure=0.300,restore=0.000),indent=2),encoding='utf-8')
print('Q:/impl/'+stage.name)
