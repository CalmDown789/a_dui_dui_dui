# No hardware APIs are called while sourcing the proc definitions.
source [lindex $argv 0]
foreach {raw expected} {00 0x00 0xff 0xff 256'h00123 0x00123} {
    if {[obs_hex $raw] ne $expected} {error "hex parser mismatch"}
}
foreach p {obs_export obs_pause_once obs_probe obs_hex} {
    if {[llength [info procs $p]]!=1} {error "missing proc $p"}
}
puts "TCL_SYNTAX_AND_HEX_PARSE_PASS; hardware object lookup/reads NOT_RUN"
