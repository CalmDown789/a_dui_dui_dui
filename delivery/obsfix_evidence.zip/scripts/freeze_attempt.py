from pathlib import Path
import json,hashlib,shutil,sys
root=Path(__file__).resolve().parents[1]
stage=root/'impl'/sys.argv[1]
m=json.loads((stage/'stage6_build_manifest.json').read_text())
target=stage/'frozen_inputs';target.mkdir(exist_ok=False)
rows=[]
sources=m['inputs']
if 'B_sources' not in m:
    sources+=json.loads((root/'results/source_manifest.json').read_text(encoding='utf-8'))
for i,row in enumerate(sources):
    p=Path(row['path'])
    raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest()
    assert sha==row['sha256'],p
    dst=target/f'{i:03d}_{p.name}';dst.write_bytes(raw)
    rows.append(dict(source=str(p),copy=str(dst),sha256=sha))
(stage/'frozen_inputs.json').write_text(json.dumps(rows,indent=2))
print('FROZEN',len(rows))
