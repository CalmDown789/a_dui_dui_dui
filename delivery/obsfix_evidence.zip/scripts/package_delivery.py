from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess,datetime,sys
root=Path(__file__).resolve().parents[1]
assert sys.argv[1:] in [[],['--source-only-preflight']]
preflight=bool(sys.argv[1:])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ready=[]
for stage in sorted((root/'impl').iterdir()):
    p=stage/'board_ready.json'
    if p.is_file():
        r=json.loads(p.read_text(encoding='utf-8'))
        assert r['status']=='BOARD_READY' and r['T6']=='NOT_RUN'
        assert all(sha(Path(a['path']))==a['sha256'] for a in r['artifacts'])
        assert sha(stage/'postroute.dcp')==r['source_postroute_sha256']
        ready.append((stage,r))
if not preflight:
    assert {(r['freq_MHz'],r['pause']) for _,r in ready}=={(100,0),(100,1),(150,0),(150,1)},'four BOARD_READY combinations required'
delivery=root/('preflight_sourcekit' if preflight else 'delivery');delivery.mkdir(exist_ok=False)
kit=delivery/'sourcekit';kit.mkdir()
evidence=delivery/'evidence';evidence.mkdir()
checkpoint=delivery/'checkpoints';checkpoint.mkdir()
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst);assert sha(src)==sha(dst)
def tree(src,dst,predicate=lambda p:True):
    for p in src.rglob('*'):
        if p.is_file() and predicate(p):copy(p,dst/p.relative_to(src))
tree(root/'candidate/multiframe',kit/'candidate/multiframe')
for name in ['run_alignment_sim.py','toolchain.json']:copy(root/'candidate'/name,kit/'candidate'/name)
(kit/'candidate/sim').mkdir()
b=json.loads((root/'B_VERIFIED_BLOBS.json').read_text(encoding='utf-8'))
for rel,expected in b['files'].items():
    p=root/'b_fixed'/rel;assert sha(p)==expected;copy(p,kit/'b_fixed'/rel)
copy(root/'B_VERIFIED_BLOBS.json',kit/'B_VERIFIED_BLOBS.json')
portable_scripts={'collect_impl.py','decode_snapshots.py','export_vio.tcl','freeze_attempt.py','gated_bitgen.tcl','portable_bootstrap.ps1','portable_run_prepared.ps1','prepare_bitgen.py','prepare_impl.py','prepare_continue.py','prepare_postroute.py','run_observer_tests.py','verify_bit.py'}
tree(root/'scripts',kit/'scripts',lambda p:p.name in portable_scripts)
for name in ['stage6_synth_setup030.tcl','stage6_place_from_synth_dcp.tcl','stage6_route_setup030.tcl','gated_bitgen.tcl','configure_observation_debug_ip.tcl']:
    copy(root/'original/scripts'/name,kit/'original/scripts'/name)
for rel in ['overlay/multiframe/rtl/c_observation.v','overlay/multiframe/tb/tb_c_observation.v','overlay/multiframe/constr/c_top.xdc','generated_ip/vio_obs_snapshot_ctrl/vio_obs_snapshot_ctrl/vio_obs_snapshot_ctrl.xci']:
    copy(root/'original'/rel,kit/'original'/rel)
tree(root/'original/fixtures',kit/'original/fixtures')
iprel='results/ipdata/ip/ila_obs_snapshot/ila_obs_snapshot/ila_obs_snapshot.xci'
copy(root/iprel,kit/iprel)
tree(root/'contracts',kit/'contracts')
capture=root.parent/'.artifacts/c_handoff_audit_20261004/observation_86df150/experiments/c_observation_handoff_20261004/baseline/scripts/capture_uart_frames.ps1'
copy(capture,kit/'scripts/capture_uart_frames.ps1')
for p in (root/'results').glob('*'):
    if p.is_file() and p.suffix in ['.md','.json','.csv','.patch'] and not p.name.startswith('progress_'):copy(p,kit/'results'/p.name)
copy(root/'source_review/scripts/configure_observation_debug_ip.tcl',kit/'source_review/scripts/configure_observation_debug_ip.tcl')
bundle=kit/'source_review.bundle'
copy(root/'results/source_review.bundle',bundle)
subprocess.run(['git','-C',str(root/'source_review'),'bundle','verify',str(bundle)],check=True,capture_output=True)
if preflight:
    rows=[dict(path=p.relative_to(kit).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(kit.rglob('*')) if p.is_file()]
    (kit/'PACKAGE_MANIFEST.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    dest=delivery/'obsfix_sourcekit.zip'
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(kit.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(kit).as_posix())
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for row in rows:
            data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    (delivery/'PREVIEW_NOT_T5_COMPLETE.json').write_text(json.dumps(dict(status='SOURCEKIT_DRAFT_ONLY',T5='NOT_COMPLETE',T6='NOT_RUN',archive_sha256=sha(dest),source_commit=json.loads((root/'results/source_revision.json').read_text())['fix_commit']),indent=2),encoding='utf-8')
    print('SOURCEKIT_PREFLIGHT_DRAFT_NOT_T5',len(rows),sha(dest))
    raise SystemExit(0)
tree(root/'results',evidence/'results',lambda p: p.suffix in ['.rpt','.log','.jou','.json','.md','.csv','.patch','.tcl','.v','.txt','.xdc','.py','.mem'] and 'xsim.dir' not in p.parts and 'ip' not in p.parts and not p.name.startswith('progress_'))
tree(root/'scripts',evidence/'scripts',lambda p:p.suffix in ['.py','.ps1','.tcl'])
for sim in ['controlled_fix01','multiframe_fix01','controlled_fix15001','multiframe_fix15001']:
    source=root/'candidate/sim'/sim
    result=json.loads((source/'result.json').read_text(encoding='utf-8'));assert result['status']=='PASS'
    tree(source,evidence/'sim'/sim,lambda p:len(p.relative_to(source).parts)==1 and p.suffix in ['.txt','.json','.log','.jou','.mem','.v'])
object_index={};frozen_index=[]
def keep_object(p):
    h=sha(p);rel='objects/'+h+p.suffix
    if h not in object_index:
        copy(p,checkpoint/rel);object_index[h]=dict(relative_path=rel,bytes=p.stat().st_size,sha256=h)
    return object_index[h]['relative_path']
for stage in sorted((root/'impl').iterdir()):
    if not stage.is_dir():continue
    tree(stage,evidence/'impl'/stage.name,lambda p:(len(p.relative_to(stage).parts)==1 and p.suffix in ['.json','.log','.jou','.tcl']) or (p.parent.name=='reports' and p.suffix in ['.rpt','.xdc','.txt']))
    for p in stage.glob('*.dcp'):
        frozen_index.append(dict(kind='checkpoint',original_path=str(p),artifact=keep_object(p),sha256=sha(p)))
    for r in json.loads((stage/'frozen_inputs.json').read_text(encoding='utf-8')):
        p=Path(r['copy']);assert sha(p)==r['sha256']
        frozen_index.append(dict(kind='frozen_input',attempt=stage.name,original_path=r['source'],frozen_path=r['copy'],artifact=keep_object(p),sha256=r['sha256']))
    if (stage/'bitgen01').exists():
        tree(stage/'bitgen01',evidence/'impl'/stage.name/'bitgen01',lambda p:p.suffix not in ['.bit','.ltx'])
for variant in ['iporig','ipdata']:
    for p in (root/'results'/variant).rglob('*.xci'):
        copy(p,evidence/'diagnostic_ip_configs'/variant/p.relative_to(root/'results'/variant))
    p=root/'results'/variant/'ip/ila_obs_snapshot/ila_obs_snapshot/ila_obs_snapshot.dcp'
    frozen_index.append(dict(kind='diagnostic_ILA_OOC',variant=variant,original_path=str(p),artifact=keep_object(p),sha256=sha(p)))
supplement=root.parent/'.artifacts/c_handoff_audit_20261004/supplement_d6b13e6/failed_dcp'
for p in supplement.glob('candidate*_postroute.dcp'):
    frozen_index.append(dict(kind='original_C_failed_DCP_readonly_diagnostic',original_path=str(p),artifact=keep_object(p),sha256=sha(p)))
(checkpoint/'object_index.json').write_text(json.dumps(dict(objects=list(object_index.values()),provenance=frozen_index),indent=2),encoding='utf-8')
board=delivery/'board_images';board.mkdir()
for stage,r in ready:
    name=f"{r['freq_MHz']}mhz_pause{r['pause']}"
    for a in r['artifacts']:copy(Path(a['path']),board/name/Path(a['path']).name)
    copy(stage/'board_ready.json',board/name/'board_ready.json')
    copy(stage/'implementation_result.json',board/name/'implementation_result.json')
for name in ['C_BOARD_GUIDE.md','T5_delivery.json','T5_delivery.md','MORNING_REVIEW.md','REBUILD_GUIDE.md']:
    copy(root/'results'/name,delivery/name)
tree(root/'scripts',board/'scripts',lambda p:p.name in ['export_vio.tcl','decode_snapshots.py'])
copy(capture,board/'scripts/capture_uart_frames.ps1')
tree(root/'contracts',board/'contracts')
for name in ['C_BOARD_GUIDE.md','T5_delivery.json','T5_delivery.md']:copy(root/'results'/name,board/name)
archives=[]
for folder in [kit,evidence,checkpoint,board]:
    rows=[dict(path=p.relative_to(folder).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(folder.rglob('*')) if p.is_file()]
    (folder/'PACKAGE_MANIFEST.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    dest=delivery/f'obsfix_{folder.name}.zip'
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(folder).as_posix())
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for row in rows:
            data=z.read(row['path']);assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
    archives.append(dict(path=dest.name,bytes=dest.stat().st_size,sha256=sha(dest),members=len(rows)+1,verified='CRC and every member raw SHA/length'))
(delivery/'DELIVERY_MANIFEST.json').write_text(json.dumps(dict(created=datetime.datetime.now().astimezone().isoformat(),status='BOARD_READY',T6='NOT_RUN',archives=archives),indent=2),encoding='utf-8')
print(json.dumps(archives))
