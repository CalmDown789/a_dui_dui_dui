from pathlib import Path
import sys,shutil,json,hashlib
root=Path(__file__).resolve().parents[1]
previous=root/'impl'/sys.argv[1];stage=root/'impl'/sys.argv[2]
assert previous.is_dir() and (previous/'synth_setup030.dcp').is_file()
stage.mkdir(exist_ok=False);(stage/'reports').mkdir()
manifest=json.loads((previous/'stage6_build_manifest.json').read_text(encoding='utf-8'))
for row in manifest['inputs']:
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
for p in previous.glob('*.mem'):shutil.copyfile(p,stage/p.name)
shutil.copytree(previous/'ip',stage/'ip')
source=stage/'source_synth.dcp';shutil.copyfile(previous/'synth_setup030.dcp',source)
source_sha=hashlib.sha256(source.read_bytes()).hexdigest()
assert source_sha==hashlib.sha256((previous/'synth_setup030.dcp').read_bytes()).hexdigest()
for p in (previous/'reports').iterdir():
    if p.is_file():shutil.copyfile(p,stage/'reports'/p.name)
place=(root/'original/scripts/stage6_place_from_synth_dcp.tcl').read_text(encoding='utf-8')
start=place.index('if {![file isfile $source_dcp]}')
place='''set_param general.maxThreads 2
if {[llength $argv]!=1} {error "usage: continuation <new_stage>"}
set stage [lindex $argv 0]
set source_dcp "$stage/source_synth.dcp"
'''+place[start:]
freq=str(manifest['freq_MHz'])
place=place.replace('1000.0/150.0','1000.0/'+freq+'.0')
insert=place.index('opt_design')
check='''set counts {}
foreach ref {b_core_real b_core_stub fsrcnn_network_mem_top fsrcnn_stream_layer pixel_shuffle2x_row_banks elastic_fifo ila_obs_snapshot vio_obs_snapshot_ctrl} {
    if {$ref eq "ila_obs_snapshot" || $ref eq "vio_obs_snapshot_ctrl"} {
        set query "REF_NAME == $ref"
    } else {set query "REF_NAME =~ $ref*"}
    lappend counts [llength [get_cells -quiet -hier -filter $query]]
}
lassign $counts a b c d e f g h
puts "STAGE6_HIERARCHY b_core_real=$a b_core_stub=$b network=$c layers=$d pixel_shuffle=$e fifo=$f ila=$g vio=$h"
if {$a!=1 || $b!=0 || $c!=1 || $d!=5 || $e!=1 || $f<4 || $g!=1 || $h!=1} {error "continuation hierarchy mismatch"}
'''
place=place[:insert]+check+place[insert:]
route=(root/'original/scripts/stage6_route_setup030.tcl').read_text(encoding='utf-8')
route=route[route.index('report_clocks -file "$out/clocks_route_setup030.rpt"'):]
(stage/'build.tcl').write_text(place+'\n'+route,encoding='utf-8')
manifest['inputs']+= [dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [source,stage/'build.tcl']]
manifest['continuation']=dict(previous=str(previous),cause='opt_design Synth20-411 with empty detail; no routed result; normal fresh session recovery',synth_source=str(previous/'synth_setup030.dcp'),synth_sha256=source_sha,copied_synthesis_reports='raw byte copies from previous attempt; not newly run synthesis',RTL_changed=False,physical_strategy_changed=False)
(stage/'stage6_build_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(stage/'continuation_input.json').write_text(json.dumps(manifest['continuation'],indent=2),encoding='utf-8')
print('CONTINUATION_PREPARED',stage.name,source_sha)
