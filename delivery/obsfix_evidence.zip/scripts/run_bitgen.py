from pathlib import Path
import sys,json,subprocess,datetime
root=Path(__file__).resolve().parents[1];stage=root/'impl'/sys.argv[1]
impl=json.loads((stage/'implementation_result.json').read_text(encoding='utf-8'))
assert impl['status']=='IMPLEMENTATION_PASS' and all(impl['gates'].values())
receipt=stage/'bitgen_command.json';assert not receipt.exists()
alias='Q:/impl/'+stage.name
cmd=['cmd.exe','/d','/c','F:/Xilinx/2025.2/Vivado/bin/vivado.bat','-mode','batch','-source','Q:/scripts/gated_bitgen.tcl','-log',alias+'/bitgen.log','-journal',alias+'/bitgen.jou','-tclargs',alias+'/postroute.dcp',str(impl['freq_MHz']),alias+'/bitgen01']
record=dict(status='RUNNING',command=cmd,start=datetime.datetime.now().astimezone().isoformat())
receipt.write_text(json.dumps(record,indent=2),encoding='utf-8')
with (stage/'bitgen_console.log').open('wb') as f:code=subprocess.call(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
record.update(status='TOOL_EXITED',exit_code=code,end=datetime.datetime.now().astimezone().isoformat())
receipt.write_text(json.dumps(record,indent=2),encoding='utf-8');print(json.dumps(record));sys.exit(code)
