from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[1]
fixed='6cc8ea4173d2a720f741e80b7cbd9279558ee93a'
assert subprocess.check_output(['git','-C',str(root/'b_fixed'),'rev-parse','HEAD']).decode().strip()==fixed
files={}
for glob in ['rtl/b_real_ae29515/stream/*.sv','experiments/l5_splitmem_20260924/rtl/b/*.sv','rom/member_a_d16_s8_m1_c16/*_packed.mem']:
    for p in (root/'b_fixed').glob(glob):
        rel=p.relative_to(root/'b_fixed').as_posix()
        data=subprocess.check_output(['git','-C',str(root/'b_fixed'),'show',fixed+':'+rel])
        assert p.read_bytes()==data,rel
        files[rel]=hashlib.sha256(data).hexdigest()
(root/'B_VERIFIED_BLOBS.json').write_text(json.dumps(dict(commit=fixed,mode='raw Git blob bytes',files=files),indent=2),encoding='utf-8')
print('FIXED_B_RAW_BLOBS_MATCH',len(files))
