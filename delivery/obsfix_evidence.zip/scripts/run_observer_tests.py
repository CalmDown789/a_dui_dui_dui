from pathlib import Path
import re,subprocess,json,hashlib,time,argparse
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--attempt',default='observer_tests01');args=parser.parse_args()
assert args.attempt.replace('_','').isalnum()
run=root/'results'/args.attempt;run.mkdir(exist_ok=False)
orig=(root/'original/overlay/multiframe/rtl/c_observation.v').read_text()
(run/'reference.v').write_text(orig.replace('module c_observation #(','module ref_observation #('))
tb=(root/'original/overlay/multiframe/tb/tb_c_observation.v').read_text()
tb16=tb.replace('.SNAPSHOT_COUNT(2)','.SNAPSHOT_COUNT(16)')
start=tb16.index('        // Two-slot capacity test')
tb16=tb16[:start]+'''        for (integer i=1;i<16;i=i+1) begin
            start_empty_frame(i);
            snapshot_select=i; #1;
            if (!snapshot_selected_valid || snapshot_selected_data[36:5]!==i)
                $fatal(1,"16-slot field or index mismatch");
        end
        if(snapshot_count!==16 || snapshot_overflow) $fatal(1,"16-slot capacity");
        start_empty_frame(32'hffffffff);
        if(snapshot_count!==16 || !snapshot_overflow) $fatal(1,"16-slot overflow");
        snapshot_select=0; #1;
        if(snapshot_selected_data[36:5]!==32'h1234abcd) $fatal(1,"slot0 overwritten");
        $display("RESULT: PASS 16 slots retained, overflow, injected hold errors=1/1");
        $finish;
    end
endmodule
'''
(run/'tb_selftest.v').write_text(tb16)
inst=re.search(r'    c_observation #\(.*?\n    \);',tb,re.S).group()
refinst=inst.replace('c_observation #','ref_observation #').replace(') dut (',') refdut (')
for name in ['snapshot_selected_data','snapshot_selected_valid','snapshot_count','snapshot_overflow']:
    refinst=refinst.replace('('+name+')','(ref_'+name+')')
prefix=tb[:tb.index('    initial begin')]
prefix=prefix.replace('    task defaults;', '''    wire [933:0] ref_snapshot_selected_data;
    wire ref_snapshot_selected_valid,ref_snapshot_overflow;
    wire [4:0] ref_snapshot_count;
'''+refinst+'\n    task defaults;')
names=re.findall(r'reg \[63:0\] (\w+);',orig)
compare='\n'.join(f'        if(dut.{n}!==refdut.{n}) $fatal(1,"counter mismatch {n}");' for n in names)
seed='\n'.join(f'                dut.{n}=seed; refdut.{n}=seed;' for n in names)
prefix+='''    reg [63:0] seed;
    integer cycle;
    always @(posedge clk) begin
        #2;
        if(rst_n) begin
            if({snapshot_selected_data,snapshot_selected_valid,snapshot_count,snapshot_overflow} !==
               {ref_snapshot_selected_data,ref_snapshot_selected_valid,ref_snapshot_count,ref_snapshot_overflow})
                $fatal(1,"31-field snapshot equivalence mismatch");
'''+compare+'''
        end
    end
    initial begin
        rst_n=0; defaults(); repeat(2) @(posedge clk);
        for(cycle=0;cycle<10000;cycle=cycle+1) begin
            @(negedge clk);
            rst_n=(cycle%137!=0);
            frame_start=(cycle%23==0); session_done=(cycle%23==21);
            expected_frame_id=cycle; uart_bytes=cycle;
            core_busy=$random; core_done=$random; uart_final_idle=$random;
            c2b_valid=$random; c2b_ready=$random; c2b_data=$random;
            b_out_valid=$random; b_out_ready=$random; b_out_data=$random;
            b_stripe_last=$random; b_frame_last=$random;
            pause_active=$random; pause_forced_block=$random;
            snapshot_select=cycle%2;
            core_proto_error=$random; core_overflow_error=$random;
            loader_protocol_error=$random; loader_frame_error_count=cycle;
            uart_framing_error_count=cycle;
            case(cycle%6)
                0:seed=64'hffff_ffff_ffff_ffff;
                1:seed=64'h0000_ffff_ffff_ffff;
                2:seed=64'h0000_0000_ffff_ffff;
                3:seed=64'h0000_0000_0000_ffff;
                4:seed=64'hffff_ffff_ffff_fffe;
                5:seed={$random,$random};
            endcase
            if(dut.inc64(seed)!==(seed+64'd1)) $fatal(1,"inc64 modulo arithmetic");
            if(cycle%7==0 && rst_n) begin
'''+seed+'''
            end
        end
        @(posedge clk); #3;
        $display("RESULT: PASS 10000-cycle old/new equivalence and seeded 16/32/48/64-bit rollover");
        $finish;
    end
endmodule
'''
(run/'tb_equivalence.v').write_text(prefix)
tools=Path(json.loads((root/'candidate/toolchain.json').read_text(encoding='utf-8'))['vivado_root'])/'bin'
records=[]
def call(name,args,label):
    command=['cmd.exe','/d','/c',str(tools/(name+'.bat')),*map(str,args)]
    start=time.time()
    with (run/(label+'.log')).open('wb') as out:
        code=subprocess.call(command,cwd=run,stdout=out,stderr=subprocess.STDOUT)
    records.append(dict(command=command,exit_code=code,seconds=time.time()-start,log=label+'.log'))
    assert code==0,label
for name,file in [('selftest','tb_selftest.v'),('equivalence','tb_equivalence.v')]:
    files=[root/'candidate/multiframe/rtl/c_observation.v',run/file]
    if name=='equivalence':files.append(run/'reference.v')
    call('xvlog',['--sv',*files],name+'_compile')
    call('xelab',['tb_c_observation','-s',name],name+'_elaborate')
    call('xsim',[name,'-runall'],name+'_run')
    assert 'RESULT: PASS' in (run/(name+'_run.log')).read_text(errors='replace')
(run/'result.json').write_text(json.dumps(dict(status='PASS',records=records,sources=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in [root/'candidate/multiframe/rtl/c_observation.v',run/'reference.v',run/'tb_selftest.v',run/'tb_equivalence.v']]),indent=2))
print('OBSERVER_TESTS_PASS')
