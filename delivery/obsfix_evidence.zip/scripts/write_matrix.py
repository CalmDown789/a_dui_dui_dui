from pathlib import Path
import json,datetime
root=Path(__file__).resolve().parents[1]
rows=[]
for stage in sorted((root/'impl').iterdir()):
    if not stage.is_dir():continue
    m=json.loads((stage/'stage6_build_manifest.json').read_text(encoding='utf-8'))
    row=dict(attempt=stage.name,freq_MHz=m['freq_MHz'],pause=m['pause'],status='PREPARED',T6='NOT_RUN')
    commandfile='command.json' if (stage/'command.json').exists() else 'command_reconstructed.json'
    for fname,key in [(commandfile,'command'),('implementation_result.json','implementation'),('board_ready.json','board_ready')]:
        p=stage/fname
        if p.exists():
            row[key]=json.loads(p.read_text(encoding='utf-8'))
            row['status']=row[key]['status']
    if row.get('command',{}).get('exit_code',0)!=0 and 'implementation' not in row:row['status']='TOOL_ERROR'
    if stage.name=='f100_p1_a01' and row['status']=='TOOL_ERROR':row['status']='TOOL_INTERNAL_ERROR'
    if stage.name=='f100_p1_a02' and row['status']=='TOOL_ERROR':row['status']='CHECK_SCRIPT_ERROR'
    if m.get('continuation'):row['synthesis_provenance']=m['continuation']
    if m.get('postroute_continuation'):row['postroute_provenance']=m['postroute_continuation']
    rows.append(row)
record=dict(updated=datetime.datetime.now().astimezone().isoformat(),T6='NOT_RUN',attempts=rows)
(root/'results/T4_attempt_matrix.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
lines=['# T4 实现逐轮记录','','新源码根链使用固定B6cc8ea4、完整板级XDC、真实B与ILA/VIO。接续均来自本轮相同源码的检查点，记录来源与SHA。实体T6未运行。','','| attempt | MHz | pause | 状态 | 名义 WNS / WHS / WPWS(ns) | 压力WNS(ns) |','|---|---:|---:|---|---|---:|']
for r in rows:
    i=r.get('implementation',{});n=i.get('nominal',{});p=i.get('pressure',{})
    metric=' / '.join(f"{n[k]:+.3f}" for k in ['WNS','WHS','WPWS']) if n else '—'
    pressure=f"{p['WNS']:+.3f}" if p else '—'
    lines.append(f"| {r['attempt']} | {r['freq_MHz']} | {r['pause']} | {r['status']} | {metric} | {pressure} |")
lines+=['','100MHz pause1 a01 的Synth20-411是综合后opt工具内部错误；a02是检查脚本广义IP匹配导致统计错误，尚未运行opt；a03准确匹配顶层IP并正常接续同SHA综合DCP。各轮错误、来源报告与原控制台均保留。','','150MHz pause0 a01 的26条setup失败为C header解析至错误计数控制。a02增加布线后AggressiveExplore物理优化再NoTimingRelaxation，仍在+0.300ns压力下搜索、签核恢复原0.000ns用户uncertainty并保持jitter。最终是否通过以表内真实签核为准。','','所有BIT由独立门控生成并从同DCP写LTX，934位DATA/九个触发探针、VIO布局及实际hub时钟逐项校验；报告名义/压力分开，不把压力失败登记为原约束失败，不删去原约束失败。']
(root/'results/T4_implementation.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
print([(r['attempt'],r['status']) for r in rows])
