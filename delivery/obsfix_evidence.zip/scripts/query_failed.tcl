set_param general.maxThreads 2
set root [lindex $argv 0]
set out [lindex $argv 1]
file mkdir $out
cd $out
open_checkpoint $root
set fp [open "$out/properties.txt" w]
puts $fp "PART=[get_property PART [current_design]] TOP=[get_property NAME [current_design]]"
foreach pattern {*pending1_reg* *elapsed_cycles_q_reg* *frame_start_reg*} {
 foreach c [get_cells -quiet -hier -filter "NAME =~ $pattern"] {
  puts $fp "CELL=$c REF=[get_property REF_NAME $c] DONT_TOUCH=[get_property DONT_TOUCH $c]"
  foreach n [get_nets -quiet -of_objects [get_pins -quiet $c/Q]] {
   puts $fp "NET=$n LOADS=[llength [get_pins -quiet -leaf -of_objects $n -filter {DIRECTION == IN}]] DONT_TOUCH=[get_property DONT_TOUCH $n]"
  }
 }
}
close $fp
report_timing_summary -delay_type min_max -report_unconstrained -file "$out/timing.rpt"
report_timing -delay_type max -max_paths 30 -input_pins -nets -file "$out/paths.rpt"
report_timing -delay_type max -to [get_pins -quiet -hier -filter {NAME =~ *u_observation*/*/D}] -max_paths 20 -nets -file "$out/observer_paths.rpt"
report_timing -delay_type max -from [get_pins -quiet -hier -filter {NAME =~ *l5/*pending1_reg*/Q}] -max_paths 10 -nets -file "$out/pending_paths.rpt"
report_property [get_cells u_obs_ila] -file "$out/ila_properties.rpt"
report_clocks -file "$out/clocks.rpt"
puts "QUERY_COMPLETE"
