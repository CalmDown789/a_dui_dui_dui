set_param general.maxThreads 2
if {[llength $argv]!=1} {error "usage: postroute <fresh_stage>"}
set stage [lindex $argv 0]
set out "$stage/reports"
open_checkpoint "$stage/source_postroute.dcp"
if {[get_property PART [current_design]] ne "xc7a200tfbg484-2"} {error "part mismatch"}
set_property SEVERITY Error [get_drc_checks {NSTD-1 UCIO-1}]
set cp [get_pins -quiet {u_multiframe/g_mmcm.u_mmcm/CLKOUT0}]
set cc [get_clocks -quiet -of_objects $cp]
if {[llength $cc]!=1 || abs([get_property PERIOD $cc]-1000.0/150.0)>0.001} {error "clock mismatch"}
set counts {}
foreach ref {b_core_real b_core_stub fsrcnn_network_mem_top fsrcnn_stream_layer pixel_shuffle2x_row_banks elastic_fifo ila_obs_snapshot vio_obs_snapshot_ctrl} {
    if {$ref eq "ila_obs_snapshot" || $ref eq "vio_obs_snapshot_ctrl"} {set query "REF_NAME == $ref"} else {set query "REF_NAME =~ $ref*"}
    lappend counts [llength [get_cells -quiet -hier -filter $query]]
}
lassign $counts a b c d e f g h
puts "STAGE6_HIERARCHY b_core_real=$a b_core_stub=$b network=$c layers=$d pixel_shuffle=$e fifo=$f ila=$g vio=$h"
if {$a!=1 || $b!=0 || $c!=1 || $d!=5 || $e!=1 || $f<4 || $g!=1 || $h!=1} {error "hierarchy mismatch"}
set header [get_cells -quiet {u_multiframe/u_frame_loader/header_q_reg[12]}]
set errorq [get_cells -quiet {u_multiframe/u_frame_loader/frame_error_count_reg[10]}]
report_property $header -file "$out/focus_header_property.rpt"
report_property $errorq -file "$out/focus_error_property.rpt"
set ce [get_pins -of_objects $errorq -filter REF_PIN_NAME==CE]
report_property [get_nets -of_objects $ce] -file "$out/focus_ce_net_property.rpt"
report_timing -to $ce -max_paths 10 -file "$out/focus_before.rpt"
set_clock_uncertainty -setup -from $cc -to $cc 0.300
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_before_postroute_opt_setup030.rpt"
phys_opt_design -directive AggressiveExplore
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_after_postroute_opt_setup030.rpt"
report_clocks -file "$out/clocks_route_setup030.rpt"
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_before_route_setup030.rpt"
route_design -directive NoTimingRelaxation
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_summary_route_setup030.rpt"

# Keep the same routed physical solution. Restore only the added user setup
# uncertainty to the original XDC value (0.000 ns), retaining device jitter.
set_clock_uncertainty -setup -from $cc -to $cc 0.000
update_timing
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 100 -file "$out/timing_summary_postroute.rpt"
report_timing -delay_type max -max_paths 100 -nworst 1 -file "$out/setup_paths_postroute.rpt"
report_timing -delay_type min -max_paths 100 -nworst 1 -file "$out/hold_paths_postroute.rpt"
report_utilization -file "$out/utilization_postroute.rpt"
report_utilization -hierarchical -file "$out/utilization_postroute_hier.rpt"
report_route_status -file "$out/route_status_postroute.rpt"
report_clocks -file "$out/clocks_postroute.rpt"
report_io -file "$out/io_postroute.rpt"
report_exceptions -coverage -file "$out/exceptions_postroute.rpt"
check_timing -verbose -file "$out/check_timing_postroute.rpt"
report_drc -file "$out/drc_postroute.rpt"
catch {report_ram_utilization -file "$out/ram_utilization_postroute.rpt"}
write_xdc -force "$out/constraints_restored.xdc"
write_checkpoint -force "$stage/postroute.dcp"
puts "STAGE6_ROUTE_COMPLETE=$stage/postroute.dcp"
puts "STAGE6_BITSTREAM_NOT_GENERATED=1"
