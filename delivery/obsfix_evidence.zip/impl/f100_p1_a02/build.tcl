set_param general.maxThreads 2
if {[llength $argv]!=1} {error "usage: continuation <new_stage>"}
set stage [lindex $argv 0]
set source_dcp "$stage/source_synth.dcp"
if {![file isfile $source_dcp]} { error "candidate synthesis DCP missing: $source_dcp" }
if {![file isdirectory $stage]} { error "fresh output attempt directory missing: $stage" }
if {[file exists "$stage/placed_setup030.dcp"]} { error "refusing to overwrite placed candidate DCP" }
set out "$stage/reports"
file mkdir $out
cd $stage
open_checkpoint $source_dcp

if {[get_property PART [current_design]] ne "xc7a200tfbg484-2"} {
    error "candidate synthesis checkpoint part mismatch"
}
set_property SEVERITY Error [get_drc_checks {NSTD-1 UCIO-1}]
set cp [get_pins -quiet {u_multiframe/g_mmcm.u_mmcm/CLKOUT0}]
set cc [get_clocks -quiet -of_objects $cp]
if {[llength $cp] != 1 || [llength $cc] != 1 || abs([get_property PERIOD $cc] - 1000.0/100.0) > 0.001} {
    error "fresh candidate synthesis DCP is not constrained at 150 MHz"
}

puts "STAGE6_CONTINUATION_SOURCE=$source_dcp"
puts "STAGE6_CONTINUATION_CWD=[pwd]"
report_clocks -file "$out/clocks_loaded_setup030.rpt"
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_loaded_setup030.rpt"
report_drc -file "$out/drc_loaded_setup030.rpt"

set counts {}
foreach ref {b_core_real b_core_stub fsrcnn_network_mem_top fsrcnn_stream_layer pixel_shuffle2x_row_banks elastic_fifo ila_obs_snapshot vio_obs_snapshot_ctrl} {
    lappend counts [llength [get_cells -quiet -hier -filter "REF_NAME =~ $ref*"]]
}
lassign $counts a b c d e f g h
puts "STAGE6_HIERARCHY b_core_real=$a b_core_stub=$b network=$c layers=$d pixel_shuffle=$e fifo=$f ila=$g vio=$h"
if {$a!=1 || $b!=0 || $c!=1 || $d!=5 || $e!=1 || $f<4 || $g!=1 || $h!=1} {error "continuation hierarchy mismatch"}
opt_design
place_design -directive ExtraNetDelay_high
phys_opt_design -directive AggressiveExplore
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_placed_setup030.rpt"
report_clocks -file "$out/clocks_placed_setup030.rpt"
write_checkpoint -force "$stage/placed_setup030.dcp"
puts "STAGE6_PLACEMENT_SETUP030_COMPLETE=$stage/placed_setup030.dcp"

report_clocks -file "$out/clocks_route_setup030.rpt"
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_before_route_setup030.rpt"
route_design -directive NoTimingRelaxation
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 30 -file "$out/timing_summary_route_setup030.rpt"

# Keep the same routed physical solution. Restore only the added user setup
# uncertainty to the original XDC value (0.000 ns), retaining device jitter.
set_clock_uncertainty -setup -from $cc -to $cc 0.000
update_timing
report_timing_summary -delay_type min_max -report_unconstrained -max_paths 100 -file "$out/timing_summary_postroute.rpt"
report_timing -delay_type max -max_paths 100 -nworst 1 -file "$out/setup_paths_postroute.rpt"
report_timing -delay_type min -max_paths 100 -nworst 1 -file "$out/hold_paths_postroute.rpt"
report_utilization -file "$out/utilization_postroute.rpt"
report_utilization -hierarchical -file "$out/utilization_postroute_hier.rpt"
report_route_status -file "$out/route_status_postroute.rpt"
report_clocks -file "$out/clocks_postroute.rpt"
report_io -file "$out/io_postroute.rpt"
report_exceptions -coverage -file "$out/exceptions_postroute.rpt"
check_timing -verbose -file "$out/check_timing_postroute.rpt"
report_drc -file "$out/drc_postroute.rpt"
catch {report_ram_utilization -file "$out/ram_utilization_postroute.rpt"}
write_xdc -force "$out/constraints_restored.xdc"
write_checkpoint -force "$stage/postroute.dcp"
puts "STAGE6_ROUTE_COMPLETE=$stage/postroute.dcp"
puts "STAGE6_BITSTREAM_NOT_GENERATED=1"
