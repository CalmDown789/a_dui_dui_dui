# T1 根因证据（2026-10-05）

固定 C 86df150 / B 6cc8ea4 / Vivado 2025.2 build 6299465 / xc7a200tfbg484-2。原失败 DCP 只读，100/150MHz查询报告分别在 query100、query150。

1. **934位探针的触发匹配配置是ILA长进位路径的原因，已有单变量实证。** 原配置 probe1 TYPE=0(DATA_AND_TRIGGER)，同一生成器仅改 TYPE=1(DATA)，其余宽度、深度1024、九个状态探针、输入流水0不变。OOC综合按同一6.666667ns时钟报告：原最差13.389ns、117 CARRY4+SRL16E，WNS -6.904ns；修改后最差3.104ns、LUT2/LUT3/SRLC32E，WNS +3.133ns。ILA总CARRY4由148到30。证据 iporig/paths.rpt、ipdata/paths.rpt、两份utilization及XCI。OOC估计不能替代完整后布线；加密网表未揭示具体运算，不命名为已确认的934位比较器结构。

2. **观察器原64位增量实现存在frame_start进入长进位链的路径。** 原150MHz路径frame_start_reg→output_blocked_cycles_q[61]，12.302ns，其中逻辑2.284/布线10.018ns、13CARRY4+LUT2，slack -5.805ns。源控制网所查询负载634。证据 query150/observer_paths.rpt与properties.txt。修复采用精确分段增量，是否成功缩短物理路径须等新实现报告；不能仅凭RTL表达式推断时序PASS。

3. **B pending1问题依频率/物理构建而异。** 原100MHz只有一个源寄存器，负载6406，pending1→shift_reg CE路径12.522ns、布线12.089ns，slack -2.754ns。原150MHz已有多个复制寄存器，所列副本网121–245负载；最差所查询pending1路径仍 -0.600ns、布线6.146ns。查询未发现显式DONT_TOUCH=1，不能断言ILA属性禁止复制，或笼统说150MHz也未复制。原150/100实现时钟、物理搜索均不同，不是证明因果的单变量对照。首次候选保持原物理策略和固定B，不以盲目移除消费者/完整route矩阵凑证据；若剩余失败再依据新报告作窄范围物理处理。

query150最后report_property命令因选到324对象退出1，之前DCP读取、属性、完整时序及两类专项路径均实际生成；错误是报告对象数量错误，不能登记成硬件失败或完整脚本PASS。query100修正为顶层ILA单对象后完整退出0。初次诊断ILA在synth_ip完成后open_run找不到project run退出1；使用其实际DCP另开query_ip成功。所有原日志保留。

无移除ILA/观察器的诊断构建登记为交付通过。真实完整候选仍含31字段/934位/16槽及ILA+VIO消费者。

## 新源码完整实现的后续证据

100MHz普通版完整新源码流名义WNS+0.717ns，压力+0.417ns；最差仍是固定B pending1至shift_reg CE（数据9.044ns/布线8.665ns），因此不能把时序通过描述为该高扇出根因已经从结构上消除。观察器4007 LUT/13604 FF，完整ILA/VIO保留，内部覆盖检查通过。

150MHz普通版首轮名义-0.141ns/TNS-1.704ns/26端点，已经集中至C header_q[12]→frame_error_count[10]/CE，11级、数据6.548ns（逻辑2.002/布线4.546），末级CE网32负载。原首轮完整流及新的焦点属性/路径报告在f150_p0_a01/a02，不能把该剩余控制路径误称为ILA117级链仍存在。

a02从同修正源码首轮postroute DCP接续，添加一次布线后AggressiveExplore物理优化，原NoTimingRelaxation再布线。名义+0.404ns/TNS0，压力+0.104ns/TNS0；最差转为VIO内部4级路径，数据6.084ns。hold+0.022ns、pulse+2.203ns、route全通/DRC Error0，观察器4078 LUT/13604 FF、ILA/VIO消费者保留。该过程不改C loader/B RTL，不改XDC或时序例外；只能说明本轮物理设计门控通过，不从加密VIO名称推断内部具体操作。

150MHz受控暂停版也已完成独立源码原可比完整流：原约束WNS+0.252ns/TNS0、hold+0.014ns、pulse+2.203ns，108090路由全通，DRC Error0、内部覆盖/真实B/原XDC门控通过。最差为B shuffle BRAM输出→观察器b_output_hold_violation_count[0]/CE，数据6.178ns（逻辑2.755/布线3.423）、6级LUT；观察器4686 LUT/15796 FF保留。额外压力WNS-0.048ns/TNS-0.397ns/10端点未过，原样保留，不混称压力通过。其同DCP BIT/LTX通过独立门控与配置核验，仅BOARD_READY；最终四组合见T4/T5。
