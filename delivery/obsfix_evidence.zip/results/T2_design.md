# T2 最小修正

当前候选：candidate/multiframe/rtl/c_observation.v。原件：original/overlay/multiframe/rtl/c_observation.v。

- 所有`q + 64'd1`改为`inc64(q)`。四个16位分段各自加0/1，进位条件为旧值低16/32/48位全1。其值严格等于原64位模2^64增量，未缩窄、饱和、漏拍或增加计量延迟。reset/frame_start/active优先关系、首拍握手、末拍记录、snapshot拼接、16槽存储与真实握手均不变。
- ILA probe1(934位)改DATA，保留所有934位采样；trigger使用原其余九个小探针（valid、slot、start、busy、done、frame_done、pause、forced、overflow）。深度1024、输入流水0。完整字段与VIO读取布局不变。不得再对probe1设置宽值触发；这不是删掉字段。
- 固定B RTL未改；原C XDC逐字节保留；原ExtraNetDelay_high/AggressiveExplore/NoTimingRelaxation及L5 phase MAX_FANOUT48流保留。完整主实现不复用旧DCP。所有attempt独立保存输入哈希。

原观察器session_done沿按原非阻塞赋值语义保存计数器旧值，而elapsed字段显式+1；本补丁保持此行为，未顺便改变同拍快照语义。对应原契约和真实loader的帧完成关系继续沿用。长期累计sticky错误仍按原源寄存器取样，不变成每帧独占计数。

IP单变量对照、旧新逐拍对照、自检与真实B回归见T1/T3。物理结果与BIT/LTX只在T4/T5门控后发布。

2026-10-05物理接续：首个完整流保留原全部指令。150MHz普通版a01修正源码仍在C header解析→错误计数CE路径名义-0.141ns/26端点失败，因此a02仅增加一次布线后AggressiveExplore，再用原NoTimingRelaxation布线；从本轮新源码DCP接续，未增加时序例外/未改RTL，+0.300ns搜索、恢复原用户0.000ns且保留jitter。实际名义WNS+0.404ns、压力+0.104ns、hold+0.022ns、pulse+2.203ns。其后布线观察器4078 LUT/13604 FF、ILA/VIO完整保留，没有通过去掉消费者让观察器消失。此物理配方变化与原可比失败逐轮单独记录，见T4与REBUILD_GUIDE。
