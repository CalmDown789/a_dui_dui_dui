`timescale 1ns / 1ps
module tb_c_observation;
    reg clk = 1'b0;
    always #5 clk = ~clk;

    reg rst_n;
    reg frame_start;
    reg session_done;
    reg [31:0] expected_frame_id;
    reg [31:0] uart_bytes;
    reg core_busy;
    reg core_done;
    reg uart_final_idle;
    reg core_proto_error;
    reg core_overflow_error;
    reg loader_protocol_error;
    reg [31:0] loader_frame_error_count;
    reg [31:0] uart_framing_error_count;
    reg c2b_valid;
    reg c2b_ready;
    reg [7:0] c2b_data;
    reg b_out_valid;
    reg [7:0] b_out_data;
    reg b_out_ready;
    reg b_stripe_last;
    reg b_frame_last;
    reg pause_active;
    reg pause_forced_block;
    reg [3:0] snapshot_select;
    wire [933:0] snapshot_selected_data;
    wire snapshot_selected_valid;
    wire [4:0] snapshot_count;
    wire snapshot_overflow;

    c_observation #(
        .EXPECTED_INPUTS(3),
        .EXPECTED_OUTPUTS(3),
        .SNAPSHOT_COUNT(2)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .frame_start(frame_start), .session_done(session_done),
        .expected_frame_id(expected_frame_id), .uart_bytes(uart_bytes),
        .core_busy(core_busy), .core_done(core_done),
        .uart_final_idle(uart_final_idle),
        .core_proto_error(core_proto_error),
        .core_overflow_error(core_overflow_error),
        .loader_protocol_error(loader_protocol_error),
        .loader_frame_error_count(loader_frame_error_count),
        .uart_framing_error_count(uart_framing_error_count),
        .c2b_valid(c2b_valid), .c2b_ready(c2b_ready), .c2b_data(c2b_data),
        .b_out_valid(b_out_valid), .b_out_data(b_out_data),
        .b_out_ready(b_out_ready), .b_stripe_last(b_stripe_last),
        .b_frame_last(b_frame_last), .pause_active(pause_active),
        .pause_forced_block(pause_forced_block),
        .snapshot_select(snapshot_select),
        .snapshot_selected_data(snapshot_selected_data),
        .snapshot_selected_valid(snapshot_selected_valid),
        .snapshot_count(snapshot_count), .snapshot_overflow(snapshot_overflow)
    );

    wire [933:0] ref_snapshot_selected_data;
    wire ref_snapshot_selected_valid,ref_snapshot_overflow;
    wire [4:0] ref_snapshot_count;
    ref_observation #(
        .EXPECTED_INPUTS(3),
        .EXPECTED_OUTPUTS(3),
        .SNAPSHOT_COUNT(2)
    ) refdut (
        .clk(clk), .rst_n(rst_n),
        .frame_start(frame_start), .session_done(session_done),
        .expected_frame_id(expected_frame_id), .uart_bytes(uart_bytes),
        .core_busy(core_busy), .core_done(core_done),
        .uart_final_idle(uart_final_idle),
        .core_proto_error(core_proto_error),
        .core_overflow_error(core_overflow_error),
        .loader_protocol_error(loader_protocol_error),
        .loader_frame_error_count(loader_frame_error_count),
        .uart_framing_error_count(uart_framing_error_count),
        .c2b_valid(c2b_valid), .c2b_ready(c2b_ready), .c2b_data(c2b_data),
        .b_out_valid(b_out_valid), .b_out_data(b_out_data),
        .b_out_ready(b_out_ready), .b_stripe_last(b_stripe_last),
        .b_frame_last(b_frame_last), .pause_active(pause_active),
        .pause_forced_block(pause_forced_block),
        .snapshot_select(snapshot_select),
        .snapshot_selected_data(ref_snapshot_selected_data),
        .snapshot_selected_valid(ref_snapshot_selected_valid),
        .snapshot_count(ref_snapshot_count), .snapshot_overflow(ref_snapshot_overflow)
    );
    task defaults;
    begin
        frame_start = 0; session_done = 0; expected_frame_id = 0; uart_bytes = 0;
        core_busy = 0; core_done = 0; uart_final_idle = 0;
        core_proto_error = 0; core_overflow_error = 0; loader_protocol_error = 0;
        loader_frame_error_count = 0; uart_framing_error_count = 0;
        c2b_valid = 0; c2b_ready = 0; c2b_data = 0;
        b_out_valid = 0; b_out_data = 0; b_out_ready = 0;
        b_stripe_last = 0; b_frame_last = 0;
        pause_active = 0; pause_forced_block = 0; snapshot_select = 0;
    end
    endtask

    task start_empty_frame;
        input [31:0] fid;
    begin
        @(negedge clk);
        frame_start = 1; expected_frame_id = fid; core_busy = 1;
        @(posedge clk); #1;
        @(negedge clk);
        frame_start = 0; core_busy = 0; core_done = 1;
        session_done = 1; uart_final_idle = 1;
        @(posedge clk); #1;
        @(negedge clk);
        session_done = 0; core_done = 0; uart_final_idle = 0;
    end
    endtask

    reg [63:0] seed;
    integer cycle;
    always @(posedge clk) begin
        #2;
        if(rst_n) begin
            if({snapshot_selected_data,snapshot_selected_valid,snapshot_count,snapshot_overflow} !==
               {ref_snapshot_selected_data,ref_snapshot_selected_valid,ref_snapshot_count,ref_snapshot_overflow})
                $fatal(1,"31-field snapshot equivalence mismatch");
        if(dut.elapsed_cycles_q!==refdut.elapsed_cycles_q) $fatal(1,"counter mismatch elapsed_cycles_q");
        if(dut.core_span_cycles_q!==refdut.core_span_cycles_q) $fatal(1,"counter mismatch core_span_cycles_q");
        if(dut.last_input_cycle_q!==refdut.last_input_cycle_q) $fatal(1,"counter mismatch last_input_cycle_q");
        if(dut.last_output_cycle_q!==refdut.last_output_cycle_q) $fatal(1,"counter mismatch last_output_cycle_q");
        if(dut.output_blocked_cycles_q!==refdut.output_blocked_cycles_q) $fatal(1,"counter mismatch output_blocked_cycles_q");
        if(dut.b_input_wait_cycles_q!==refdut.b_input_wait_cycles_q) $fatal(1,"counter mismatch b_input_wait_cycles_q");
        if(dut.c2b_stall_cycles_q!==refdut.c2b_stall_cycles_q) $fatal(1,"counter mismatch c2b_stall_cycles_q");
        if(dut.joint_stall_cycles_q!==refdut.joint_stall_cycles_q) $fatal(1,"counter mismatch joint_stall_cycles_q");
        if(dut.pause_request_cycles_q!==refdut.pause_request_cycles_q) $fatal(1,"counter mismatch pause_request_cycles_q");
        if(dut.pause_forced_block_cycles_q!==refdut.pause_forced_block_cycles_q) $fatal(1,"counter mismatch pause_forced_block_cycles_q");
        end
    end
    initial begin
        rst_n=0; defaults(); repeat(2) @(posedge clk);
        for(cycle=0;cycle<10000;cycle=cycle+1) begin
            @(negedge clk);
            rst_n=(cycle%137!=0);
            frame_start=(cycle%23==0); session_done=(cycle%23==21);
            expected_frame_id=cycle; uart_bytes=cycle;
            core_busy=$random; core_done=$random; uart_final_idle=$random;
            c2b_valid=$random; c2b_ready=$random; c2b_data=$random;
            b_out_valid=$random; b_out_ready=$random; b_out_data=$random;
            b_stripe_last=$random; b_frame_last=$random;
            pause_active=$random; pause_forced_block=$random;
            snapshot_select=cycle%2;
            core_proto_error=$random; core_overflow_error=$random;
            loader_protocol_error=$random; loader_frame_error_count=cycle;
            uart_framing_error_count=cycle;
            case(cycle%6)
                0:seed=64'hffff_ffff_ffff_ffff;
                1:seed=64'h0000_ffff_ffff_ffff;
                2:seed=64'h0000_0000_ffff_ffff;
                3:seed=64'h0000_0000_0000_ffff;
                4:seed=64'hffff_ffff_ffff_fffe;
                5:seed={$random,$random};
            endcase
            if(dut.inc64(seed)!==(seed+64'd1)) $fatal(1,"inc64 modulo arithmetic");
            if(cycle%7==0 && rst_n) begin
                dut.elapsed_cycles_q=seed; refdut.elapsed_cycles_q=seed;
                dut.core_span_cycles_q=seed; refdut.core_span_cycles_q=seed;
                dut.last_input_cycle_q=seed; refdut.last_input_cycle_q=seed;
                dut.last_output_cycle_q=seed; refdut.last_output_cycle_q=seed;
                dut.output_blocked_cycles_q=seed; refdut.output_blocked_cycles_q=seed;
                dut.b_input_wait_cycles_q=seed; refdut.b_input_wait_cycles_q=seed;
                dut.c2b_stall_cycles_q=seed; refdut.c2b_stall_cycles_q=seed;
                dut.joint_stall_cycles_q=seed; refdut.joint_stall_cycles_q=seed;
                dut.pause_request_cycles_q=seed; refdut.pause_request_cycles_q=seed;
                dut.pause_forced_block_cycles_q=seed; refdut.pause_forced_block_cycles_q=seed;
            end
        end
        @(posedge clk); #3;
        $display("RESULT: PASS 10000-cycle old/new equivalence and seeded 16/32/48/64-bit rollover");
        $finish;
    end
endmodule
