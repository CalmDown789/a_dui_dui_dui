# T4 实现逐轮记录

新源码根链使用固定B6cc8ea4、完整板级XDC、真实B与ILA/VIO。接续均来自本轮相同源码的检查点，记录来源与SHA。实体T6未运行。

| attempt | MHz | pause | 状态 | 名义 WNS / WHS / WPWS(ns) | 压力WNS(ns) |
|---|---:|---:|---|---|---:|
| f100_p0_a01 | 100 | 0 | BOARD_READY | +0.717 / +0.036 / +3.870 | +0.417 |
| f100_p1_a01 | 100 | 1 | TOOL_INTERNAL_ERROR | — | — |
| f100_p1_a02 | 100 | 1 | CHECK_SCRIPT_ERROR | — | — |
| f100_p1_a03 | 100 | 1 | BOARD_READY | +1.088 / +0.036 / +3.870 | +0.788 |
| f150_p0_a01 | 150 | 0 | IMPLEMENTATION_FAIL | -0.141 / +0.011 / +2.203 | -0.441 |
| f150_p0_a02 | 150 | 0 | BOARD_READY | +0.404 / +0.022 / +2.203 | +0.104 |
| f150_p1_a01 | 150 | 1 | BOARD_READY | +0.252 / +0.014 / +2.203 | -0.048 |

100MHz pause1 a01 的Synth20-411是综合后opt工具内部错误；a02是检查脚本广义IP匹配导致统计错误，尚未运行opt；a03准确匹配顶层IP并正常接续同SHA综合DCP。各轮错误、来源报告与原控制台均保留。

150MHz pause0 a01 的26条setup失败为C header解析至错误计数控制。a02增加布线后AggressiveExplore物理优化再NoTimingRelaxation，仍在+0.300ns压力下搜索、签核恢复原0.000ns用户uncertainty并保持jitter。最终是否通过以表内真实签核为准。

所有BIT由独立门控生成并从同DCP写LTX，934位DATA/九个触发探针、VIO布局及实际hub时钟逐项校验；报告名义/压力分开，不把压力失败登记为原约束失败，不删去原约束失败。
