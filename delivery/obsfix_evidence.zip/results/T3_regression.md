# T3 新候选实跑回归

2026-10-05，Vivado/XSim2025.2。下列均为新候选实跑，固定B=6cc8ea4，无混入200MHz源码。

| 用例 | 实际结果 | 原件 |
|---|---|---|
| 观察器31字段语义、自检、16槽及溢出 | PASS；首拍握手、最后握手、core_done/session_done、UART idle、stall/joint、pause及sticky错误取样；故意payload/sideband改变预期hold错误1/1；16槽保留，溢出不覆盖 | observer_tests01/selftest_run.log |
| 原/新观察器10000拍逐拍对照 | PASS；对全部64位计数器及所选934位快照/valid/count/overflow逐拍比较；随机信号/复位/帧边界；播种16/32/48/64位回卷边界；inc64与原64位加法一致 | observer_tests01/equivalence_run.log、TB、result.json |
| 真实B双帧96×54，暂停启用 | PASS；两个不同输入，每帧5184输入/20736 UART返回；Golden失配0；每帧16拍强制背压，合计32；正常hold0/0，两个槽计量正确 | candidate/sim/controlled_fix01/ |
| 真实B双帧96×54，普通暂停禁用 | PASS；两个不同输入、每帧20736 UART返回，Golden失配0，正常帧边界 | candidate/sim/multiframe_fix01/ |
| 150MHz真实B双帧96×54，暂停启用 | PASS；两帧UART各20736字节失配0；每帧pause/forced16拍、合计32、hold0/0，两个快照正确 | candidate/sim/controlled_fix15001/ |
| 150MHz真实B双帧96×54，普通暂停禁用 | PASS；两帧UART各20736字节失配0、帧计数正确 | candidate/sim/multiframe_fix15001/ |

前两组TB实际100MHz/DIV4，新增两组实际150MHz/DIV6；UART_BAUD均25M用于加速仿真，USE_MMCM=0。150MHz测试在独立run生成TB，只修改CLK_HZ和时钟半周期，原TB/RTL原字节未变；衍生配方、源哈希及所有编译/仿真退出码另存。MMCM、真实板级UART_BAUD和物理时序由完整实现及C板测确认。八个实际返回再次独立逐字节复核见T3_raw_uart_recheck.json。

两组真实B TB均从实际UART_TX串行引脚独立8N1解码，actual_frame0/1.mem保存返回；不是仅用输出总线推定串口正确。新候选只改只读观察器增量表达式和ILA probe匹配类型，未改变真实握手、缓冲、复位或帧末关系，因此复用已核验基线完整双帧数值证据；本轮没有重跑全尺寸双帧，不能称新候选全尺寸实跑。调试IP不参与RTL功能TB，必须由完整实现/LTX验证其实际配置，板读数仍由C的T6验证。

工程回归不改变用户掌握状态。完整板测、忙时复位、Flash自主启动、自然视频/播放、200MHz均不由本报告扩大为通过。
