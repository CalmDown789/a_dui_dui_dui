`timescale 1ns / 1ps

// 成员B工作 / Team member B: elastic multiply plus balanced reduction tree.
// One phase may enter each clock. Every tree level and its phase tag stop
// together under backpressure. The final 32-bit partial sum has the same
// wrap semantics as phase_mac_array; target DSP/timing mapping is unverified.
module phase_mac_pipeline #(
    parameter integer K=5,
    parameter integer CIN=16,
    parameter integer COUT=4,
    parameter integer IN_PAR=2,
    parameter integer OUT_PAR=4,
    parameter integer ACT_W=16,
    parameter integer ACT_UNSIGNED=0,
    parameter integer PIPE_SELECTED_OPERANDS=0
)(
    input  wire                              clk,
    input  wire                              rst,
    input  wire                              in_valid,
    output wire                              in_ready,
    input  wire [2:0]                        in_phase,
    input  wire [K*K*CIN*ACT_W-1:0]         window_flat,
    input  wire [COUT*CIN*K*K*8-1:0]        weight_flat,
    output wire                              out_valid,
    input  wire                              out_ready,
    output wire [2:0]                        out_phase,
    output wire [OUT_PAR*32-1:0]            partial_sums
);
    localparam integer TAPS=K*K;
    localparam integer TERMS=IN_PAR*TAPS;
    localparam integer LEVELS=(TERMS<=1)?0:$clog2(TERMS);
    localparam integer IN_GROUPS=CIN/IN_PAR;
    localparam integer MAX_TERMS=1<<LEVELS;
    reg [LEVELS+PIPE_SELECTED_OPERANDS:0] valid_q;
    reg [2:0] phase_q[0:LEVELS+PIPE_SELECTED_OPERANDS];
    reg signed [31:0] sums_q[0:LEVELS][0:OUT_PAR-1][0:MAX_TERMS-1];
    wire [LEVELS+PIPE_SELECTED_OPERANDS:0] ready;
    assign ready[LEVELS+PIPE_SELECTED_OPERANDS]=
        !valid_q[LEVELS+PIPE_SELECTED_OPERANDS]||out_ready;
    assign in_ready=ready[0];
    assign out_valid=valid_q[LEVELS+PIPE_SELECTED_OPERANDS];
    assign out_phase=phase_q[LEVELS+PIPE_SELECTED_OPERANDS];

    initial begin
        if((K!=1&&K!=3&&K!=5)||CIN<1||COUT<1||IN_PAR<1||OUT_PAR<1||
           CIN%IN_PAR!=0||COUT%OUT_PAR!=0||
           (CIN/IN_PAR)*(COUT/OUT_PAR)!=8||
           (ACT_W!=8&&ACT_W!=16)||
           (PIPE_SELECTED_OPERANDS!=0&&PIPE_SELECTED_OPERANDS!=1))
            $error("phase_mac_pipeline requires frozen eight-phase layout");
    end

    genvar o,n,s,j;
    generate
        for(o=0;o<OUT_PAR;o=o+1)begin:out_lane
            assign partial_sums[o*32+:32]=sums_q[LEVELS][o][0];
            for(n=0;n<TERMS;n=n+1)begin:mult_lane
                localparam integer I=n/TAPS;
                localparam integer TAP=n%TAPS;
                // Keep phase-dependent selection static at elaboration. A
                // variable part-select here makes Vivado build a wide,
                // general-purpose mux for every multiplier lane.
                reg [ACT_W-1:0] act;
                reg signed [7:0] weight;
                always @* begin
                    act = {ACT_W{1'b0}};
                    weight = 8'sd0;
                    case (in_phase)
                        3'd0: begin
                            act = window_flat[(TAP*CIN+((0%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((0/IN_GROUPS)*OUT_PAR+o)*CIN+((0%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        3'd1: begin
                            act = window_flat[(TAP*CIN+((1%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((1/IN_GROUPS)*OUT_PAR+o)*CIN+((1%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        3'd2: begin
                            act = window_flat[(TAP*CIN+((2%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((2/IN_GROUPS)*OUT_PAR+o)*CIN+((2%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        3'd3: begin
                            act = window_flat[(TAP*CIN+((3%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((3/IN_GROUPS)*OUT_PAR+o)*CIN+((3%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        3'd4: begin
                            act = window_flat[(TAP*CIN+((4%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((4/IN_GROUPS)*OUT_PAR+o)*CIN+((4%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        3'd5: begin
                            act = window_flat[(TAP*CIN+((5%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((5/IN_GROUPS)*OUT_PAR+o)*CIN+((5%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        3'd6: begin
                            act = window_flat[(TAP*CIN+((6%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((6/IN_GROUPS)*OUT_PAR+o)*CIN+((6%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        3'd7: begin
                            act = window_flat[(TAP*CIN+((7%IN_GROUPS)*IN_PAR+I))*ACT_W+:ACT_W];
                            weight = weight_flat[((((7/IN_GROUPS)*OUT_PAR+o)*CIN+((7%IN_GROUPS)*IN_PAR+I))*TAPS+TAP)*8+:8];
                        end
                        default: begin end
                    endcase
                end
                if(PIPE_SELECTED_OPERANDS!=0)begin:operand_pipe
                    (* DONT_TOUCH = "TRUE" *) reg [ACT_W-1:0] act_q;
                    (* DONT_TOUCH = "TRUE" *) reg signed [7:0] weight_q;
                    wire signed [ACT_W:0] act_q_ext;
                    if(ACT_UNSIGNED!=0)begin:unsigned_act_q
                        assign act_q_ext=$signed({1'b0,act_q});
                    end else begin:signed_act_q
                        assign act_q_ext=$signed({act_q[ACT_W-1],act_q});
                    end
                    (* use_dsp="yes" *) wire signed [ACT_W+8:0] product_q=act_q_ext*weight_q;
                    always @(posedge clk)if(ready[0]&&in_valid)begin
                        act_q<=act;
                        weight_q<=weight;
                    end
                    always @(posedge clk)if(ready[1]&&valid_q[0])
                        sums_q[0][o][n]<=product_q;
                end else begin:direct_product
                    wire signed [ACT_W:0] act_ext;
                    if(ACT_UNSIGNED!=0)begin:unsigned_act
                        assign act_ext=$signed({1'b0,act});
                    end else begin:signed_act
                        assign act_ext=$signed({act[ACT_W-1],act});
                    end
                    (* use_dsp="yes" *) wire signed [ACT_W+8:0] product=act_ext*weight;
                    always @(posedge clk)if(ready[0]&&in_valid)
                        sums_q[0][o][n]<=product;
                end
            end
        end
        for(s=1;s<=LEVELS;s=s+1)begin:tree_stage
            localparam integer PREV_COUNT=(TERMS+(1<<(s-1))-1)>>(s-1);
            localparam integer COUNT=(TERMS+(1<<s)-1)>>s;
            localparam integer SRC_STAGE=s+PIPE_SELECTED_OPERANDS-1;
            localparam integer DST_STAGE=s+PIPE_SELECTED_OPERANDS;
            assign ready[SRC_STAGE]=!valid_q[SRC_STAGE]||ready[DST_STAGE];
            for(o=0;o<OUT_PAR;o=o+1)begin:channel
                for(j=0;j<COUNT;j=j+1)begin:node
                    if(2*j+1<PREV_COUNT)begin:pair
                        (* use_dsp="no" *) wire signed [31:0] added=
                            sums_q[s-1][o][2*j]+sums_q[s-1][o][2*j+1];
                        always @(posedge clk)if(ready[DST_STAGE]&&valid_q[SRC_STAGE])
                            sums_q[s][o][j]<=added;
                    end else begin:single
                        always @(posedge clk)if(ready[DST_STAGE]&&valid_q[SRC_STAGE])
                            sums_q[s][o][j]<=sums_q[s-1][o][2*j];
                    end
                end
            end
            always @(posedge clk)begin
                if(rst)valid_q[DST_STAGE]<=0;
                else if(ready[DST_STAGE])begin
                    valid_q[DST_STAGE]<=valid_q[SRC_STAGE];
                    if(valid_q[SRC_STAGE])phase_q[DST_STAGE]<=phase_q[SRC_STAGE];
                end
            end
        end
    endgenerate
    always @(posedge clk)begin
        if(rst)valid_q[0]<=0;
        else if(ready[0])begin
            valid_q[0]<=in_valid;
            if(in_valid)phase_q[0]<=in_phase;
        end
    end
    generate if(PIPE_SELECTED_OPERANDS!=0)begin:operand_valid_stage
        assign ready[0]=!valid_q[0]||ready[1];
        always @(posedge clk)begin
            if(rst)valid_q[1]<=0;
            else if(ready[1])begin
                valid_q[1]<=valid_q[0];
                if(valid_q[0])phase_q[1]<=phase_q[0];
            end
        end
    end endgenerate
endmodule
